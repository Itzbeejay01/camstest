<?php
include 'include/connection.php';

if (isset($_POST['submit'])) {
    $surname = strip_tags($_POST['surname']);
    $othernames = strip_tags($_POST['othernames']);
    $level = strip_tags($_POST['level']);
    $gender = strip_tags($_POST['gender']);
    $matricNumber = strip_tags($_POST['matricNumber']);
    $email = strip_tags($_POST['email']);
    $phoneNumber = strip_tags($_POST['phoneNumber']);
    $college = strip_tags($_POST['college']);
    $department = strip_tags($_POST['department']);
    $hostel_id = strip_tags($_POST['hostel_id']);
    $block = isset($_POST['block']) ? strip_tags($_POST['block']) : null; // Allow NIL
    $roomNo = strip_tags($_POST['roomNo']);
    $bedSpace = strip_tags($_POST['bedSpace']);

    // Check if matric number already exists
    $check_matric = $connect->query("SELECT matricNumber, email, phoneNumber FROM tblstudents WHERE matricNumber='$matricNumber' OR email='$email' OR phoneNumber='$phoneNumber'");
    $count = $check_matric->num_rows;

    if ($count == 0) {
        // Cropped image handling
        if (isset($_POST["croppedImage"])) {
            // Decode the base64 encoded cropped image data
            $croppedImageData = $_POST["croppedImage"];
            $croppedImage = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $croppedImageData));

            // Specify the directory where images will be stored
            $targetDir = "uploads/";

            // Generate a unique file name
            $targetFileName = $matricNumber . '.jpg'; // Assuming JPEG format for the cropped image

            // Path to save the cropped image
            $targetFilePath = $targetDir . $targetFileName;

            // Save the cropped image to the server's filesystem
            if (file_put_contents($targetFilePath, $croppedImage)) {
                // Insert student record into database
                if ($block === null) {
                    $query = "INSERT INTO tblstudents (surname, othernames, level, gender, matricNumber, email, phoneNumber, college, department, hostel_id, roomNo, bedSpace, image_path) VALUES ('$surname', '$othernames', '$level', '$gender', '$matricNumber', '$email', '$phoneNumber', '$college', '$department', '$hostel_id', '$roomNo', '$bedSpace', '$targetFilePath')";
                } else {
                    $query = "INSERT INTO tblstudents (surname, othernames, level, gender, matricNumber, email, phoneNumber, college, department, hostel_id, block, roomNo, bedSpace, image_path) VALUES ('$surname', '$othernames', '$level', '$gender', '$matricNumber', '$email', '$phoneNumber', '$college', '$department', '$hostel_id', '$block', '$roomNo', '$bedSpace', '$targetFilePath')";
                }

                if ($connect->query($query)) {
                    header("Location: recordsubmitted.php");
                    exit();
                } else {
                    echo "Error: " . $connect->error;
                    // Handle database insertion error
                }
            } else {
                echo '<div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
                <p class="font-bold">Please take a photo!</p>
            </div>';
                // Handle cropped image saving error
            }
        } else {
            echo "No cropped image data received.";
            // Handle no cropped image data received error
        }
    } else {
        echo '<div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
            <p class="font-bold">Sorry! Matric Number/Email/Phone Number already exists!</p>
        </div>';
    }
    $connect->close();
}
?>