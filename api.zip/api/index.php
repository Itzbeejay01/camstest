<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login Panel</title>
    <link rel="stylesheet" href="dist/output.css">
    <link rel="shortcut icon" href="img/logo.png" type="image/x-icon">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />

</head>
<body class="w-full h-full loginback mybody lg:px-64 px-6 py-16">
<div class="w-full h-full bg-transparent rounded py-6 px-4  backdrop-blur-sm lg:w-full lg:flex lg:px-0 lg:py-16 lg:justify-center lg:items-center"
        style="box-shadow: 0 2px 5px rgba(113, 128, 150); height: 560px;">

<div class="hidden w-full h-full bg-white rounded  backdrop-blur-sm  lg:w-full lg:flex lg:flex-col lg:py-16 lg:justify-center lg:items-center"style="height: 560px;">
        <img src="img/reg.png" alt="">
    </div>
    <div class="w-full h-full bg-transparent rounded py-8 px-4 lg:w-full lg:flex lg:flex-col lg:px-0 lg:py-16 lg:justify-center lg:items-center"
        style="height: 560px;">
        <div class="flex flex-col items-center">
            <h2 class="text-lg text-gray-800 font-bold text-center px-2">JABU CHAPEL ATTENDANCE MANAGEMENT SYSTEM</h2>
            <p class="mb-4 text-center">(JABU_CAMS)</p>
            <img class="w-24" src="img/logo.png" alt="">
            <h2 class="text-lg font-medium text-center text-gray-800 mb-5">Admin Login Panel</h2>
        </div>
        <form id="adminLoginForm" method="post" class="w-full h-full pb-5 lg:px-14">
            <?php
            include 'include/connection.php';
            // Check login
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $userRole = $_POST['userRole'];
                $email = $_POST['email'];
                $password = $_POST['password'];
                $hashed_password = hash('sha256', $password); // Hash the password using SHA256
            
                if ($userRole == "superAdmin") {
                    $query = "SELECT surname FROM tbladmin WHERE email = '$email' AND password = '$hashed_password'";
                    $result = mysqli_query($connect, $query);

                    if (mysqli_num_rows($result) > 0) {
                        $row = mysqli_fetch_assoc($result);
                        $_SESSION["username"] = $row["surname"];
                        echo "<script type = \"text/javascript\">
                    window.location = (\"admin/index.php\")
                    </script>";
                    } else {
                        echo "<div class='bg-red-500 shadow-slate-200 shadow-md text-white px-5 py-3 rounded-md  my-2 mb-8 text-center'>Invalid email or password</div>";
                    }
                } else if ($userRole == "moderator") {
                    // Query to check moderator credentials
                    $query = "SELECT * FROM tblmoderator WHERE email='$email' AND password='$hashed_password'";
                    $result = mysqli_query($connect, $query);

                    if (mysqli_num_rows($result) == 1) {
                        // Moderator authenticated, set session
                        $moderator = mysqli_fetch_assoc($result);
                        $_SESSION['mod_id'] = $moderator['mod_id'];
                        //$_SESSION['email'] = $moderator['email'];
                        echo "<script type = \"text/javascript\">
                    window.location = (\"moderator/index.php\")
                    </script>";
                    } else {
                        // Moderator authentication failed
                        echo "<div class='bg-red-500 shadow-slate-200 shadow-md text-white px-5 py-3 rounded-md  my-2 mb-8 text-center'>Invalid email or password</div>";
                    }
                }
            }
            ?>
            <div class="mb-4">
                <select id="userRole" name="userRole"
                    class="text-gray-800 border-2 outline-none rounded-md form-select mt-1 p-2 w-full" required>
                    <option value="" disabled selected>Select User Role</option>
                    <option value="moderator">Moderator</option>
                    <option value="superAdmin">Super Admin</option>
                </select>
            </div>
            <div class="relative mb-4">
                <input type="email" id="email" name="email"
                    class="w-full border-none border-gray-300  rounded-md pl-14 pr-2 py-2 px-2 outline-none"
                    placeholder="Email Address">
                <div class="absolute inset-y-0 left-0 flex items-center rounded-l-md px-3 bg-green-500">
                    <span class="material-symbols-outlined text-white">person</span>
                </div>
            </div>
            <div class="relative mb-4">
                <input type="password" id="password" name="password"
                    class="w-full border-none border-gray-300 rounded-md pl-14 pr-2 py-2 px-2 outline-none"
                    placeholder="Password">
                <div class="absolute inset-y-0 left-0 flex items-center rounded-l-md px-3 bg-green-500">
                    <span class="material-symbols-outlined text-white">passkey</span>
                </div>
            </div>
            <button name="login" type="submit"
                class="w-full font-medium text-lg bg-green-500 text-white p-2 rounded shadow-lg hover:bg-green-700 flex items-center justify-center"><span
                class="material-symbols-outlined text-white font-semibold mr-1">login</span> <p>Login</p></button>
        </form>
    </div>    
</div>
<?php include "include/footer.php"; ?>  
</body>
</html>
<script src="js/adminscript.js"></script>