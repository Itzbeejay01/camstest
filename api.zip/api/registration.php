<?php
include 'include/connection.php';
include 'insert.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JABU CHAPEL ATTENDANCE SYSTEM</title>
    <link rel="stylesheet" href="dist/output.css">
    <link rel="shortcut icon" href="img/logo.png" type="image/x-icon">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.12/cropper.min.css" rel="stylesheet">
    <style>
        /* Your custom styles */
        input::file-selector-button {
            background-color: white;
            border: none;
        }

        input::file-selector-button {
            border-radius: 4px;
            font-weight: 500;
            font-size: medium;
            padding: 4px 6px;
            color: green !important;
            text-decoration: underline;
        }

        input::file-selector-button::after {
            max-width: 100%;
            height: 2px;
            display: block;
            content: "";
            background: linear-gradient(-90deg, #ff9100 0%, #f10366 50%, #6173ff 100%);
            opacity: 1;
            margin-bottom: -6px;
            margin-top: 1px;
        }

        .bn40div {
            display: flex;
        }

        image {
            background-image: url(img/background.jpg);
        }
    </style>
</head>

<body class="w-full h-full bg-gray-100 px-4 py-8 lg:px-52">
    <div class="flex bg-transparent backdrop-blur-sm rounded shadow-md lg:w-full lg:flex lg:justify-center"
        style="box-shadow: 0 4px 10px rgba(113, 128, 150);">
        <!-- image for pc view -->
        <div class="rounded p-8 bg-white hidden lg:w-full lg:flex lg:flex-col lg:justify-center" style="height: 650px;">
            <img src="img/reg.png" alt="">
        </div>
        <!-- Major form -->
        <div class="bg-transparent backdrop-blur-sm rounded p-8 lg:w-full lg:flex lg:flex-col lg:justify-center"
            style="height: 650px;">
            <div class="flex flex-col items-center mt-5">
                <h2 class="text-xl text-gray-600 font-bold mb-4 text-center">JABU CHAPEL ATTENDANCE MANAGEMENT SYSTEM
                </h2>
                <p class="mb-4 text-center">(JABU_CAMS)</p>
                <img class="w-24" src="img/logo.png" alt="">
                <h2 class="text-lg font-medium text-center text-gray-600 mb-5">Student Registration Panel</h2>
            </div>
            <form id="registrationForm" method="post" enctype="multipart/form-data">
                <!-- Personal Information -->
                <div id="personalInfo" class="form-section" style="height: 350px;">
                    <div class="flex flex-col">
                        <!-- Your Personal Information Fields -->
                        <p class="section-title font-bold text-md mb-4 text-green-800">Personal Information:</p>
                        <div class="relative mb-3">
                            <input type="text" id="surname" name="surname"
                                class="w-full shadow-md shadow-gray-300 rounded-full pl-12 pr-2 py-2 px-2 outline-none"
                                placeholder="Surname" required>
                            <div class="absolute inset-y-0 left-0 flex items-center rounded-l-md px-3 ">
                                <span class="material-symbols-outlined text-2xl text-green-500">person</span>
                            </div>
                        </div>
                        <p id="surnameError" class="hidden text-red-500 text-sm mt-1">Please enter your surname.</p>
                        <div class="relative mb-3">
                            <input type="text" id="othernames" name="othernames"
                                class="w-full shadow-md shadow-gray-300 rounded-full pl-12 pr-2 py-2 px-2 outline-none"
                                placeholder="Othernames" required>
                            <div class="absolute inset-y-0 left-0 flex items-center rounded-l-md px-3 ">
                                <span class="material-symbols-outlined text-2xl text-green-500">person</span>
                            </div>
                        </div>
                        <div class="relative mb-3">
                            <select id="gender" name="gender"
                                class="w-full h-10 shadow-md shadow-gray-300 rounded-full pr-2 px-2 outline-none bg-white"
                                required>
                                <option value="" disabled selected>Select Gender</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>
                        <div class="relative mb-3">
                            <input type="tel" id="phoneNumber" name="phoneNumber"
                                class="w-full shadow-md shadow-gray-300 rounded-full pl-12 pr-2 py-2 px-2 outline-none"
                                placeholder="Phone Number" minlength="11" maxlength="11" required>
                            <div class="absolute inset-y-0 left-0 flex items-center rounded-l-md px-3 ">
                                <span class="material-symbols-outlined text-2xl text-green-500">person</span>
                            </div>
                        </div>
                        <p id="phoneNumberError" class="hidden text-red-500 text-sm mt-1">Enter 11 digit phone number.
                        </p>

                    </div>
                    <button type="button" id="nextPersonalInfo"
                        class="next-btn w-full flex flex-col items-center justify-center mt-5">
                        <span
                            class="material-symbols-outlined text-green-800 font-semibold p-3 bg-white shadow-md rounded-full hover:bg-green-800 hover:text-white">arrow_forward</span>
                    </button>
                </div>

                <!-- Academic Information -->
                <div id="academicInfo" class="form-section" style="display: none; height: 350px;">
                    <div class="lg:flex flex flex-col">
                        <!-- Your Academic Information Fields -->
                        <p class="section-title font-bold text-md mb-2  text-green-800">Academic Information:</p>
                        <div class="relative mb-2">
                            <select id="college" name="college"
                                class="w-full h-10 shadow-md shadow-gray-300 rounded-full pr-2 px-2 outline-none bg-white">
                                <option value="" disabled selected>Select College</option>
                                <option value="1">College of Agriculture and Natural Science</option>
                                <option value="2">College of Health Science</option>
                                <option value="3">College of Law</option>
                                <option value="4">College of Humanities and Social Science</option>
                                <option value="5">College of Environmental Science</option>
                                <option value="6">College of Management Science</option>
                                <!-- Add your other college options here -->
                            </select>
                        </div>
                        <div class="relative mb-2">
                            <select id="department" name="department"
                                class="w-full h-10 shadow-md shadow-gray-300 rounded-full pr-2 py-2 px-2 outline-none bg-white"
                                required>
                                <option value="" disabled selected>Select Department</option>
                            </select>
                        </div>
                        <div class="relative mb-2">
                            <input type="text" id="matricNumber" name="matricNumber"
                                class="w-full shadow-md shadow-gray-300 rounded-full pl-12 pr-2 py-2 px-2 outline-none"
                                placeholder="Matric Number" maxlength="10" required>
                            <div class="absolute inset-y-0 left-0 flex items-center rounded-l-md px-3 ">
                                <span class="material-symbols-outlined text-2xl text-green-500">123</span>
                            </div>
                        </div>

                        <div class="relative mb-2">
                            <input type="email" id="email" name="email"
                                class="w-full shadow-md shadow-gray-300 rounded-full pl-12 pr-2 py-2 px-2 outline-none"
                                placeholder="Jabu Student Mail">
                            <div class="absolute inset-y-0 left-0 flex items-center rounded-l-md px-3 ">
                                <span class="material-symbols-outlined text-2xl text-green-500">mail</span>
                            </div>
                        </div>
                        <p id="emailError" class="hidden text-red-500 text-sm mt-1">Please enter a valid student email
                            address.</p>
                        <div class="relative mb-2">
                            <select id="level" name="level"
                                class="w-full h-10 shadow-md shadow-gray-300 rounded-full pr-2 px-2 outline-none bg-white"
                                required>
                                <option value="" disabled selected>Select Level</option>
                                <option value="100">100</option>
                                <option value="200">200</option>
                                <option value="300">300</option>
                                <option value="400">400</option>
                                <option value="500">500</option>
                            </select>
                        </div>
                    </div>
                    <div class="flex">
                        <button type="button" id="prevAcademicInfo"
                            class="prev-btn w-full flex flex-col items-end justify-center mr-2">
                            <span
                                class="material-symbols-outlined text-green-800 font-semibold p-3 bg-white shadow-md rounded-full hover:bg-green-800 hover:text-white">arrow_back</span>
                        </button>
                        <button type="button" id="nextAcademicInfo"
                            class="next-btn w-full flex flex-col items-start justify-center">
                            <span
                                class="material-symbols-outlined text-green-800 font-semibold p-3 bg-white shadow-md rounded-full hover:bg-green-800 hover:text-white">arrow_forward</span>
                        </button>
                    </div>
                </div>

                <!-- Accommodation Information -->
                <div id="accommodationInfo" class="form-section" style="display: none; height: 350px;">
                    <div class="lg:flex flex flex-col">
                        <!-- Your Accommodation Information Fields -->
                        <p class="section-title font-bold text-md mb-4  text-green-800">Hostel Information:</p>
                        <div class="relative mb-3">
                            <select id="hostels" name="hostel_id"
                                class="w-full shadow-md shadow-gray-300 rounded-full pr-2 py-3 px-2 outline-none bg-white"
                                required>
                                <option value="" disabled selected>Select Hostel</option>
                                <option value="1">Male Hostel 1</option>
                                <option value="2">Male Hostel 2</option>
                                <option value="3">Male Hostel 3</option>
                                <option value="4">Male Hostel 4</option>
                                <option value="5">Female Hostel 1</option>
                                <option value="6">Female Hostel 2</option>
                                <option value="7">Female Hostel 3</option>
                                <option value="8">Female Hostel 4</option>
                            </select>
                        </div>
                        <div class="relative mb-3" id="blockContainer" style="display: none;">
                            <select id="block" name="block"
                                class="w-full shadow-md shadow-gray-300 rounded-full pr-2 py-2 px-2 outline-none bg-white">
                                <option value="" disabled selected>Select Block</option>
                            </select>
                            <div class="absolute inset-y-0 left-0 flex items-center rounded-l-md px-3 ">
                            </div>
                        </div>

                        <div class="relative mb-3">
                            <input type="text" id="roomNo" name="roomNo"
                                class="w-full shadow-md shadow-gray-300 rounded-full pl-12 pr-2 py-2 px-2 outline-none bg-white"
                                placeholder="Room Number" maxlength="3" required>
                            <div class="absolute inset-y-0 left-0 flex items-center rounded-l-md px-3 ">
                                <span class="material-symbols-outlined text-2xl text-green-500">edit_note</span>
                            </div>
                        </div>

                        <div class="relative mb-3">
                            <input type="number" id="bedSpace" name="bedSpace"
                                class="w-full shadow-md shadow-gray-300 rounded-full pl-12 pr-2 py-2 px-2 outline-none bg-white"
                                placeholder="Bed Space" required>
                            <div class="absolute inset-y-0 left-0 flex items-center rounded-l-md px-3 ">
                                <span class="material-symbols-outlined text-2xl text-green-500">edit_note</span>
                            </div>
                        </div>
                    </div>
                    <div class="flex mt-6">
                        <button type="button" id="prevAccommodationInfo"
                            class="prev-btn w-full flex flex-col items-end justify-center mr-2">
                            <span
                                class="material-symbols-outlined text-green-800 font-semibold p-3 bg-white shadow-md rounded-full hover:bg-green-800 hover:text-white">arrow_back</span>
                        </button>
                        <button type="button" id="nextAccommodationInfo"
                            class="next-btn w-full flex flex-col items-start justify-center">
                            <span
                                class="material-symbols-outlined text-green-800 font-semibold p-3 bg-white shadow-md rounded-full hover:bg-green-800 hover:text-white">arrow_forward</span>
                        </button>
                    </div>
                </div>
                <!-- Image Information -->
                <div id="imageInfo" class="form-section" style="display: none; height: 350px;">
                    <div class="lg:flex flex flex-col">
                        <!-- Your Image Information Fields -->
                        <p class="section-title font-bold text-md mb-2  text-green-800">Image Information:</p>
                        <div class="relative mb-2">
                            <input type="hidden" id="croppedImageInput" name="croppedImage">
                            <div class="relative mb-2">
                                <input type="file" id="image" name="image" accept="image/*" capture="camera"
                                    class="hidden">
                                <label for="image"
                                    class="block font-medium text-gray-700 cursor-pointer w-full shadow-md shadow-gray-300 rounded-full pl-12 pr-2 py-2 px-2 outline-none bg-white"
                                    required> Take Photo </label>
                                <div class="absolute inset-y-0 left-0 flex items-center rounded-l-md px-3 ">
                                    <span class="material-symbols-outlined text-2xl text-green-500">camera</span>
                                </div>
                            </div>
                        </div>
                        <div id="preview" class="hidden rounded-lg mb-4" style="width: 100px; height: 100px;">
                            <h3>Preview:</h3>
                            <img id="previewImage" src="#" alt="Preview">
                        </div>
                    </div>
                    <div class="flex mt-3">
                        <button type="button" id="prevImageInfo"
                            class="prev-btn w-full flex flex-col items-center justify-center">
                            <span
                                class="material-symbols-outlined text-green-800 font-semibold p-3 bg-white shadow-md rounded-full hover:bg-green-800 hover:text-white">arrow_back</span>
                        </button>
                        <button type="submit" name="submit" id="submitForm"
                            class="submit-btn w-full flex flex-col items-center justify-center"> <span
                                class="material-symbols-outlined text-green-800 font-semibold p-3 bg-white shadow-md rounded-full hover:bg-green-800 hover:text-white">done_all</span>
                        </button>
                    </div>
            </form>
        </div>
    </div>
    <div id="cropModal" class="fixed inset-0 z-10 overflow-y-auto hidden">
        <div class="flex items-center justify-center min-h-screen">
            <div class="fixed inset-0 bg-black bg-opacity-50"></div>
            <div class="z-20 relative bg-white rounded-lg overflow-hidden">
                <div id="cropper" style="height: 400px;"></div>
                <div class="flex justify-center p-4">
                    <button id="cropButton"
                        class="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 focus:outline-none focus:bg-indigo-700">Crop</button>
                </div>
            </div>
        </div>
    </div>
    <script src="js/regscript.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.12/cropper.min.js"></script>
</body>

</html>
<script>
    document.getElementById('hostels').addEventListener('change', function() {
        const blockContainer = document.getElementById('blockContainer');
        const blockSelect = document.getElementById('block');

        // Show block select if hostel 4 or 8 is selected
        if (this.value === '4' || this.value === '8') {
            blockContainer.style.display = 'block';
            blockSelect.setAttribute('required', 'required');
        } else {
            blockContainer.style.display = 'none';
            blockSelect.removeAttribute('required');
        }
    });
</script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const sections = document.querySelectorAll('.form-section');
        let currentSection = 0;

        function showSection(index) {
            sections.forEach((section, i) => {
                section.style.display = i === index ? 'block' : 'none';
            });
        }

        function validateSection(index) {
            const currentFields = sections[index].querySelectorAll('input, select');
            for (let field of currentFields) {
                if (!field.checkValidity()) {
                    field.reportValidity();
                    return false;
                }
            }
            return true;
        }

        document.getElementById('nextPersonalInfo').addEventListener('click', function () {
            if (validateSection(currentSection)) {
                currentSection = 1;
                showSection(currentSection);
            }
        });

        document.getElementById('prevAcademicInfo').addEventListener('click', function () {
            currentSection = 0;
            showSection(currentSection);
        });

        document.getElementById('nextAcademicInfo').addEventListener('click', function () {
            if (validateSection(currentSection)) {
                currentSection = 2;
                showSection(currentSection);
            }
        });

        document.getElementById('prevAccommodationInfo').addEventListener('click', function () {
            currentSection = 1;
            showSection(currentSection);
        });

        document.getElementById('nextAccommodationInfo').addEventListener('click', function () {
            if (validateSection(currentSection)) {
                currentSection = 3;
                showSection(currentSection);
            }
        });

        document.getElementById('prevImageInfo').addEventListener('click', function () {
            currentSection = 2;
            showSection(currentSection);
        });

        // Initialize form to show the first section
        showSection(currentSection);
    });
</script>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const fileInput = document.getElementById("image");
        const previewImage = document.getElementById("previewImage");
        const previewDiv = document.getElementById("preview");
        const cropButton = document.getElementById("cropButton");
        const form = document.getElementById("uploadForm"); // Form element
        const croppedImageInput = document.getElementById("croppedImageInput"); // Hidden input for cropped image data
        let cropper;

        fileInput.addEventListener("change", function () {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function (event) {
                    previewImage.src = event.target.result;
                    previewDiv.classList.remove("hidden");
                    openCropModal(file);
                };
                reader.readAsDataURL(file);
            }
        });

        function openCropModal(file) {
            const cropModal = document.getElementById("cropModal");
            cropModal.classList.remove("hidden");

            const image = document.createElement("img");
            image.src = URL.createObjectURL(file);

            const cropperContainer = document.getElementById("cropper");
            cropperContainer.innerHTML = ''; // Clear container before appending
            cropperContainer.appendChild(image);

            cropper = new Cropper(image, {
                aspectRatio: 1, // Aspect ratio for 1:1 square image
                viewMode: 1,
                autoCropArea: 1,
                movable: true,
                zoomable: false,
                background: false
            });

            cropButton.addEventListener("click", function () {
                const croppedCanvas = cropper.getCroppedCanvas();
                cropper.destroy();
                cropModal.classList.add("hidden");

                // Display the cropped image in the preview
                previewImage.src = croppedCanvas.toDataURL('image/jpeg');

                // Resize the cropped image to 512x512 pixels and compress
                resizeAndCompressImage(croppedCanvas, 512, 512, 20, 30);
            });
        }

        function resizeAndCompressImage(image, targetWidth, targetHeight, minSizeKB, maxSizeKB) {
            // Create a canvas element for resizing
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');

            // Calculate the scale factors for resizing while maintaining aspect ratio
            const scaleFactor = Math.min(targetWidth / image.width, targetHeight / image.height);
            const scaledWidth = image.width * scaleFactor;
            const scaledHeight = image.height * scaleFactor;

            // Set the canvas dimensions to the target dimensions
            canvas.width = targetWidth;
            canvas.height = targetHeight;

            // Draw the image onto the canvas with the calculated dimensions
            ctx.drawImage(image, 0, 0, scaledWidth, scaledHeight);

            // Convert the canvas content to a Blob with specified quality
            canvas.toBlob(function (blob) {
                // Calculate initial quality
                let quality = 0.4;

                // Set target size in bytes
                const minSize = minSizeKB * 1024;
                const maxSize = maxSizeKB * 1024;

                // Decrease quality while the size is outside the desired range
                while (blob.size > maxSize && quality >= 0.1) {
                    canvas.toBlob(function (newBlob) {
                        blob = newBlob;
                    }, 'image/jpeg', quality);
                    quality -= 0.1;
                }

                // Convert Blob to base64 data URL
                const reader = new FileReader();
                reader.onload = function () {
                    const base64DataUrl = reader.result;
                    // Set the base64 data URL as the value of the hidden input
                    croppedImageInput.value = base64DataUrl;
                    // Submit the form
                    form.submit();
                };
                reader.readAsDataURL(blob);
            }, 'image/jpeg', 0.4); // Initial quality
        }
    });
</script>