<?php
session_start();

// Check if moderator is logged in
if (!isset($_SESSION['mod_id'])) {
  header("location: index.php");
  exit;
}
?><!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Attendance Submitted</title>
  <link rel="stylesheet" href="../dist/output.css">
  <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon">
  <link rel="stylesheet"
    href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
  <style>
    @keyframes rotate {
      0% {
        transform: rotate(0deg);
      }

      100% {
        transform: rotate(360deg);
      }
    }

    .loading-container {
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .loading-spinner {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      border: 5px solid #17a349;
      border-top-color: transparent;
      animation: rotate 0.7s infinite linear;
    }
  </style>
</head>

<body class="w-full max-h-full lg:flex bg-gray-100 ">
  <?php include 'include/header.php'; ?>
  <div class="w-full px-4 py-6">
    <div class="bg-gray-50 p-8 rounded shadow-lg text-center mt-7">
      <h1 class="text-2xl font-bold text-green-600 mb-4">Attendance Taken Successfully!</h1>
      <div class="loading-container">
        <div class="loading-spinner"></div>
      </div>
      <p class="text-gray-600 mb-4">You will be redirected <a href="/moderator/index.php" class="text-green-600"></a> in
        <span id="countdown">5</span> seconds.</p>
    </div>
  </div>
  <script>
    let timeLeft = 5;
    const countdown = document.getElementById('countdown');

    const timer = setInterval(() => {
      timeLeft--;
      countdown.textContent = timeLeft;

      if (timeLeft <= 0) {
        clearInterval(timer);
        window.location.href = 'index.php';
      }
    }, 1000);
  </script>

  <!-- FOOTER -->

  <div class="w-full shadow-gray-200 py-4 flex items-center justify-center lg:mt-52 lg:py-6">
    <p class="text-md font-medium text-black"> &copy; Copyright
      <script>
        document.write(new Date().getFullYear());
      </script>. Created by &ThinSpace;BeeTechHub
    </p>
  </div>

  </div>
  </div>

  </div>
  <!-- SCRIPTS -->
  <script src="/js/adminscript.js"></script>
  <script src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons.js"></script>
  <script>
    function updateDateTime() {
      const dateTimeElement = document.getElementById('currentDateTime');
      const now = new Date();
      const date = now.toLocaleDateString();
      const time = now.toLocaleTimeString();
      dateTimeElement.textContent = `Date: ${date} | Time: ${time}`;
    }

    // Update the date and time every second
    setInterval(updateDateTime, 1000);

    // Initial call to display the date and time
    updateDateTime();
  </script>
  <script>
    document.getElementById('toggleButton').addEventListener('click', function () {
      document.getElementById('sidebar').classList.toggle('hidden');
    });
  </script>
  <script>
    document.getElementById('dropdown-button').addEventListener('click', function () {
      var menu = document.getElementById('dropdown-menu');
      if (menu.classList.contains('hidden')) {
        menu.classList.remove('hidden');
      } else {
        menu.classList.add('hidden');
      }
    });

    document.addEventListener('click', function (event) {
      var menu = document.getElementById('dropdown-menu');
      var button = document.getElementById('dropdown-button');
      if (!menu.contains(event.target) && event.target !== button) {
        menu.classList.add('hidden');
      }
    });
  </script>

</body>

</html>