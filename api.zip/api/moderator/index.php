<?php
session_start();
if (!isset($_SESSION['mod_id'])) {
    header("Location: ../index.php");
    exit;
}
?><!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Moderator Dashboard</title>
    <link rel="stylesheet" href="../dist/output.css">
    <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
</head>

<body class="w-full h-full lg:flex-row lg:min-h-100vh lg:flex bg-gray-100 ">
    <?php include 'include/header.php'; ?>
    <div class="lg:flex-1 pc-view-padding h-full">
        <div class="text-lg text-center font-bold text-green-800 py-4 bg-white shadow-lg rounded hidden lg:block">
            JABU_CAMS - DASHBOARD</div>
        <div class="w-full lg:flex lg:px-10 lg:pt-16 px-2">
            <!-- TOTAL STUDENT -->
            <div
                class="bg-blue-800 shadow-slate-500 text-white px-5 py-8 rounded-lg shadow-sm my-2 mb-8 lg:w-full lg:mx-10">
                <div href="" class="flex items-center justify-between">
                    <div class="flex items-center">
                        <span class="material-symbols-outlined text-2xl">group</span>
                        <p class="text-xl mx-2">Total Students</p>
                    </div>
                    <p class="text-xl mr-4">
                        <?php
                        include '../include/connection.php';

                        // Retrieve moderator's block and hostel_id
                        $query_mod_details = "SELECT block_id, hostel_id FROM tblmoderator WHERE mod_id = $mod_id";
                        $result_mod_details = $connect->query($query_mod_details);
                        if ($result_mod_details->num_rows > 0) {
                            $row_mod_details = $result_mod_details->fetch_assoc();
                            $assigned_block = $row_mod_details['block_id'];
                            $assigned_hostel_id = $row_mod_details['hostel_id'];

                            // Check if the moderator has a block assigned
                            if ($assigned_block != null) {
                                // Query to count total students in the assigned hostel and block
                                $query_total_students = "SELECT COUNT(*) AS total FROM tblstudents WHERE block = '$assigned_block' AND hostel_id = '$assigned_hostel_id'";
                            } else {
                                // Query to count total students in the assigned hostel (no block assigned)
                                $query_total_students = "SELECT COUNT(*) AS total FROM tblstudents WHERE hostel_id = '$assigned_hostel_id'";
                            }

                            $result_total_students = $connect->query($query_total_students);
                            if ($result_total_students->num_rows > 0) {
                                // Output total students
                                $row_total_students = $result_total_students->fetch_assoc();
                                echo $row_total_students["total"];
                            } else {
                                echo "0";
                            }
                        } else {
                            echo "0";
                        }
                        ?>
                    </p>
                </div>
            </div>
            <div
                class="bg-slate-900 shadow-slate-500 text-white px-5 py-8 rounded-lg shadow-sm my-2 mb-8 lg:w-full lg:mx-10">
                <div href="" class="flex items-center justify-between">
                    <div class="flex items-center">
                        <span class="material-symbols-outlined text-2xl">home</span>
                        <p class="text-xl mx-2">Hostels</p>
                    </div>
                    <p class="text-xl"><?php
                    if (isset($_SESSION['mod_id'])) {
                        // Include database connection
                        include("../include/connection.php");

                        // Fetch moderator's assignment
                        $mod_id = $_SESSION['mod_id'];
                        $sql = "SELECT m.hostel_id, m.block_id, h.hostel 
                                          FROM tblmoderator m
                                          LEFT JOIN tblhostels h ON m.hostel_id = h.id
                                          WHERE m.mod_id = $mod_id";
                        $result = mysqli_query($connect, $sql);
                        $row = mysqli_fetch_assoc($result);

                        // Concatenate assigned hostel and block
                        $assignment = '';
                        if (!empty($row['hostel_id'])) {
                            $assignment .= $row['hostel'];
                        }
                        if (!empty($row['block_id'])) {
                            $assignment .= ' Block ' . $row['block_id'];
                        }

                        // Display concatenated assignment
                        if (!empty($assignment)) {
                            echo '<div class="text-md">' . $assignment . '</div>';
                        }
                    }
                    ?></p>
                </div>
            </div>
        </div>
        <div class="w-full lg:flex lg:px-10 lg:pt-8 px-2">
            <!-- attendance -->
            <div
                class="bg-green-500 shadow-slate-500 text-white px-5 py-8 rounded-lg shadow-sm my-2 mb-8 lg:w-full lg:mx-10">
                <a href="program.php">
                    <div href="" class="flex items-center justify-between">
                        <div class="flex items-center">
                            <span class="material-symbols-outlined text-2xl">task_alt</span>
                            <p class="text-xl mx-2">Take Attendance</p>
                        </div>
                    </div>
                </a>
            </div>
            <!-- markout -->
            <div
                class="bg-emerald-800 shadow-slate-500 text-white px-5 py-8 rounded-lg shadow-sm my-2 mb-8 lg:w-full lg:mx-10">
                <a href="post_program.php">
                    <div href="" class="flex items-center justify-between">
                        <div class="flex items-center">
                            <span class="material-symbols-outlined text-2xl">done_all</span>
                            <p class="text-xl mx-2">Mark Out</p>
                        </div>
                    </div>
                </a>
            </div>
        </div>
        <div class="w-full lg:flex lg:px-10 lg:pt-8 px-2">
            <!-- Semester -->
            <div
                class="bg-black shadow-slate-500 text-white px-5 py-8 rounded-lg shadow-sm my-2 mb-8 lg:w-full lg:mx-10">
                <div href="" class="flex items-center justify-between">
                    <div class="flex items-center">
                        <span class="material-symbols-outlined text-2xl">calendar_month</span>
                        <p class="text-xl mx-2">2024/2025</p>
                    </div>
                </div>
            </div>
            <!-- DOWNLOAD RECORD -->

            <div
                class="bg-blue-600 shadow-slate-500 text-white px-5 py-8 rounded-lg shadow-sm my-2 mb-8 lg:w-full lg:mx-10">
                <a href="record.php">
                    <div href="" class="flex items-center justify-between">
                        <div class="flex items-center">
                            <span class="material-symbols-outlined text-2xl">download</span>
                            <p class="text-xl mx-2">Download Record</p>
                        </div>
                    </div>
                </a>
            </div>

        </div>
    </div>
    </div>
    </div>
    <?php include 'include/footer.php' ?>
    <!-- SCRIPTS -->
    <script src="/js/adminscript.js"></script>
    <script>
        function updateDateTime() {
            const dateTimeElement = document.getElementById('currentDateTime');
            const now = new Date();
            const date = now.toLocaleDateString();
            const time = now.toLocaleTimeString();
            dateTimeElement.textContent = `Date: ${date} | Time: ${time}`;
        }

        // Update the date and time every second
        setInterval(updateDateTime, 1000);

        // Initial call to display the date and time
        updateDateTime();
    </script>
    <script>
        document.getElementById('toggleButton').addEventListener('click', function () {
            document.getElementById('sidebar').classList.toggle('hidden');
        });
    </script>
    <script>
        document.getElementById('dropdown-button').addEventListener('click', function () {
            var menu = document.getElementById('dropdown-menu');
            if (menu.classList.contains('hidden')) {
                menu.classList.remove('hidden');
            } else {
                menu.classList.add('hidden');
            }
        });

        document.addEventListener('click', function (event) {
            var menu = document.getElementById('dropdown-menu');
            var button = document.getElementById('dropdown-button');
            if (!menu.contains(event.target) && event.target !== button) {
                menu.classList.add('hidden');
            }
        });
    </script>
</body>

</html>