<div class="w-full lg:w-full lg:flex justify-center lg:items-center">
    <!-- MOBILE VIEW -->
    <header class="w-full h-full bg-gray-200 shadow-lg p-4 flex items-center justify-between px-5 lg:hidden">
        <div class="flex items-center justify-center">
            <button type="hamburger" name="hamburger" id="toggleButton"><span
                    class="material-symbols-outlined bg-gray-50 p-2 rounded-md shadow-green-900 shadow-md font-bold text-2xl mr-2 text-green-600 hover:bg-green-800 hover:text-green-50">menu</span></button>
            <p class="text-lg font-medium">
                <?php
                // Start the session
                session_start();

                // Check if mod_id is set in the session
                if (isset($_SESSION['mod_id'])) {
                    // Connect to your database (Replace with your actual database connection code)
                    include ("../include/connection.php");
                    // Prepare SQL statement to retrieve user's name based on mod_id
                    $mod_id = $_SESSION['mod_id'];
                    $sql = "SELECT surname FROM tblmoderator WHERE mod_id = '$mod_id'";
                    $result = mysqli_query($connect, $sql);
                    if (mysqli_num_rows($result) > 0) {
                        // Output data of each row
                        while ($row = mysqli_fetch_assoc($result)) {
                            ?>
                        <div class="text-lg font-medium mx-2">
                            Welcome, <?php echo $row['surname']; ?>
                        </div>
                        <?php
                        }
                    } else {
                        echo "<div class='text-center text-red-500'>No user found with mod_id: $mod_id</div>";
                    }

                    // Close connection
                    mysqli_close($connect);
                } else {
                    // If mod_id is not set in the session, redirect to login page or handle accordingly
                    // header("Location: me.php"); // Redirect to your login page
                    exit;
                }
                ?>
            </p>
        </div>
        <a href="logout.php"><span
                class="material-symbols-outlined bg-gray-50 p-2 rounded-md shadow-green-700 shadow-sm font-bold text-2xl mr-2 text-green-700 hover:bg-green-800 hover:text-red-50">power_settings_new</span></a>
    </header>
    <!-- PC VIEW SIDEBAR START HERE -->
    <div class="w-1/4 min-h-screen bg-gray-30 header p-4 lg:flex lg:flex-col items-cente px-5 hidden">
        <div class="flex w-full justify-between">
            <div class="flex items-center justify-center">
                <p class="">
                    <?php
                    // Start the session
                    session_start();

                    // Check if mod_id is set in the session
                    if (isset($_SESSION['mod_id'])) {
                        // Connect to your database (Replace with your actual database connection code)
                        include ("../include/connection.php");
                        // Prepare SQL statement to retrieve user's name based on mod_id
                        $mod_id = $_SESSION['mod_id'];
                        $sql = "SELECT surname FROM tblmoderator WHERE mod_id = '$mod_id'";

                        $result = mysqli_query($connect, $sql);

                        if (mysqli_num_rows($result) > 0) {
                            // Output data of each row
                            while ($row = mysqli_fetch_assoc($result)) {
                                ?>
                            <div class="text-lg w-full font-medium">
                                Welcome, <?php echo $row['surname']; ?>
                            </div>
                            <?php
                            }
                        } else {
                            echo "<div class='text-center text-red-500'>No user found with mod_id: $mod_id</div>";
                        }

                        // Close connection
                        mysqli_close($connect);
                    } else {
                        // If mod_id is not set in the session, redirect to login page or handle accordingly
                        header("Location: me.php"); // Redirect to your login page
                        exit;
                    }
                    ?>
                </p>
            </div>
            <a href="logout.php"><span
                    class="material-symbols-outlined bg-gray-50 p-2 rounded-md shadow-green-700 shadow-sm font-bold text-2xl mr-2 text-green-700 hover:bg-green-800 hover:text-red-50">power_settings_new</span></a>

        </div>
        <div class="w-full h-1 rounded-full mt-3 bg-green-700"></div>
        <div class="flex flex-col mt-4 w-full justify-between">
            <!-- Dashboard -->
            <a href="index.php" class="mb-5">
                <div
                    class="shadow-xl rounded-lg bg-slate-50 py-4 font-medium flex items-center  hover:bg-slate-200 px-5">
                    <span class="material-symbols-outlined text-2xl">home</span>
                    <p class="text-md mx-5">Dashboard</p>
                </div>
            </a>
            <!-- Attendance -->
            <a href="program.php" class="mb-5">
                <div
                    class="shadow-xl rounded-lg bg-slate-50 py-4 font-medium flex items-center  hover:bg-slate-200 px-5">
                    <span class="material-symbols-outlined text-2xl">add_task</span>
                    <p class="text-md mx-5">Attendance</p>
                </div>
            </a>
            <!-- Pre-Attendance -->
            <a href="post_program.php" class="mb-5">
                <div
                    class="shadow-xl rounded-lg bg-slate-50 py-4 font-medium flex items-center  hover:bg-slate-200 px-5">
                    <span class="material-symbols-outlined text-2xl">add_task</span>
                    <p class="text-md mx-5">Post_Attendance</p>
                </div>
            </a>
            <!-- record -->
            <a href="record.php" class="mb-5">
                <div
                    class="shadow-xl rounded-lg bg-slate-50 py-4 font-medium flex items-center  hover:bg-slate-200 px-5">
                    <span class="material-symbols-outlined text-2xl">folder</span>
                    <p class="text-md mx-5">Record</p>
                </div>
            </a>
            <!-- calculate -->
            <a href="calculate.php" class="mb-5">
                <div
                    class="shadow-xl rounded-lg bg-slate-50 py-4 font-medium flex items-center  hover:bg-slate-200 px-5">
                    <span class="material-symbols-outlined text-2xl">cloud_download</span>
                    <p class="text-md mx-5">Download Report</p>
                </div>
            </a>
        </div>
    </div>

    <!-- PC VIEW SIDEBAR END HERE -->
    <div class="w-full flex lg:flex lg:px-0 ">
        <!-- dropdown start here -->
        <div class="flex h-full bg-gray-300 header lg:hidden">
            <div id="sidebar" class="w-64 h-full px-4 flex-shrink-0 hidden pt-2">
                <div class="flex flex-col w-full h-screen">
                    <!-- Dashboard -->
                    <a href="index.php" class="mb-5">
                        <div
                            class="shadow-xl rounded-lg bg-slate-50 py-4 font-medium flex items-center  hover:bg-slate-200 px-5">
                            <span class="material-symbols-outlined text-2xl">home</span>
                            <p class="text-sm mx-5">Dashboard</p>
                        </div>
                    </a>
                    <!-- attendance -->
                    <a href="program.php" class="mb-5">
                        <div
                            class="shadow-xl rounded-lg bg-slate-50 py-4 font-medium flex items-center  hover:bg-slate-200 px-5">
                            <span class="material-symbols-outlined text-2xl">add_task</span>
                            <p class="text-sm mx-5">Attendance</p>
                        </div>
                    </a>
                    <!-- Pre-Attendance -->
                    <a href="post_program.php" class="mb-5">
                        <div
                            class="shadow-xl rounded-lg bg-slate-50 py-4 font-medium flex items-center  hover:bg-slate-200 px-5">
                            <span class="material-symbols-outlined text-2xl">add_task</span>
                            <p class="text-sm mx-5">Post_Attendance</p>
                        </div>
                    </a>
                    <!-- record -->
                    <a href="record.php" class="mb-5">
                        <div
                            class="shadow-xl rounded-lg bg-slate-50 py-4 font-medium flex items-center  hover:bg-slate-200 px-5">
                            <span class="material-symbols-outlined text-2xl">folder</span>
                            <p class="text-sm mx-5">Record</p>
                        </div>
                    </a>
                    <!-- calculate -->
                    <a href="calculate.php" class="mb-5">
                        <div
                            class="shadow-xl rounded-lg bg-slate-50 py-4 font-medium flex items-center  hover:bg-slate-200 px-5">
                            <span class="material-symbols-outlined text-2xl">cloud_download</span>
                            <p class="text-sm mx-5">Download Report</p>
                        </div>
                    </a>
                </div>
            </div>
        </div>
        <!-- dropdown ends here -->
        <div class=" w-full h-screen">
             <!-- Current Time -->
        <div class="w-full p-2 flex items-center justify-center mb-2 lg:p-0 lg:hidden">
            <div id="currentDateTime" class="text-green-950 w-2/3 p-2 rounded-xl bg-gray-50 text-sm text-center font-medium
                        shadow-gray-300 shadow-md lg:text-center lg:w-full lg:rounded-md lg:text-lg"></div>
        </div>
        <!-- Current time end here -->