<?php
// Include the necessary libraries
require ('../../fpdf/fpdf.php');

// Start the session to access session variables
session_start();

// Check if the moderator is logged in
if (!isset($_SESSION['mod_id'])) {
    header("Location: ../index.php");
    exit;
}
// Database connection
include ("../../include/connection.php");

// Get parameters from the form
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];
$mod_id = $_SESSION['mod_id'];

//$moderator_id = $_SESSION['moderator_id'];
$sqlAssignment = "SELECT m.surname, m.othernames, m.hostel_id, m.block_id, h.hostel FROM tblmoderator m 
INNER JOIN tblhostels h ON m.hostel_id = h.id 
INNER JOIN tblblocks b ON m.block_id 
WHERE m.mod_id = '$mod_id'";
$resultAssignment = mysqli_query($connect, $sqlAssignment);
$rowAssignment = mysqli_fetch_assoc($resultAssignment);
$hostel_id = $rowAssignment['hostel_id'];
$block_id = $rowAssignment['block_id'];
$hostelName = $rowAssignment['hostel'];
$blockName = $rowAssignment['block_id'];
$surname = $rowAssignment['surname'];
$othernames = $rowAssignment['othernames'];

// Query to get the attendance records with student names
if ($block_id) {
    $sql = "SELECT a.student_id, s.surname, s.othernames, s.matricNumber, s.roomNo, s.bedSpace, COUNT(*) as total_attendance, SUM(a.attendance_status) as present_attendance
FROM tblattendance a
INNER JOIN tblstudents s ON a.student_id = s.student_id
WHERE a.attendance_date BETWEEN '$start_date' AND '$end_date' AND a.mod_id = '$mod_id' AND s.block = '$block_id' AND s.hostel_id = '$hostel_id'
GROUP BY a.student_id;";
} else {
    $sql = "SELECT a.student_id, s.surname, s.othernames, s.matricNumber, s.roomNo, s.bedSpace, COUNT(*) as total_attendance, SUM(a.attendance_status) as present_attendance
FROM tblattendance a
INNER JOIN tblstudents s ON a.student_id = s.student_id
WHERE a.attendance_date BETWEEN '$start_date' AND '$end_date' AND a.mod_id = '$mod_id' AND s.hostel_id = '$hostel_id'
GROUP BY a.student_id;";
}
$result = $connect->query($sql);

// PDF creation using FPDF library
$pdf = new FPDF();
$pdf->AddPage();
// Set logo as header aligned with hostel name
$pdf->Image('../../img/logo.png', 10, 5, 28);

// Set hostel name as the heading
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(0, 10, 'Moderator: ' . $surname . ' ' . $othernames, 0, 1, 'C');
$pdf->Cell(0, 10, $hostelName . ' Block ' . $blockName, 0, 1, 'C');

// Set table headers with styling
$pdf->SetFont('Helvetica', 'B', 14);
$pdf->SetFillColor(80, 80, 80); // Light blue
$pdf->SetTextColor(0, 0, 0); // Black

// Header row
$pdf->SetTextColor($fill ? 255 : 255, $fill ? 255 : 255, $fill ? 255 : 255);
$pdf->Cell(15, 10, 'S/N', 1, 0, 'C', true);
$pdf->Cell(38, 10, 'SURNAME', 1, 0, 'C', true);
$pdf->Cell(38, 10, 'OTHERNAMES', 1, 0, 'C', true);
$pdf->Cell(35, 10, 'MATRIC NO.', 1, 0, 'C', true);
$pdf->Cell(20, 10, 'ROOM', 1, 0, 'C', true);
$pdf->Cell(20, 10, 'SPACE', 1, 0, 'C', true);
$pdf->Cell(23, 10, 'SCORE', 1, 1, 'C', true);

// Set table rows with alternating colors and styling
$pdf->SetFont('Arial', '', 12);
$fill = false;
$counter = 1; // Initialize counter variable
while ($row = $result->fetch_assoc()) {
    // Calculate percentage
    $attendance_percentage = ($row['present_attendance'] / $row['total_attendance']) * 100;

    // Alternate row color
    $pdf->SetTextColor(0, 0, 0);
    $pdf->SetFillColor($fill ? 216 : 1, $fill ? 216 : 1, $fill ? 216 : 240);
    $pdf->Cell(15, 10, $counter++, 1, 0, 'C', $fill);
    $pdf->Cell(38, 10, $row['surname'], 1, 0, 'C', $fill);
    $pdf->Cell(38, 10, $row['othernames'], 1, 0, 'C', $fill);
    $pdf->Cell(35, 10, $row['matricNumber'], 1, 0, 'C', $fill);
    $pdf->Cell(20, 10, $row['roomNo'], 1, 0, 'C', $fill);
    $pdf->Cell(20, 10, $row['bedSpace'], 1, 0, 'C', $fill);
    $pdf->Cell(23, 10, number_format($attendance_percentage, 2) . '%', 1, 1, 'C', $fill);
    $fill = !$fill; // Toggle fill color for alternating rows
}

// Output PDF
$pdf->Output();
?>