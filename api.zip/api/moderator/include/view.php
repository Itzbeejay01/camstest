<?php
// Include the necessary libraries
require ('../../fpdf/fpdf.php');

// Start the session to access session variables
session_start();

// Check if the moderator is logged in
if (!isset($_SESSION['mod_id'])) {
    header("Location: ../index.php");
    exit;
}

// Database connection
include ("../../include/connection.php");

// Get parameters from the form
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];
$mod_id = $_SESSION['mod_id'];

// Fetch the moderator's hostel and block ID
$sqlAssignment = "SELECT m.hostel_id, m.block_id, h.hostel FROM tblmoderator m INNER JOIN tblhostels h ON m.hostel_id = h.id INNER JOIN tblblocks b ON m.block_id WHERE m.mod_id = '$mod_id'";
$resultAssignment = mysqli_query($connect, $sqlAssignment);
$rowAssignment = mysqli_fetch_assoc($resultAssignment);
$hostel_id = $rowAssignment['hostel_id'];
$block_id = $rowAssignment['block_id'];
$hostelName = $rowAssignment['hostel'];
$blockName = $rowAssignment['block_id'];

// Query to get the attendance records
if ($block_id) {
    // Fetch attendance records based on block ID and hostel ID
    $sql = "SELECT a.attendance_id, s.surname, s.othernames, s.matricNumber, s.roomNo, s.bedSpace, p.program_name, a.attendance_status, a.attendance_date, a.timestamp
    FROM tblattendance AS a
    JOIN tblstudents AS s ON a.student_id = s.student_id
    JOIN tblprograms p ON a.program_id = p.program_id
            WHERE a.attendance_date BETWEEN '$start_date' AND '$end_date'
            AND a.mod_id = '$mod_id' AND s.block = '$block_id' AND s.hostel_id = '$hostel_id'";
} else {
    // Fetch attendance records based only on hostel ID
    $sql = "SELECT a.attendance_id, s.surname, s.othernames, s.matricNumber, s.roomNo, s.bedSpace, p.program_name, a.attendance_status, a.attendance_date, a.timestamp
            FROM tblattendance AS a
            JOIN tblstudents AS s ON a.student_id = s.student_id
            JOIN tblprograms p ON a.program_id = p.program_id
            WHERE a.attendance_date BETWEEN '$start_date' AND '$end_date'
            AND a.mod_id = '$mod_id' AND s.hostel_id = '$hostel_id'";
}

// Execute the query
$result = mysqli_query($connect, $sql);

// PDF creation using FPDF library
$pdf = new FPDF('L'); // 'L' for landscape orientation
$pdf->AddPage();

// Set logo as header aligned with hostel name
$pdf->Image('../../img/logo.png', 10, 2, 20);

// Set hostel name as the heading
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 10, $hostelName . ' Block ' . $blockName, 0, 1, 'C');

// Set table headers with styling
$pdf->SetFont('Helvetica', 'B', 14);
$pdf->SetFillColor(100, 100, 100); // Light blue
$pdf->SetTextColor(0, 0, 0); // Black

// Header row
$pdf->SetTextColor($fill ? 255 : 255, $fill ? 255 : 255, $fill ? 255 : 255);
$pdf->Cell(20, 10, 'S/N', 1, 0, 'C', true);
$pdf->Cell(45, 10, 'SURNAME', 1, 0, 'C', true);
$pdf->Cell(45, 10, 'OTHERNAMES', 1, 0, 'C', true);
$pdf->Cell(37, 10, 'MATRIC NO.', 1, 0, 'C', true);
$pdf->Cell(52, 10, 'PROGRAM', 1, 0, 'C', true);
$pdf->Cell(28, 10, 'STATUS', 1, 0, 'C', true);
$pdf->Cell(30, 10, 'DATE', 1, 0, 'C', true);
$pdf->Cell(22, 10, 'TIME', 1, 1, 'C', true);

// Set table rows with alternating colors and styling
$pdf->SetFont('Arial', '', 14);
$fill = false;
$counter = 1; // Initialize counter variable
while ($row = mysqli_fetch_assoc($result)) {
    // Define attendance status text
    $attendanceStatus = $row['attendance_status'] == 1 ? 'Present' : 'Absent';

    // Alternate row color
    $pdf->SetTextColor(0, 0, 0);
    $pdf->SetFillColor($fill ? 216 : 1, $fill ? 216 : 1, $fill ? 216 : 240);
    $pdf->Cell(20, 10, $counter++, 1, 0, 'C', $fill);
    $pdf->Cell(45, 10, $row['surname'], 1, 0, 'C', $fill);
    $pdf->Cell(45, 10, $row['othernames'], 1, 0, 'C', $fill);
    $pdf->Cell(37, 10, $row['matricNumber'], 1, 0, 'C', $fill);
    $pdf->Cell(52, 10, $row['program_name'], 1, 0, 'C', $fill);
    $pdf->Cell(28, 10, $attendanceStatus, 1, 0, 'C', $fill); // Display attendance status text
    $pdf->Cell(30, 10, $row['attendance_date'], 1, 0, 'C', $fill);
    $pdf->Cell(22, 10, $row['timestamp'], 1, 1, 'C', $fill);
    $fill = !$fill; // Toggle fill color for alternating rows
}
// Output PDF
$pdf->Output();
?>