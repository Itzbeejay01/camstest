<?php
session_start();

// Check if moderator is logged in
if (!isset($_SESSION['mod_id'])) {
    echo "error: moderator not logged in";
    exit;
}

// Include database connection
include ("../../include/connection.php");

// Get moderator ID and program ID
$mod_id = $_SESSION['mod_id'];
$program_id = isset($_POST['program_id']) ? $_POST['program_id'] : null; // Ensure program_id is set

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && $program_id !== null) {
    // Get current date
    $current_date = date("Y-m-d H:i:s");

    // Get student IDs, attendance status, and timestamps
    $student_ids = isset($_POST['student_ids']) ? $_POST['student_ids'] : [];
    $attendance = isset($_POST['attendance']) ? $_POST['attendance'] : [];
    $timestamps = isset($_POST['timestamp']) ? $_POST['timestamp'] : [];

    // Insert new attendance records for each student and program
    foreach ($student_ids as $student_id) {
        $is_present = in_array($student_id, $attendance) ? 1 : 0;

        // Check if timestamp is available for this student
        $timestamp = isset($timestamps[$student_id]) ? $timestamps[$student_id] : $current_date;

        $sql_insert_attendance = "INSERT INTO tblattendance (student_id, mod_id, attendance_status, attendance_date, program_id, timestamp) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt_insert_attendance = mysqli_prepare($connect, $sql_insert_attendance);
        mysqli_stmt_bind_param($stmt_insert_attendance, "iiisis", $student_id, $mod_id, $is_present, $current_date, $program_id, $timestamp);
        if (mysqli_stmt_execute($stmt_insert_attendance)) {
            // Successfully inserted attendance record
            mysqli_stmt_close($stmt_insert_attendance);
        } else {
            // Error inserting attendance record
            echo "error: " . mysqli_error($connect);
            exit;
        }
    }

    // Return success response
    header('Location: ../attendance_taken.php');
} else {
    // Return error response if accessed directly without form submission or without program_id
    echo "error: invalid request";
}
?>