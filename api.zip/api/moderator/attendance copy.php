<?php
session_start();
// Check if moderator is logged in
if (!isset($_SESSION['mod_id'])) {
    header("location: index.php");
    exit;
}
if (!isset($_SESSION['startTime'])) {
    $_SESSION['startTime'] = time(); // Set start time in seconds
}
// Include database connection
include ("../include/connection.php");
// Fetch moderator's assignment
$mod_id = $_SESSION['mod_id'];
$sql = "SELECT hostel_id, block_id FROM tblmoderator WHERE mod_id = $mod_id";
$result = mysqli_query($connect, $sql);
$row = mysqli_fetch_assoc($result);

if ($row['hostel_id'] && $row['block_id']) {
    // If moderator is assigned to both hostel and block, fetch students of that block in that hostel
    $hostel_id = $row['hostel_id'];
    $block_id = $row['block_id'];
    // Modify the SQL query to fetch the leave_request field along with other student data
    $sql_students = "SELECT s.*, e.start_date, e.end_date, CONCAT('../uploads/', s.matricNumber, '.') AS image_path
    FROM tblstudents s
    LEFT JOIN tblexeat e ON s.student_id = e.student_id
    WHERE s.hostel_id = $hostel_id AND s.block = $block_id";
} elseif ($row['hostel_id']) {
    // If moderator is assigned to only a hostel, fetch students of that hostel
    $hostel_id = $row['hostel_id'];
    $sql_students = "SELECT s.*, e.start_date, e.end_date, CONCAT('../uploads/', s.matricNumber, '.') AS image_path
    FROM tblstudents s
    LEFT JOIN tblexeat e ON s.student_id = e.student_id
    WHERE s.hostel_id = $hostel_id";
}

$result_students = mysqli_query($connect, $sql_students);
// Check if attendance has already been marked for the current program and date
$program_id = isset($_GET['program_id']) ? $_GET['program_id'] : '';
$current_date = date('Y-m-d');
$sql_check_attendance = "SELECT * FROM tblattendance WHERE mod_id = $mod_id AND program_id = $program_id AND attendance_date = '$current_date'";
$result_check_attendance = mysqli_query($connect, $sql_check_attendance);
if (mysqli_num_rows($result_check_attendance) > 0) {
    // Redirect or display a message indicating that attendance has already been marked for today's program
    // For example:
    header("location: isnotattendance.php");
    exit;
}
?><!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Moderator:: Attendance</title>
    <link rel="stylesheet" href="../dist/output.css">
    <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
</head>
<style>
    .student-container {
        display: flex;
    }

    .student-info {
        display: flex;
        align-items: center;
    }

    .student-image {
        width: 80px;
        height: auto;
        border-radius: 50%;
    }
</style>

<body class="w-full lg:flex-row lg:min-h-100vh lg:flex bg-gray-100 ">
    <?php include 'include/header.php'; ?>
    <div class="lg:flex-1 pc-view-padding">
        <div class="text-lg text-center font-bold text-green-800 py-4 bg-white shadow-lg rounded hidden lg:block">
            JABU_CAMS - ATTENDANCE</div>
    <div class="container w-full mt-3 flex flex-col px-2">
        <form action="include/mark_attendance.php" method="POST" id="attendanceForm"
            class="shadow-lg px-2 rounded-lg py-2 backdrop-blur-sm">
            <input type="hidden" name="program_id"
                value="<?php echo isset($_GET['program_id']) ? $_GET['program_id'] : ''; ?>">
            <div class="flex justify-center">
                <input type="text" name="search" id="searchInput" placeholder="Search by Room No"
                    class="px-4 py-2 border-2 border-green-500 rounded-lg outline-none">
            </div>
            <div class="text-lg mt-2 font-semibold text-green-800 text-center">Timer: &ThickSpace;<span id="countdown"
                    class="text-green-800"></span></div>
            <!-- Display Students -->
            <div class="student-list w-full">
                <?php while ($student = mysqli_fetch_assoc($result_students)): ?>
                    <div class="student-container bg-white mb-4 w-full px-4 py-4 rounded-lg shadow-lg">
                        <div class="mx-4">
                            <?php
                            // Construct the image tag
                            $image_extensions = ['jpg', 'jpeg', 'png'];
                            $image_found = false;
                            foreach ($image_extensions as $ext) {
                                $image_file = $student['image_path'] . $ext;
                                if (file_exists($image_file)) {
                                    echo '<img src="' . $image_file . '" alt="Student Image" class="rounded-2xl" style="width:85px; height:90px; display: block; margin: 0 auto;">';
                                    $image_found = true;
                                    break;
                                }
                            }
                            if (!$image_found) {
                                echo 'Image Not Available';
                            }
                            ?>
                        </div>
                        <div class="student-info px-4">
                            <div class="flex flex-col font-bold">
                                <span class="py-2">Room No: <?php echo $student['roomNo']; ?></span>
                                <span>Space: <?php echo $student['bedSpace']; ?></span>
                            </div>
                        </div>
                        <input type="hidden" name="student_ids[]" value="<?php echo $student['student_id']; ?>">
                        <div class="student-info mx-4">
                            <?php
                            // Check if student's leave status is available
                            $leave_status = ($student['start_date'] && $student['end_date'] && strtotime($student['start_date']) <= time() && strtotime($student['end_date']) >= time()) ? 'checked onclick="return false" ' : '';
                            echo "<input class='w-9 h-9' type='checkbox' name='attendance[]' value='{$student['student_id']}' $leave_status>";
                            ?>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
            <div class="flex justify-center lg:px-0 px-8">
                <button type="submit"
                    class=" lg:w-1/2 w-full mt-3 bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-8 rounded-full">Submit
                </button>
            </div>
        </form>
    </div>
    <!-- FOOTER -->
    <div class="w-full shadow-gray-200 py-4 flex items-center justify-center lg:mt-52 lg:py-6">
        <p class="text-md font-medium text-black"> &copy; Copyright
            <script>
                document.write(new Date().getFullYear());
            </script>. Created by &ThinSpace;BeeTechHub
        </p>
    </div>
</body>

</html>
<script>
    // Get the input element
    var input = document.getElementById("searchInput");
    // Add event listener for input event
    input.addEventListener("input", function (event) {
        var filter, studentContainers, i, txtValue;
        filter = event.target.value.toUpperCase();
        studentContainers = document.querySelectorAll(".student-container");

        // Loop through all student containers, hide those that don't match the search query
        studentContainers.forEach(function (container) {
            var roomNoElement = container.querySelector("span");
            txtValue = roomNoElement.textContent || roomNoElement.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                container.style.display = "";
            } else {
                container.style.display = "none";
            }
        });
    });
</script>

<script>
    //FOR TIME
    function updateDateTime() {
        const dateTimeElement = document.getElementById('currentDateTime');
        const now = new Date();
        const date = now.toLocaleDateString();
        const time = now.toLocaleTimeString();
        dateTimeElement.textContent = `Date: ${date} | Time: ${time}`;
    }

    // Update the date and time every second
    setInterval(updateDateTime, 1000);

    // Initial call to display the date and time
    updateDateTime();
</script>
<script>
    document.getElementById('toggleButton').addEventListener('click', function () {
        document.getElementById('sidebar').classList.toggle('hidden');
    });
</script>
<script>
    document.getElementById('dropdown-button').addEventListener('click', function () {
        var menu = document.getElementById('dropdown-menu');
        if (menu.classList.contains('hidden')) {
            menu.classList.remove('hidden');
        } else {
            menu.classList.add('hidden');
        }
    });

    document.addEventListener('click', function (event) {
        var menu = document.getElementById('dropdown-menu');
        var button = document.getElementById('dropdown-button');
        if (!menu.contains(event.target) && event.target !== button) {
            menu.classList.add('hidden');
        }
    });

</script>
<script src="/js/adminscript.js"></script>
<script>
    // Function to start the countdown timer
    function startTimer(duration) {
        var timer = duration;
        var countdownDisplay = document.getElementById('countdown');

        var interval = setInterval(function () {
            var minutes = Math.floor(timer / 60);
            var seconds = timer % 60;

            minutes = minutes < 10 ? '0' + minutes : minutes;
            seconds = seconds < 10 ? '0' + seconds : seconds;

            countdownDisplay.textContent = minutes + ':' + seconds;

            if (timer <= 180) { // Change color to red and start blinking when 3 minutes remaining
                countdownDisplay.classList.add('warning');
            }

            if (--timer < 0) {
                clearInterval(interval);
                countdownDisplay.textContent = 'Time\'s up!';
                // Auto-submit form
                document.getElementById('attendanceForm').submit();
                // Reset session and restart timer
                <?php unset($_SESSION['startTime']); ?> // Reset startTime in session
                var programId = <?php echo isset($_GET['program_id']) ? $_GET['program_id'] : 0; ?>;
                var timerDuration = programId == 1 ? 600 : 1800; // 10 minutes for program ID 1, 30 minutes otherwise
                startTimer(timerDuration);
            }
        }, 1000);
    }

    // Check if countdown has been started before
    var startTime = <?php echo isset($_SESSION['startTime']) ? $_SESSION['startTime'] : 0; ?>;
    if (startTime) {
        var currentTime = Math.floor(Date.now() / 1000); // in seconds
        var timeElapsed = currentTime - startTime;
        var programId = <?php echo isset($_GET['program_id']) ? $_GET['program_id'] : 0; ?>;
        var timerDuration = programId == 1 ? 600 : 1800; // 10 minutes for program ID 1, 30 minutes otherwise
        var timeRemaining = Math.max(0, timerDuration - timeElapsed);
        startTimer(timeRemaining);
    } else {
        // Start countdown for the first time
        var programId = <?php echo isset($_GET['program_id']) ? $_GET['program_id'] : 0; ?>;
        var timerDuration = programId == 1 ? 600 : 1800; // 10 minutes for program ID 1, 30 minutes otherwise
        startTimer(timerDuration);
    }
    // Clear session when the form is submitted
    document.getElementById('attendanceForm').addEventListener('submit', function () {
        <?php unset($_SESSION['startTime']); ?> // Reset startTime in session
    });
</script>