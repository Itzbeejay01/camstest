<?php
// Start the session
session_start();

// Include the file with database connection parameters
include ("../include/connection.php");

// Sanitize the input to prevent SQL injection
$pageId = $connect->real_escape_string('program');

// Query database for page status
$sql = "SELECT status FROM page_status WHERE page_id = '$pageId'";
$result = $connect->query($sql);

if ($result && $result->num_rows > 0) {
    // Fetch the first row
    $row = $result->fetch_assoc();
    $status = $row["status"];

    // Check if the page is disabled
    if ($status === 'disabled') {
        // If the page is disabled, show a message and exit
        header('Location: disabled.php');
        exit; // Stop further execution of the script
    }
} else {
    // If status is not found, display an error message
    echo "Status not found.";
}
?>
<?php
// Check if moderator is logged in
if (!isset($_SESSION['mod_id'])) {
    header("location: index.php");
    exit;
}
// Include database connection
include ("../include/connection.php");

// Fetch moderator's assignment
$mod_id = $_SESSION['mod_id'];
$sql = "SELECT hostel_id, block_id FROM tblmoderator WHERE mod_id = $mod_id";
$result = mysqli_query($connect, $sql);
$row = mysqli_fetch_assoc($result);

if ($row['hostel_id'] && $row['block_id']) {
    // If moderator is assigned to both hostel and block, fetch students of that block in that hostel
    $hostel_id = $row['hostel_id'];
    $block_id = $row['block_id'];
    // Modify the SQL query to fetch the leave_request field along with other student data
    $sql_students = "SELECT s.*, e.start_date, e.end_date, CONCAT('../uploads/', s.matricNumber, '.') AS image_path
    FROM tblstudents s
    LEFT JOIN tblexeat e ON s.student_id = e.student_id
    WHERE s.hostel_id = $hostel_id AND s.block = $block_id";


} elseif ($row['hostel_id']) {
    // If moderator is assigned to only a hostel, fetch students of that hostel
    $hostel_id = $row['hostel_id'];
    $sql_students = "SELECT s.*, e.start_date, e.end_date, CONCAT('../uploads/', s.matricNumber, '.') AS image_path
    FROM tblstudents s
    LEFT JOIN tblexeat e ON s.student_id = e.student_id
    WHERE s.hostel_id = $hostel_id";
}

$result_students = mysqli_query($connect, $sql_students);
?><!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Moderator:: Program</title>
    <link rel="stylesheet" href="../dist/output.css">
    <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
</head>

<body class="w-full lg:flex-row lg:min-h-100vh lg:flex bg-gray-100 ">
    <?php include 'include/header.php'; ?>
    <div class="lg:flex-1 pc-view-padding">
        <div class="text-lg text-center font-bold text-green-800 py-4 bg-white shadow-lg rounded hidden lg:block">
            JABU_CAMS - PROGRAM</div>
    <div class="px-4 lg:px-32 lg:py-4">
        <div class="bg-white p-8 rounded-lg shadow-lg lg:mx-auto ">
            <!-- Display Hostel and Block assigned to Moderator -->
            <div class="bg-inherit backdrop-blur-md shadow-lg text-center text-black py-2 px-4 rounded-lg mb-2">
                <?php
                if (isset($_SESSION['mod_id'])) {
                    // Include database connection
                    include ("../include/connection.php");

                    // Fetch moderator's assignment
                    $mod_id = $_SESSION['mod_id'];
                    $sql = "SELECT m.hostel_id, m.block_id, h.hostel 
                FROM tblmoderator m
                LEFT JOIN tblhostels h ON m.hostel_id = h.id
                WHERE m.mod_id = $mod_id";
                    $result = mysqli_query($connect, $sql);
                    $row = mysqli_fetch_assoc($result);

                    // Concatenate assigned hostel and block
                    $assignment = '';
                    if (!empty($row['hostel_id'])) {
                        $assignment .= 'Assigned Hostel: ' . $row['hostel'];
                    }
                    if (!empty($row['block_id'])) {
                        $assignment .= ' Block: ' . $row['block_id'];
                    }

                    // Display concatenated assignment
                    if (!empty($assignment)) {
                        echo '<div class="text-sm font-semibold">' . $assignment . '</div>';
                    }
                }
                ?>
            </div>
            <h2 class="text-2xl font-semibold mb-4 text-green-800 my-6">Program</h2>
            <form id="programForm" method="POST">
                <!-- Fetch program list from database and display as dropdown -->
                <div class="w-full mb-4">
                    <select id="program" name="program_id"
                        class="mt-1 block w-full p-2 border border-gray-300 rounded-md outline-none focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        required>
                        <option value="" disabled selected>Select Program</option>
                        <?php
                        // Connect to the database and fetch program list
                        include ("../include/connection.php");
                        $sql = "SELECT program_id, program_name FROM tblprograms";
                        $result = mysqli_query($connect, $sql);
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo '<option value="' . $row['program_id'] . '">' . $row['program_name'] . '</option>';
                        }
                        ?>
                    </select>
                </div>
                <button type="submit"
                    class="w-full text-lg mt-6 bg-green-500 text-white py-2 px-4 font-bold rounded-full hover:bg-green-700">Submit</button>
            </form>
        </div>
    </div>
    <!-- FOOTER -->
    <?php include 'include/footer.php' ?>
</body>

</html>
<script>
    // JavaScript to handle form submission
    document.getElementById('programForm').addEventListener('submit', function (event) {
        // Prevent the default form submission behavior
        event.preventDefault();

        // Get the selected program ID from the dropdown
        var programId = document.getElementById('program').value;

        // Construct the URL with the selected program ID as a parameter
        var url = 'attendance.php?program_id=' + programId;

        // Redirect to the next page with the program ID as a parameter
        window.location.href = url;
    });
</script>
<script>
    // <!--Include JavaScript to handle checkbox selection-->
    // Get all checkboxes
    const checkboxes = document.querySelectorAll('input[type="checkbox"]');

    // Add event listener to each checkbox
    checkboxes.forEach((checkbox) => {
        checkbox.addEventListener('change', function () {
            // If checkbox is checked, uncheck other checkboxes
            if (this.checked) {
                checkboxes.forEach((otherCheckbox) => {
                    if (otherCheckbox !== checkbox) {
                        otherCheckbox.checked = false;
                    }
                });
            }
        });
    });

    //FOR TIME
    function updateDateTime() {
        const dateTimeElement = document.getElementById('currentDateTime');
        const now = new Date();
        const date = now.toLocaleDateString();
        const time = now.toLocaleTimeString();
        dateTimeElement.textContent = `Date: ${date} | Time: ${time}`;
    }

    // Update the date and time every second
    setInterval(updateDateTime, 1000);

    // Initial call to display the date and time
    updateDateTime();
</script>
<script>
    document.getElementById('toggleButton').addEventListener('click', function () {
        document.getElementById('sidebar').classList.toggle('hidden');
    });
</script>
<script>
    document.getElementById('dropdown-button').addEventListener('click', function () {
        var menu = document.getElementById('dropdown-menu');
        if (menu.classList.contains('hidden')) {
            menu.classList.remove('hidden');
        } else {
            menu.classList.add('hidden');
        }
    });

    document.addEventListener('click', function (event) {
        var menu = document.getElementById('dropdown-menu');
        var button = document.getElementById('dropdown-button');
        if (!menu.contains(event.target) && event.target !== button) {
            menu.classList.add('hidden');
        }
    });
</script>
<script src="/js/adminscript.js"></script>