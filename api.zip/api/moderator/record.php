<?php
session_start();
if (!isset($_SESSION['mod_id'])) {
  header("Location: ../index.php");
  exit;
}
?><!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Moderator:: Record</title>
  <link rel="stylesheet" href="../dist/output.css">
  <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon">
  <link rel="stylesheet"
    href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
</head>

<body class="w-full lg:flex-row lg:min-h-100vh lg:flex bg-gray-100 ">
  <?php include 'include/header.php'; ?>
  <div class="lg:flex-1 pc-view-padding">
    <div class="text-lg text-center font-bold text-green-800 py-4 bg-white shadow-lg rounded hidden lg:block">
      JABU_CAMS - RECORD</div>
    <?php
    // Get mod_id from session
    $mod_id = $_SESSION['mod_id'];

    // Database connection parameters
    include("../include/connection.php");

    // Check if form is submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
      $start_date = $_POST["start_date"];
      $end_date = $_POST["end_date"];

      // SQL query to fetch attendance records within the specified date range and for the given mod_id
      $sql = "SELECT a.attendance_id, s.surname, s.othernames, s.matricNumber, a.attendance_status, a.attendance_date
                FROM tblattendance AS a
                JOIN tblstudents AS s ON a.student_id = s.student_id
                WHERE a.attendance_date BETWEEN '$start_date' AND '$end_date'
                AND a.mod_id = $mod_id";
      $result = $connect->query($sql);
    }
    ?>
    <div class="w-full p-2 rounded lg:px-64 lg:py-5">
      <div
        class="w-full shadow-sm bg-inherit backdrop-blur-md rounded-md py-4 px-6 flex flex-col items-center justify-center"
        style="box-shadow: 0 2px 10px gray;">
        <h1 class="text-xl font-semibold mb-4 text-green-800">All Student Attendance Report</h1>
        <form method="post" class="w-full mb-5 flex flex-col items-center justify-center" action="include/view.php">
          <div class="w-full mb-4">
            <label class="block text-green-800 text-sm font-bold mb-2" for="start_date">Start Date:</label>
            <input
              class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              type="date" name="start_date" id="start_date" required>
          </div>
          <div class="w-full mb-4">
            <label class="block text-green-800 text-sm font-bold mb-2" for="end_date">End Date:</label>
            <input
              class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              type="date" name="end_date" id="end_date" required>
          </div>
          <div class="w-full text-center">
            <button
              class="w-full bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline flex items-center justify-center"
              type="submit"> <span class="material-symbols-outlined text-white px-2">visibility</span>View
              Report</button>
          </div>
          <p class="mt-2"><a class="text-green-600" href="studentattendance.php">Click here</a> to view individual
            student
            record.</p>

        </form>
      </div>

      <?php
      // Display attendance records if available
      if ($_SERVER["REQUEST_METHOD"] == "POST" && $result && $result->num_rows > 0) {
        echo "<h2 class='text-lg font-semibold mt-8 mb-4'>Attendance Records:</h2>";
        echo "<table class='w-full text-sm bg-gray-100'>";
        echo "<thead class='w-full text-sm bg-gray-600 text-gray-50'>
            <tr>
            <th class='border px-2 py-2'>Surname</th>
            <th class='border px-2 py-2'>Othername</th>
            <th class='border px-2 py-2'>Matric Number</th>
            <th class='border px-2 py-2'>Status</th>
            <th class='border px-2 py-2'>Date</th>
            </tr>
            </thead>
            <tbody>";
        while ($row = $result->fetch_assoc()) {
          echo "<tr>
                <td class='border px-2 py-2'>" . $row["surname"] . "</td>
                <td class='border px-2 py-2'>" . $row["othernames"] . "</td>
                <td class='border px-2 py-2'>" . $row["matricNumber"] . "</td>
                <td class='border px-2 py-2'>" . $row["attendance_status"] . "</td>
                <td class='border px-2 py-2'>" . $row["attendance_date"] . "</td></tr>";
        }
        echo "</tbody></table>";
      } elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
        echo "<p class='text-red-500 mt-4'>No attendance records found within the specified date range.</p>";
      }
      ?>

    </div>
  </div>
  </div>
  </div>
  <!-- SCRIPTS -->
  <script src="/js/adminscript.js"></script>
  <script>
    function updateDateTime() {
      const dateTimeElement = document.getElementById('currentDateTime');
      const now = new Date();
      const date = now.toLocaleDateString();
      const time = now.toLocaleTimeString();
      dateTimeElement.textContent = `Date: ${date} | Time: ${time}`;
    }

    // Update the date and time every second
    setInterval(updateDateTime, 1000);

    // Initial call to display the date and time
    updateDateTime();
  </script>
  <script>
    document.getElementById('toggleButton').addEventListener('click', function () {
      document.getElementById('sidebar').classList.toggle('hidden');
    });
  </script>
  <script>
    document.getElementById('dropdown-button').addEventListener('click', function () {
      var menu = document.getElementById('dropdown-menu');
      if (menu.classList.contains('hidden')) {
        menu.classList.remove('hidden');
      } else {
        menu.classList.add('hidden');
      }
    });

    document.addEventListener('click', function (event) {
      var menu = document.getElementById('dropdown-menu');
      var button = document.getElementById('dropdown-button');
      if (!menu.contains(event.target) && event.target !== button) {
        menu.classList.add('hidden');
      }
    });
  </script>

</html>