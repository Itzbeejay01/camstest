<?php
session_start();
// Check if moderator is logged in
if (!isset($_SESSION['mod_id'])) {
    header("location: index.php");
    exit;
}
// Include database connection
include ("../include/connection.php");

// Fetch moderator's hostel and assigned students
$mod_id = $_SESSION['mod_id'];
$sql = "SELECT * FROM tblmoderator WHERE mod_id = $mod_id";
$result = mysqli_query($connect, $sql);
$row = mysqli_fetch_assoc($result);
$hostel_id = $row['hostel_id'];

// Fetch students assigned to the moderator's hostel
$sql_students = "SELECT * FROM tblstudents WHERE hostel_id = $hostel_id";
$result_students = mysqli_query($connect, $sql_students);
?><!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Moderator Dashboard</title>
    <link rel="stylesheet" href="../dist/output.css">
    <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />

</head>

<body class="w-full max-h-full lg:flex">
    <?php include 'include/header.php'; ?>
    <div class="container w-full  mt-3 flex flex-col items-center">

        <!-- Attendance Form -->
        <form method="post" action="include/mark_attendance.php"
            class="w-full h-full px-2 py-2 shadow-lg flex flex-col backdrop-blur-sm items-center" id="attendanceForm">
            <!-- Display Students -->
            <?php include 'include/mark_attendance.php'; ?>

            <table class="w-full text-center object-center" id="data-table">
                <thead class="bg-gray-600 text-gray-50">
                    <tr>
                        <th class="px-2 py-2">#</th>
                        <th class="px-2 py-2">Surname</th>
                        <th class="px-2 py-2">Othername</th>
                        <th class="px-2 py-2">Matric No</th>
                        <th class="px-2 py-2">Room No</th>
                        <th class="px-2 py-2">Bed No</th>
                    </tr>
                </thead>
                <tbody id="studentTableBody">
                    <?php while ($student = mysqli_fetch_assoc($result_students)): ?>
                        <tr>
                            <td class="border px-2 py-2"><?php echo $student['surname']; ?></td>
                            <td class="border px-2 py-2"><?php echo $student['othernames']; ?></td>
                            <td class="border px-2 py-2"><?php echo $student['matricNumber']; ?></td>
                            <td class="border px-2 py-2"><?php echo $student['roomNo']; ?></td>
                            <td class="border px-2 py-2"><?php echo $student['bedSpace']; ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            <button type="submit"
                class=" w-3/4 mt-5 bg-gray-600 hover:bg-gray-900 text-white font-bold py-2 px-4 rounded">Download as
                PDF</button>
        </form>
    </div>
    <!-- FOOTER -->

    <div class="w-full shadow-gray-200 py-4 flex items-center justify-center lg:mt-52 lg:py-6">
        <p class="text-md font-medium text-black"> &copy; Copyright
            <script>
                document.write(new Date().getFullYear());

            </script>. Created by &ThinSpace;BeeTechHub
        </p>
    </div>

    </div>
    </div>

    </div>
</body>

</html>
<script>
    // Function to confirm form submission
    function confirmSubmit() {
        if (confirm("Are you sure you want to submit the attendance?")) {
            document.getElementById("attendanceForm").submit();
        }
    }

    // Get the input element
    var input = document.getElementById("searchInput");

    // Add event listener for input event
    input.addEventListener("input", function (event) {
        var filter, table, tbody, tr, td, i, txtValue;
        filter = event.target.value.toUpperCase();
        table = document.querySelector("table");
        tbody = table.querySelector("tbody");
        tr = tbody.getElementsByTagName("tr");

        // Loop through all table rows, hide those that don't match the search query
        for (i = 0; i < tr.length; i++) {
            td = tr[i].getElementsByTagName("td")[0]; // Column index for Room No
            if (td) {
                txtValue = td.textContent || td.innerText;
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                } else {
                    tr[i].style.display = "none";
                }
            }
        }
    });
</script>
<!-- SCRIPTS -->
<script src="../js/number.js"></script>
<script>
    function updateDateTime() {
        const dateTimeElement = document.getElementById('currentDateTime');
        const now = new Date();
        const date = now.toLocaleDateString();
        const time = now.toLocaleTimeString();
        dateTimeElement.textContent = `Date: ${date} | Time: ${time}`;
    }

    // Update the date and time every second
    setInterval(updateDateTime, 1000);

    // Initial call to display the date and time
    updateDateTime();
</script>
<script>
    document.getElementById('toggleButton').addEventListener('click', function () {
        document.getElementById('sidebar').classList.toggle('hidden');
    });
</script>
<script>
    document.getElementById('dropdown-button').addEventListener('click', function () {
        var menu = document.getElementById('dropdown-menu');
        if (menu.classList.contains('hidden')) {
            menu.classList.remove('hidden');
        } else {
            menu.classList.add('hidden');
        }
    });

    document.addEventListener('click', function (event) {
        var menu = document.getElementById('dropdown-menu');
        var button = document.getElementById('dropdown-button');
        if (!menu.contains(event.target) && event.target !== button) {
            menu.classList.add('hidden');
        }
    });
</script>