<?php
session_start();
// Check if moderator is logged in
if (!isset($_SESSION['mod_id'])) {
  header("location: index.php");
  exit;
}
?><!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Page Disabled</title>
  <link rel="stylesheet" href="../dist/output.css">
  <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon">
  <link rel="stylesheet"
    href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />

</head>

<body class="w-full max-h-full lg:flex bg-gray-100 ">
  <?php include 'include/header.php'; ?>
  <div class="w-full px-4 py-12">
    <div class="bg-inherit backdrop-blur-sm p-8 rounded shadow-lg text-center mt-7">
      <h1 class="text-2xl font-bold text-red-600 mb-4">This page is currently disabled. Please check back later.</h1>
      <p class="text-gray-600 mb-4">You will be redirected <a href="moderator/index.php" class="text-green-600"></a> in
        <span id="countdown">10</span> seconds.</p>
      <p class="text-gray-600">If you are not redirected, please click <a href="index.php"
          class="text-green-600">here</a>.</p>
    </div>
  </div>
  <script>
    let timeLeft = 10;
    const countdown = document.getElementById('countdown');

    const timer = setInterval(() => {
      timeLeft--;
      countdown.textContent = timeLeft;

      if (timeLeft <= 0) {
        clearInterval(timer);
        window.location.href = 'index.php';
      }
    }, 1000);
  </script>
  <?php include 'include/footer.php' ?>

  <!-- SCRIPTS -->
  <script src="/js/adminscript.js"></script>
  <script src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons.js"></script>
  <script>
    function updateDateTime() {
      const dateTimeElement = document.getElementById('currentDateTime');
      const now = new Date();
      const date = now.toLocaleDateString();
      const time = now.toLocaleTimeString();
      dateTimeElement.textContent = `Date: ${date} | Time: ${time}`;
    }

    // Update the date and time every second
    setInterval(updateDateTime, 1000);

    // Initial call to display the date and time
    updateDateTime();
  </script>
  <script>
    document.getElementById('toggleButton').addEventListener('click', function () {
      document.getElementById('sidebar').classList.toggle('hidden');
    });
  </script>
  <script>
    document.getElementById('dropdown-button').addEventListener('click', function () {
      var menu = document.getElementById('dropdown-menu');
      if (menu.classList.contains('hidden')) {
        menu.classList.remove('hidden');
      } else {
        menu.classList.add('hidden');
      }
    });

    document.addEventListener('click', function (event) {
      var menu = document.getElementById('dropdown-menu');
      var button = document.getElementById('dropdown-button');
      if (!menu.contains(event.target) && event.target !== button) {
        menu.classList.add('hidden');
      }
    });
  </script>
</body>

</html>