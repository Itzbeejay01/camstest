
// Function to start the countdown timer
function startTimer(duration) {
  var timer = duration;
  var countdownDisplay = document.getElementById('countdown');

  var interval = setInterval(function () {
    var minutes = Math.floor(timer / 60);
    var seconds = timer % 60;

    minutes = minutes < 10 ? '0' + minutes : minutes;
    seconds = seconds < 10 ? '0' + seconds : seconds;

    countdownDisplay.textContent = minutes + ':' + seconds;

    if (timer <= 180) { // Change color to red and start blinking when 3 minutes remaining
      countdownDisplay.classList.add('warning');
    }

    if (--timer < 0) {
      clearInterval(interval);
      countdownDisplay.textContent = 'Time\'s up!';
      // Auto-submit form
      document.getElementById('myForm').submit();
    }
  }, 1000);
}

// Check if countdown has been started before
var startTime = localStorage.getItem('startTime');
if (startTime) {
  var currentTime = Math.floor(Date.now() / 1000); // in seconds
  var timeElapsed = currentTime - startTime;
  var timeRemaining = Math.max(0, 300 - timeElapsed); // 5 minutes countdown
  startTimer(timeRemaining);
} else {
  // Start countdown for the first time
  localStorage.setItem('startTime', Math.floor(Date.now() / 1000));
  startTimer(300); // 5 minutes countdown
}

// Clear local storage when the form is submitted
document.getElementById('myForm').addEventListener('submit', function() {
  localStorage.removeItem('startTime');
});
