<?php
include ("../include/connection.php");
session_start();
if (!isset($_SESSION["username"])) {
    header("Location: ../index.php");
    exit;
}
?><!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin: Add Moderator</title>
    <link rel="stylesheet" href="../dist/output.css">
    <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <!-- Include DataTables CSS -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
    <!-- Include jQuery and DataTables JavaScript -->
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#moderators-table').DataTable();
        });
    </script>
    <script>
        $(document).ready(function () {
            $('#swapAllBtn').click(function () {
                // Show the confirmation modal
                $('#confirmationModal').removeClass('hidden');
            });

            // Handle cancel swap button click inside the modal
            $('#cancelSwapBtn').click(function () {
                // Hide the modal
                $('#confirmationModal').addClass('hidden');
            });

            // Handle confirm swap button click inside the modal
            $('#confirmSwapBtn').click(function () {
                // AJAX request to initiate the swap process for all moderators
                $.ajax({
                    url: 'swap_all_moderators.php', // Replace 'swap_all_moderators.php' with your backend PHP script
                    method: 'POST',
                    success: function (response) {
                        // Hide the confirmation modal
                        $('#confirmationModal').addClass('hidden');
                        // Show the success modal
                        $('#successModal').removeClass('hidden');
                    },
                    error: function (xhr, status, error) {
                        // Handle error response
                        console.error(error);
                        alert("An error occurred. Please try again later.");
                    }
                });
            });

            // Handle close success modal button click
            $('#closeSuccessModal').click(function () {
                // Hide the success modal
                $('#successModal').addClass('hidden');
                // Refresh the page
                location.reload();
            });
        });
    </script>
</head>
<style>
    #successModal.hidden {
        display: none;
    }

    @media (min-width: 1024px) {
        .pc-view-padding {
            padding-left: 310px;
        }
    }
</style>

<body class="w-full max-h-full  bg-gray-100 ">
    <?php include 'include/header.php'; ?>
    <!-- MODERATOR REGISTRTATION DASHBOARD -->
    <div class="w-full flex flex-col px-2 lg:px-10 lg:flex-1 pc-view-padding">
        <!-- Current Time -->
        <div class="w-full flex items-center justify-center mb-1 mt-2 lg:p-0 lg:hidden">
            <div id="currentDateTime" class="text-green-950 w-2/3 p-2 rounded-xl bg-gray-50 text-sm text-center font-medium
                        shadow-gray-300 shadow-md lg:text-center lg:w-full lg:rounded-md lg:text-lg"></div>
        </div>
        <!-- Current time end here -->
        <div class="text-lg text-center font-bold text-green-800 py-4 bg-white shadow-lg rounded hidden lg:block mb-4">
        JABU_CAMS - ADD MODERATOR</div>
        <form id="moderatorform" method="post" class="w-full flex flex-col mt-3 lg:mt-0">
            <div class="flex flex-col w-full px-2">
                <?php include 'include/insertmod.php'; ?>
            </div>
            <div
                class="bg-white flex-col items-center justify-center shadow-lg py-4 shadow-gray-300 rounded-md lg:flex lg:flex-col lg:w-full lg:py-4 lg:shadow-lg lg:shadow-gray-200">
                <div class="lg:flex lg:w-full w-full">
                    <div class="mb-4 w-full lg:flex lg:w-full lg:mx-4">
                        <div class="flex flex-col w-full px-5">
                            <div class="mb-4 lg:my-3">
                                <input type="text" id="surname" name="surname"
                                    class="border-2 outline-none rounded-lg form-input mt-1 p-2 w-full lg:p-4 placeholder:text-gray-600"
                                    placeholder="Surname" required>
                            </div>
                            <div class="mb-4 lg:my-3">
                                <input type="text" id="othernames" name="othernames"
                                    class="border-2 outline-none rounded-lg form-input mt-1 p-2 w-full lg:p-4 placeholder:text-gray-600"
                                    placeholder="Other names" required>
                            </div>
                            <div class="mb-4 lg:my-3">
                                <select id="marking_for_gender" name="marking_for_gender"
                                    class="border-2 outline-none rounded-lg form-input mt-1 p-2 w-full lg:p-4 placeholder:text-gray-600"
                                    required>
                                    <option value="" disabled selected>Select Gender</option>
                                    <option value="male">Male</option>
                                    <option value="female">Female</option>
                                </select>
                            </div>
                            <div class="mb-4 lg:my-3">
                                <input type="email" id="emai" name="email"
                                    class="border-2 outline-none rounded-lg form-input mt-1 p-2 w-full lg:p-4 placeholder:text-gray-600"
                                    placeholder="Email Address" required>
                            </div>
                        </div>
                        <div class="flex flex-col w-full px-5">
                            <div class="mb-4 lg:my-3">
                                <select id="hostels" name="hostel_id"
                                    class="text-gray-500 border-2 outline-none rounded-lg  form-select mt-1 p-2 lg:p-4 w-full"
                                    required>
                                    <option value="" disabled selected>Select Hostel</option>
                                    <option value="1">Male Hostel 1</option>
                                    <option value="2">Male Hostel 2</option>
                                    <option value="3">Male Hostel 3</option>
                                    <option value="4">Male Hostel 4</option>
                                    <option value="5">Female Hostel 1</option>
                                    <option value="6">Female Hostel 2</option>
                                    <option value="7">Female Hostel 3</option>
                                    <option value="8">Female Hostel 4</option>
                                </select>
                            </div>
                            <div class="mb-4 lg:my-3" id="blockContainer" style="display: none;">
                                <select id="block" name="block_id"
                                    class="text-gray-400 border-2 outline-none rounded-lg lg:p-4 form-select mt-1 p-2 w-full">
                                    <option value="" disabled selected>Select Block</option>
                                </select>
                            </div>
                            <div class="mb-4 lg:my-3">
                                <input type="password" id="password" name="password"
                                    class="border-2 outline-none rounded-lg form-input mt-1 p-2 w-full lg:p-4 placeholder:text-gray-600"
                                    placeholder="Password" required>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="flex flex-col px-5">
                    <button name="submit" type="submit"
                        class="lg:px-32 mx-2 bg-green-500 text-white p-2 items-center rounded-full shadow-lg lg:p-3 lg:text-md lg:font-bold hover:bg-green-700">Add
                        Moderator</button>
                </div>
            </div>
        </form>
        <!-- Moderators -->
        <div class="w-full px-6 mt-5 bg-white py-4 rounded-lg">
            <div id="deleteModalTemplate"
                class="hidden fixed inset-0 z-50 justify-center items-center bg-gray-800 bg-opacity-50">
                <div class="absolute top-0 left-0 right-0 flex justify-center items-center h-full">
                    <div class="bg-white rounded-lg w-1/2 p-8 transform -translate-y-full transition-transform">
                        <h2 class="text-xl font-semibold mb-4">Confirm Deletion</h2>
                        <p class="text-gray-700 mb-4">Are you sure you want to delete this moderator?</p>
                        <div class="flex justify-end">
                            <button id="confirmDeleteBtn"
                                class="bg-red-500 text-white hover:bg-red-600 px-4 py-2 rounded mr-4">Delete</button>
                            <button id="cancelDeleteBtn"
                                class="bg-gray-200 text-gray-800 hover:bg-gray-300 px-4 py-2 rounded">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Add a Swap All Button -->
            <button id="swapAllBtn" class="bg-green-500 text-white px-8 py-2 rounded-full shadow mb-4 font-bold hover:bg-green-700">Swap
                Moderators</button>
            <!-- Modal HTML for swap start here -->
            <div id="confirmationModal"
                class="hidden fixed inset-0 z-50 justify-center items-center bg-gray-800 bg-opacity-50">
                <div class="absolute top-0 left-0 right-0 flex justify-center items-center h-full">
                    <div class="bg-white rounded-lg w-1/2 p-8 transform -translate-y-full transition-transform">
                        <h2 class="mb-4 text-lg font-semibold">Confirm Swap</h2>
                        <p class="mb-6">Are you sure you want to swap the hostel and block assignments for all
                            moderators?</p>
                        <div class="flex justify-end">
                            <button id="cancelSwapBtn"
                                class="bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-4 mr-2 rounded">Cancel</button>
                            <button id="confirmSwapBtn"
                                class="bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded">Swap
                                All</button>
                        </div>
                    </div>
                </div>
            </div>

            <div id="successModal"
                class="hidden fixed inset-0 z-50 justify-center items-center bg-gray-800 bg-opacity-50">
                <div class="absolute top-0 left-0 right-0 flex justify-center items-center h-full">
                    <div class="bg-white p-8 rounded-lg">
                        <p class="text-xl font-bold">Success!</p>
                        <p>The moderator block assignments have been swapped successfully.</p>
                        <button id="closeSuccessModal"
                            class="bg-red-500 text-white px-4 py-2 rounded shadow mt-4">Close</button>
                    </div>
                </div>
            </div>

            <!-- Modal HTML for swap ends here -->


            <table id="moderators-table" class="display">
                <thead>
                    <tr class="text-white bg-green-500">
                        <th class="text-center">S/N</th>
                        <th class="text-left">Surname</th>
                        <th class="text-left">Othernames</th>
                        <th class="text-left">Hostel</th>
                        <th class="text-left">Block</th>
                        <th class="text-left">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    include '../include/connection.php';
                    $sql = "SELECT m.*, h.hostel AS hostel FROM tblmoderator m 
                    INNER JOIN tblhostels h ON m.hostel_id = h.id";
                    $result = mysqli_query($connect, $sql);
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            ?>
                            <tr>
                                <td class="text-left"><?php echo $row["surname"]; ?></td>
                                <td class="text-left"><?php echo $row["othernames"]; ?></td>
                                <td class="text-left"><?php echo $row["hostel"]; ?></td>
                                <td class="text-left"><?php echo $row["block_id"]; ?></td>
                                <td class="text-left">
                                    <!-- Trigger delete function with JavaScript -->
                                    <button type="button" class="text-red-500 delete-btn"
                                        onclick="openModal(<?php echo $row['mod_id']; ?>)">Delete</button>
                                    <a href="edit_user.php?mod_id=<?php echo $row["mod_id"]; ?>" class="text-blue-500">Edit</a>
                                </td>
                            </tr>
                            <?php
                        }
                    } else {
                        ?>
                        <tr>
                            <td colspan="5">No moderators found</td>
                        </tr>
                        <?php
                    }
                    $connect->close();
                    ?>
                </tbody>
            </table>
        </div>
        <?php include 'include/footer.php' ?>
    </div>
</body>

</html>
<script>
    function openModal(modId) {
        const modalTemplate = document.getElementById('deleteModalTemplate');
        const modalClone = modalTemplate.cloneNode(true);
        modalClone.removeAttribute('id');
        modalClone.classList.remove('hidden');

        const confirmBtn = modalClone.querySelector('#confirmDeleteBtn');
        const cancelBtn = modalClone.querySelector('#cancelDeleteBtn');

        confirmBtn.onclick = function () {
            confirmDelete(modId);
            closeModal(modalClone);
        };

        cancelBtn.onclick = function () {
            closeModal(modalClone);
        };

        document.body.appendChild(modalClone);
        document.body.classList.add('overflow-hidden'); // Prevent scrolling

        setTimeout(function () {
            modalClone.querySelector('.bg-white').classList.remove('translate-y-full');
        }, 50);
    }

    function closeModal(modal) {
        modal.querySelector('.bg-white').classList.add('translate-y-full');
        setTimeout(function () {
            modal.remove();
            document.body.classList.remove('overflow-hidden'); // Re-enable scrolling
        }, 250);
    }

    function confirmDelete(modId) {
        // Implement deletion logic here
        // For example, redirect to PHP script for deletion
        window.location.href = 'include/delete_moderator.php?mod_id=' + modId;
    }
</script>
<!-- SCRIPTS -->
<script>
    function updateDateTime() {
        const dateTimeElement = document.getElementById('currentDateTime');
        const now = new Date();
        const date = now.toLocaleDateString();
        const time = now.toLocaleTimeString();
        dateTimeElement.textContent = `Date: ${date} | Time: ${time}`;
    }

    // Update the date and time every second
    setInterval(updateDateTime, 1000);

    // Initial call to display the date and time
    updateDateTime();

</script>
<script>
    document.getElementById('toggleButton').addEventListener('click', function () {
        document.getElementById('sidebar').classList.toggle('hidden');
    });
</script>
<script>
    $(document).ready(function () {
        $('#moderators-table').DataTable();
    });
</script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var table = document.getElementById('moderators-table');
        var rows = table.getElementsByTagName('tr');

        for (var i = 1; i < rows.length; i++) {
            var cell = document.createElement('td');
            cell.textContent = i;
            cell.style.border = '0.5px solid lightgray'; // Add border style
            cell.style.textAlign = 'center'; // Center text horizontally
            rows[i].insertBefore(cell, rows[i].firstChild);
        }
    });
</script>

<script src="js/search.js"></script>
<script src="js/drop.js"></script>
<script src="js/adminscript.js"></script>