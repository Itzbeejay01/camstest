<?php
include ("../include/connection.php");
session_start();
if (!isset($_SESSION["username"])) {
    header("Location: index.php");
    exit;
}
?><!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrator</title>
    <link rel="stylesheet" href="../dist/output.css">
    <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
</head>
<style>
    @media (min-width: 1024px) {
        .pc-view-padding {
            padding-left: 310px;
        }
    }

    @media (min-width: 640px) {
        .mybody {
            background: url("../img/admin2.jpeg");
            background-size: cover;
            background-position: center center;
            background-repeat: no-repeat;
            background-attachment: fixed;

        }
    }
</style>

<body class="w-full lg:flex-row lg:min-h-screen lg:flex bg-gray-100">
    <?php include 'include/header.php'; ?>
    <div class="w-full flex flex-col lg:px-14 lg:mt-8 pc-view-padding">
        <div class="w-full px-4">
            <h1 class="text-lg font-bold mb-4 text-center text-green-800">Update Student Details</h1>
            <?php
            // Assuming you have a database connection established already
            include ("../include/connection.php");
            // Fetch colleges from tblcollege
            $collegeQuery = "SELECT * FROM tblcollege";
            $collegeResult = mysqli_query($connect, $collegeQuery);

            // Fetch departments from tbldepartment
            $departmentQuery = "SELECT * FROM tbldepartment";
            $departmentResult = mysqli_query($connect, $departmentQuery);

            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Process form data when form is submitted
                $student_id = $_POST['student_id'];
                $surname = $_POST['surname'];
                $othernames = $_POST['othernames'];
                $gender = $_POST['gender'];
                $matricNumber = $_POST['matricNumber'];
                $email = $_POST['email'];
                $phoneNumber = $_POST['phoneNumber'];
                $college = $_POST['college'];
                $department = $_POST['department'];
                $hostel_id = $_POST['hostel_id'];
                $block = $_POST['block'];
                $roomNo = $_POST['roomNo'];
                $bedSpace = $_POST['bedSpace'];


                // Check if block is "null" and set it to NULL if it is
                $blockValue = strtolower($block) === 'null' ? "NULL" : "'$block'";

                // Update user details in the database
                $sql = "UPDATE tblstudents 
                            SET surname='$surname', othernames='$othernames', gender='$gender', matricNumber='$matricNumber', email='$email', phoneNumber='$phoneNumber', college='$college', department='$department', hostel_id='$hostel_id', block=$blockValue, roomNo='$roomNo', bedSpace='$bedSpace'
                            WHERE student_id=$student_id";
                if (mysqli_query($connect, $sql)) {
                    echo '<div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
                                        <p class="font-bold">User updated successfully.</p>
                                        </div>';
                } else {
                    echo "Error updating user: " . mysqli_error($connect);
                }
            }
            // Fetch user details based on ID from the query string
            if (isset($_GET['student_id'])) {
                $student_id = $_GET['student_id'];
                $sql = "SELECT s.*, c.college, d.department, h.hostel 
                    FROM tblstudents s
                    INNER JOIN tblcollege c ON s.college = c.id
                    INNER JOIN tbldepartment d ON s.department = d.id
                    INNER JOIN tblhostels h ON s.hostel_id = h.id WHERE s.student_id=$student_id";


                $result = mysqli_query($connect, $sql);

                if (mysqli_num_rows($result) == 1) {
                    $row = mysqli_fetch_assoc($result);
                } else {
                    echo "User not found";
                    exit();
                }
            }
            // HTML structure starts here
            ?>
            <form class="w-full bg-white rounded-lg mt-4 shadow-lg flex flex-col lg:p-10" method="POST"
                action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="w-full lg:flex lg:items-center lg:justify-center p-5">
                    <input type="hidden" name="student_id" value="<?php echo $row['student_id']; ?>">
                    <div class="w-full px-4 h-full">
                        <div class="mb-4 lg:mb-4">
                            <label class="block text-gray-700 text-sm font-bold mb-2" for="username">Surname:</label>
                            <input
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                id="username" type="text" name="surname" value="<?php echo $row['surname']; ?>"
                                required>
                        </div>
                        <div class="mb-4 lg:mb-4">
                            <label class="block text-gray-700 text-sm font-bold mb-2" for="username">Othernames:</label>
                            <input
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                id="username" type="text" name="othernames" value="<?php echo $row['othernames']; ?>"
                                required>
                        </div>
                        <div class="mb-4 lg:mb-4">
                            <label class="block text-gray-700 text-sm font-bold mb-2" for="gender">Gender:</label>
                            <input
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                id="gender" type="text" name="gender" value="<?php echo $row['gender']; ?>" required>
                        </div>
                        <div class="mb-4 lg:mb-4">
                            <label class="block text-gray-700 text-sm font-bold mb-2" for="matricNumber">Matric
                                Number:</label>
                            <input
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                id="matricNumber" type="text" name="matricNumber"
                                value="<?php echo $row['matricNumber']; ?>" required>
                        </div>
                        <div class="mb-4 lg:mb-4">
                            <label class="block text-gray-700 text-sm font-bold mb-2" for="email">Email:</label>
                            <input
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                id="email" type="email" name="email" value="<?php echo $row['email']; ?>" required>
                        </div>
                        <div class="mb-4 lg:mb-4">
                            <label class="block text-gray-700 text-sm font-bold mb-2" for="phoneNumber">Phone
                                Number:</label>
                            <input
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                id="college" type="text" name="phoneNumber" value="<?php echo $row['phoneNumber']; ?>"
                                required>
                        </div>
                    </div>
                    <div class="w-full px-4 h-full">
                        <div class="mb-4 lg:mb-4">
                            <label class="block text-gray-700 text-sm font-bold mb-2" for="college">College:</label>
                            <select
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                id="college" name="college" required>
                                <?php while ($college = mysqli_fetch_assoc($collegeResult)): ?>
                                    <option value="<?php echo $college['id']; ?>"><?php echo $college['college']; ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="mb-4 lg:mb-5">
                            <label class="block text-gray-700 text-sm font-bold mb-2"
                                for="department">Department:</label>
                            <select
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                id="department" name="department" required>
                                <?php while ($department = mysqli_fetch_assoc($departmentResult)): ?>
                                    <option value="<?php echo $department['id']; ?>">
                                        <?php echo $department['department']; ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="mb-4 lg:mb-5">
                            <select id="hostels" name="hostel_id"
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                required>
                                <option value="" disabled selected>Select Hostel</option>
                                <option value="1">Male Hostel 1</option>
                                <option value="2">Male Hostel 2</option>
                                <option value="3">Male Hostel 3</option>
                                <option value="4">Male Hostel 4</option>
                                <option value="5">Female Hostel 1</option>
                                <option value="6">Female Hostel 2</option>
                                <option value="7">Female Hostel 3</option>
                                <option value="8">Female Hostel 4</option>
                            </select>
                        </div>
                        <div class="mb-4 lg:mb-5">
                            <label class="block text-gray-700 text-sm font-bold mb-2" for="block">Block:</label>
                            <input
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                id="block" type="text" name="block" value="<?php echo $row['block']; ?>"
                                placeholder="Type NULL if not applicable" required>
                        </div>
                        <div class="mb-4 lg:mb-5">
                            <label class="block text-gray-700 text-sm font-bold mb-2" for="roomNo">Room No:</label>
                            <input
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                id="roomNo" type="text" name="roomNo" value="<?php echo $row['roomNo']; ?>" required>
                        </div>
                        <div class="mb-4 lg:mb-5">
                            <label class="block text-gray-700 text-sm font-bold mb-2" for="bedSpace">Bed Space:</label>
                            <input
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                id="bedSpace" type="text" name="bedSpace" value="<?php echo $row['bedSpace']; ?>"
                                required>
                        </div>
                    </div>
                </div>
                <div class="mb-4 w-full flex items-center justify-center">
                    <button
                        class="w-1/2 bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                        type="submit">Update</button>
                </div>
            </form>
        </div>
        <?php
        // Close connection
        mysqli_close($connect);
        ?>
        <?php include 'include/footer.php' ?>

    </div>
</body>

</html>
<script>
    document.getElementById('toggleButton').addEventListener('click', function () {
        document.getElementById('sidebar').classList.toggle('hidden');
    });
</script>
<script src="../js/myscript.js"></script>