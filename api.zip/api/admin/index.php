<?php
// Start output buffering to prevent any output being sent to the browser
ob_start();
// Include connection file
include '../include/connection.php';
// Now it's safe to start the session
session_start();
// Check if the user is not logged in
if (!isset($_SESSION["username"])) {
    // Redirect to the login page
    header("Location: ../index.php");
    // Make sure to flush the output buffer before the redirection header
    ob_end_flush();
    exit;
}
// If the user is logged in, continue with your code
// Flush the output buffer before the script ends
ob_end_flush();
?><!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../dist/output.css">
    <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
</head>
<style>
    @media (min-width: 1024px) {
        .pc-view-padding {
            padding-left: 280px;
        }
    }
</style>

<body class="w-full lg:flex-row lg:min-h-100vh lg:flex bg-gray-100 ">
    
    <?php include 'include/header.php'; ?>
    <div class="lg:flex-1 pc-view-padding">
        <!-- Current Time -->
        <div class="w-full p-2 flex items-center justify-center mb-2 lg:p-0 lg:hidden">
            <div id="currentDateTime" class="text-green-950 w-2/3 p-2 rounded-xl bg-gray-50 text-sm text-center font-medium
                        shadow-gray-300 shadow-md lg:text-center lg:w-full lg:rounded-md lg:text-lg"></div>
        </div>
        <!-- Current time end here -->
        <div class="text-lg text-center font-bold text-green-800 py-4 bg-white shadow-lg rounded hidden lg:block">
            JABU_CAMS - DASHBOARD</div>
        <div class="lg:flex lg:px-10 lg:pt-16  px-2">
            <!-- TOTAL STUDENT -->
            <div
                class="bg-blue-800 shadow-slate-500 text-white px-5 py-8 rounded-lg shadow-lg my-2 mb-8 lg:w-full lg:mx-10">
                <div href="" class="flex items-center justify-between">
                    <div class="flex items-center">
                        <span class="material-symbols-outlined text-2xl">group</span>
                        <p class="text-xl mx-2">Total Students</p>
                    </div>
                    <p class="text-xl mr-4">
                        <?php
                        include '../include/connection.php';

                        $query = "SELECT COUNT(*) AS total FROM tblstudents";
                        $result = $connect->query($query);

                        if ($result->num_rows > 0) {
                            // output data of each row
                            $row = $result->fetch_assoc();
                            echo $row["total"];
                        } else {
                            echo "0";
                        }
                        //$conn->close();
                        ?>
                    </p>
                </div>
            </div>
            <!-- MODERATORS -->
            <div
                class="bg-green-600 shadow-slate-500 text-white px-5 py-8 rounded-lg shadow-lg my-2 mb-8 lg:w-full lg:mx-10">
                <a href="addmod.php" class="flex items-center justify-between">
                    <div class="flex items-center">
                        <span class="material-symbols-outlined text-2xl">add_moderator</span>
                        <p class="text-xl mx-2">Moderators</p>
                    </div>
                    <p class="text-xl mr-4">
                        <?php
                        include '../include/connection.php';

                        $query = "SELECT COUNT(*) AS total FROM tblmoderator";
                        $result = $connect->query($query);

                        if ($result->num_rows > 0) {
                            // output data of each row
                            $row = $result->fetch_assoc();
                            echo $row["total"];
                        } else {
                            echo "0";
                        }
                        //$conn->close();
                        ?>
                    </p>
                </a>
            </div>
        </div>
        <div class="lg:flex lg:px-10 px-2">
            <!-- HOSTELS -->
            <div
                class="bg-slate-900 shadow-slate-500 text-white px-5 py-8 rounded-lg shadow-lg my-2 mb-8 lg:w-full lg:mx-10">
                <div href="" class="flex items-center justify-between">
                    <div class="flex items-center">
                        <span class="material-symbols-outlined text-2xl">home</span>
                        <p class="text-xl mx-2">Hostels</p>
                    </div>
                    <p class="text-xl mr-4">
                        <?php
                        include '../include/connection.php';

                        $query = "SELECT COUNT(*) AS total FROM tblhostels";
                        $result = $connect->query($query);

                        if ($result->num_rows > 0) {
                            // output data of each row
                            $row = $result->fetch_assoc();
                            echo $row["total"];
                        } else {
                            echo "0";
                        }
                        //$conn->close();
                        ?>
                    </p>
                </div>
            </div>
            <!-- Semester -->
            <div
                class="bg-emerald-800 shadow-slate-500 text-white px-5 py-8 rounded-lg shadow-lg my-2 mb-8 lg:w-full lg:mx-10">
                <div href="" class="flex items-center justify-between">
                    <div class="flex items-center">
                        <span class="material-symbols-outlined text-2xl">calendar_month</span>
                        <p class="text-xl mx-2">2024/2025</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="lg:flex lg:px-10 px-2">
            <!-- EXEAT -->
            <div
                class="bg-red-600 shadow-slate-500 text-white px-5 py-8 rounded-lg shadow-lg my-2 mb-8 lg:w-full lg:mx-10">
                <a href="exeat.php" class="flex items-center justify-between">
                    <div class="flex items-center">
                        <span class="material-symbols-outlined text-2xl">person_off</span>
                        <p class="text-xl mx-2">Exeat Students</p>
                    </div>
                    <p class="text-xl mr-4">
                        <?php
                        include '../include/connection.php';

                        $query = "SELECT COUNT(*) AS total FROM tblexeat";
                        $result = $connect->query($query);

                        if ($result->num_rows > 0) {
                            // output data of each row
                            $row = $result->fetch_assoc();
                            echo $row["total"];
                        } else {
                            echo "0";
                        }
                        //$conn->close();
                        ?>
                    </p>
                </a>
            </div>
            <!-- DOWNLOAD RECORD -->
            <div
                class="bg-blue-600 shadow-slate-500 text-white px-5 py-8 rounded-lg shadow-lg my-2 mb-8 lg:w-full lg:mx-10">
                <a href="record.php" class="flex items-center justify-between">
                    <div class="flex items-center">
                        <span class="material-symbols-outlined text-2xl">download</span>
                        <p class="text-xl mx-2">Download Record</p>
                    </div>
                </a>
            </div>
        </div>
        <?php include 'include/footer.php' ?>
    </div>
</body>

</html>
<!-- SCRIPTS -->
<script src="/js/adminscript.js"></script>
<script>
    function updateDateTime() {
        const dateTimeElement = document.getElementById('currentDateTime');
        const now = new Date();
        const date = now.toLocaleDateString();
        const time = now.toLocaleTimeString();
        dateTimeElement.textContent = `Date: ${date} | Time: ${time}`;
    }

    // Update the date and time every second
    setInterval(updateDateTime, 1000);

    // Initial call to display the date and time
    updateDateTime();
</script>
<script>
    document.getElementById('toggleButton').addEventListener('click', function () {
        document.getElementById('sidebar').classList.toggle('hidden');
    });
</script>
<script>
    document.getElementById('dropdown-button').addEventListener('click', function () {
        var menu = document.getElementById('dropdown-menu');
        if (menu.classList.contains('hidden')) {
            menu.classList.remove('hidden');
        } else {
            menu.classList.add('hidden');
        }
    });

    document.addEventListener('click', function (event) {
        var menu = document.getElementById('dropdown-menu');
        var button = document.getElementById('dropdown-button');
        if (!menu.contains(event.target) && event.target !== button) {
            menu.classList.add('hidden');
        }
    });
</script>