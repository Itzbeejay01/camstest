<?php
include ("../include/connection.php");
session_start();
if (!isset($_SESSION["username"])) {
    header("Location: ../index.php");
    exit;
}
// Fetching all student details
$query = "SELECT tblstudents.*, tblcollege.college, tbldepartment.department, tblhostels.hostel 
          FROM tblstudents 
          INNER JOIN tblcollege ON tblstudents.college = tblcollege.id
          INNER JOIN tbldepartment ON tblstudents.department = tbldepartment.id
          INNER JOIN tblhostels ON tblstudents.hostel_id = tblhostels.id";
$result = mysqli_query($connect, $query);
if (!$result) {
    die("Query failed: " . mysqli_error($connect));
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin::Students</title>
    <link rel="stylesheet" href="../dist/output.css">
    <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <!-- Include DataTables CSS -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
    <!-- Include jQuery and DataTables JavaScript -->
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#student-details-table').DataTable({
                responsive: true,
                rowGroup: {
                    dataSrc: 'group' // Specify the column to group by
                }
            });
        });
    </script>

</head>
<style>
    @media (min-width: 1024px) {
        .pc-view-padding {
            padding-left: 310px;
        }
    }
</style>

<body class="w-full max-h-full">
    <?php include 'include/header.php'; ?>

    <div class="w-full lg:px-5 pc-view-padding">
    <!-- Current Time -->
    <div class="w-full flex items-center justify-center mb-1 mt-2 lg:p-0 lg:hidden">
            <div id="currentDateTime" class="text-green-950 w-2/3 p-2 rounded-xl bg-gray-50 text-sm text-center font-medium
                        shadow-gray-300 shadow-md lg:text-center lg:w-full lg:rounded-md lg:text-lg"></div>
        </div>
        <!-- Current time end here -->
        <div class="text-lg text-center font-bold text-green-800 py-4 bg-white shadow-lg rounded hidden lg:block mb-4">
        JABU_CAMS - STUDENTS</div>
        <div class="w-full px-6 mt-3 backdrop-blur-md rounded-xl shadow-xl lg:py-3">
            <table id="student-details-table" class="w-full rounded-lg">
                <thead>
                    <tr class="text-white bg-green-500" >
                        <th class="text-center">S/N</th>
                        <th class="text-left">Surname</th>
                        <th class="text-left px-1">Othernames</th>
                        <th class="text-left px-1">Matric No.</th>
                        <th class="text-left px-1">Phone No.</th>
                        <th class="text-left px-1">College</th>
                        <th class="text-left px-1">Department</th>
                        <th class="text-left px-1">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-white">
                    <?php if (mysqli_num_rows($result) > 0) { ?>
                        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                            <tr>
                                <td>
                                    <?php echo $row['surname']; ?>
                                </td>
                                <td>
                                    <?php echo $row['othernames']; ?>
                                </td>
                                <td>
                                    <?php echo $row['matricNumber']; ?>
                                </td>
                                <td>
                                    <?php echo $row['phoneNumber']; ?>
                                </td>
                                <td>
                                    <?php echo $row['college']; ?>
                                </td>
                                <td>
                                    <?php echo $row['department']; ?>
                                </td>
                                <td class="text-left">
                                    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                                        <input type="hidden" name="student_id" value="<?php echo $row['student_id']; ?>">
                                        <a href="editstudent.php?student_id=<?php echo $row["student_id"]; ?>"
                                            class="text-green-500">View</a>
                                    </form>
                                </td>
                            </tr>
                        <?php } ?>
                    <?php } else { ?>
                        <tr>
                            <td colspan="12">No student details found</td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
        <?php include 'include/footer.php' ?>
    </div>
    </div>
    <script>
        function updateDateTime() {
            const dateTimeElement = document.getElementById('currentDateTime');
            const now = new Date();
            const date = now.toLocaleDateString();
            const time = now.toLocaleTimeString();
            dateTimeElement.textContent = `Date: ${date} | Time: ${time}`;
        }
        setInterval(updateDateTime, 1000);
        updateDateTime();
    </script>
    <script>
        document.getElementById('toggleButton').addEventListener('click', function () {
            document.getElementById('sidebar').classList.toggle('hidden');
        });
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var table = document.getElementById('student-details-table');
            var rows = table.getElementsByTagName('tr');

            for (var i = 1; i < rows.length; i++) {
                var cell = document.createElement('td');
                cell.textContent = i;
                cell.style.borderRight = '1px solid lightgray';
                cell.style.textAlign = 'center'; // Center text horizontally
                rows[i].insertBefore(cell, rows[i].firstChild);
            }
        });
    </script>
    <script src="js/adminscript.js"></script>
</body>

</html>