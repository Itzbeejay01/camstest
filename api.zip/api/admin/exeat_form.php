<?php
include ("../include/connection.php");
session_start();
if (!isset($_SESSION["username"])) {
    header("Location: ../index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin:: Exeat Registration</title>
    <link rel="stylesheet" href="../dist/output.css">
    <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
</head>
<style>
    @media (min-width: 1024px) {
        .pc-view-padding {
            padding-left: 280px;
        }
    }
</style>

<body class="w-full max-h-full">
    <?php include 'include/header.php'; ?>
    <div class="w-full lg:flex-1 pc-view-padding">
        <div class="text-lg mx-8 text-center font-bold text-green-800 py-2 bg-white shadow-lg mt-2 mb-2 rounded-xl">
            Exeat Form</div>
        <!-- Form to request Matric Number -->
        <div class="w-full justify-center px-4 lg:px-52 lg:py-2">
            <form class="w-full bg-white mt-4 shadow-2xl shadow-gray-400 p-8 rounded-lg" method="POST"
                action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="mb-4">
                    <label class="block text-sm font-bold mb-2 text-green-800" for="matricNumber">Enter student matric
                        Number:</label>
                    <input
                        class="shadow appearance-none border rounded w-full py-2 px-3 text-black leading-tight focus:outline-none focus:shadow-outline"
                        id="matricNumber" type="text" name="matricNumber" required>
                </div>
                <div class="mb-4">
                    <button
                        class="w-full bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                        type="submit">Get Details</button>
                </div>
            </form>
            <?php
            // Fetch user details based on Matric Number from the form submission
            if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['matricNumber'])) {
                $matricNumber = $_POST['matricNumber'];
                $sql = "SELECT * FROM tblstudents WHERE matricNumber='$matricNumber'";
                $result = mysqli_query($connect, $sql);

                if (mysqli_num_rows($result) == 1) {
                    $row = mysqli_fetch_assoc($result);

                    // Check if the student ID exists in the tblexeat table
                    $check_query = "SELECT * FROM tblexeat WHERE student_id = '{$row['student_id']}'";
                    $check_result = $connect->query($check_query);

                    if ($check_result && $check_result->num_rows > 0) {
                        // Display a link to update exeat information
                        $exeat_row = $check_result->fetch_assoc();
                        echo '<div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
                        <p class="font-bold">Student on exeat. <a href="update_exeat.php?student_id=' . $exeat_row['student_id'] . '" class="underline text-blue-500">Click here</a> to update the exeat form.</p> 
                  </div>';
                        exit;
                    }
                    ?>
                </div>
                <!-- Form to submit exeat information -->
                <div class="w-full flex justify-center px-4 lg:px-20 lg:py-2">
                    <form class="w-full bg-white mt-4 shadow-lg p-8 " method="POST">
                        <h1 class="text-xl font-bold text-center text-green-800">Exeat Registration Form</h1>
                        <?php include 'include/submit_exeat.php'; ?>
                        <div class="lg:flex">
                            <div class="w-full mx-2">
                                <input
                                    class="shadow appearance-none border rounded w-full py-2 px-3 text-black leading-tight focus:outline-none focus:shadow-outline hidden"
                                    id="surname" type="text" name="surname" value="<?php echo $row['student_id']; ?>" readonly>
                                <div class="mb-4">
                                    <label class="block text-sm font-bold mb-2 text-green-800" for="surname">Surname:</label>
                                    <input
                                        class="shadow appearance-none border rounded w-full py-2 px-3 text-black leading-tight focus:outline-none focus:shadow-outline"
                                        id="surname" type="text" name="surname" value="<?php echo $row['surname']; ?>" readonly>
                                </div>
                                <div class="mb-4">
                                    <label class="block text-sm font-bold mb-2 text-green-800"
                                        for="othernames">Othernames:</label>
                                    <input
                                        class="shadow appearance-none border rounded w-full py-2 px-3 text-black leading-tight focus:outline-none focus:shadow-outline"
                                        id="othernames" type="text" name="othernames" value="<?php echo $row['othernames']; ?>"
                                        readonly>
                                </div>
                                <div class="mb-4">
                                    <label class="block text-sm font-bold mb-2 text-green-800" for="start_date">Matric
                                        Number:</label>
                                    <input
                                        class="shadow appearance-none border rounded w-full py-2 px-3 text-black leading-tight focus:outline-none focus:shadow-outline"
                                        id="start_date" type="text" name="matricNumber"
                                        value="<?php echo $row['matricNumber']; ?>" readonly>
                                </div>
                            </div>
                            <div class="w-full mx-2">
                                <div class="mb-4">
                                    <label class="block text-sm font-bold mb-2 text-green-800" for="start_date">Start
                                        Date:</label>
                                    <input
                                        class="shadow appearance-none border rounded w-full py-2 px-3 text-black leading-tight focus:outline-none focus:shadow-outline"
                                        id="start_date" type="date" name="start_date" required>
                                </div>
                                <div class="mb-4">
                                    <label class="block text-sm font-bold mb-2 text-green-800" for="end_date">End Date:</label>
                                    <input
                                        class="shadow appearance-none border rounded w-full py-2 px-3 text-black leading-tight focus:outline-none focus:shadow-outline"
                                        id="end_date" type="date" name="end_date" required>
                                </div>
                                <div class="mb-4">
                                    <label class="block text-sm font-bold mb-2 text-green-800" for="reason">Reason:</label>
                                    <input
                                        class="shadow appearance-none border rounded w-full py-2 px-3 text-black leading-tight focus:outline-none focus:shadow-outline"
                                        id="reason" name="reason" required></input>
                                </div>
                            </div>
                        </div>
                        <div class="mb-4">
                            <input type="hidden" name="student_id" value="<?php echo $row['student_id']; ?>">
                            <button
                                class="w-full bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                                type="submit" name="exeat">Submit Exeat</button>
                        </div>
                    </form>
                </div>

                <?php
                } else {
                    echo '<div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
                <p class="font-bold">No student found with the Matric Number!</p> </div>';
                }
            }
            ?>
    </div>
    <?php include 'include/footer.php'; ?>
</body>

</html>
<script>
    function updateDateTime() {
        const dateTimeElement = document.getElementById('currentDateTime');
        const now = new Date();
        const date = now.toLocaleDateString();
        const time = now.toLocaleTimeString();
        dateTimeElement.textContent = `Date: ${date} | Time: ${time}`;
    }

    // Update the date and time every second
    setInterval(updateDateTime, 1000);

    // Initial call to display the date and time
    updateDateTime();
</script>
<script>
    document.getElementById('toggleButton').addEventListener('click', function () {
        document.getElementById('sidebar').classList.toggle('hidden');
    });
</script>
<script>
    $(document).ready(function () {
        $('#student-details-table').DataTable();
    });
</script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var table = document.getElementById('student-details-table');
        var rows = table.getElementsByTagName('tr');

        for (var i = 1; i < rows.length; i++) {
            var cell = document.createElement('td');
            cell.textContent = i;
            cell.style.border = '1px solid lightgray'; // Add border style
            cell.style.textAlign = 'center'; // Center text horizontally
            rows[i].insertBefore(cell, rows[i].firstChild);
        }
    });
</script>
<script src="js/adminscript.js"></script>