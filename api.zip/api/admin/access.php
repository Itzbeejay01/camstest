<?php
include ("../include/connection.php");
session_start();
if (!isset($_SESSION["username"])) {
    header("Location: ../index.php");
    exit;
}
?><!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin::Access Control</title>
    <link rel="stylesheet" href="../dist/output.css">
    <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
</head>
<style>
    @media (min-width: 1024px) {
        .pc-view-padding {
            padding-left: 300px;
        }
    }
</style>

<body class="w-full max-h-full">
    <?php include 'include/header.php'; ?>
    <div class="w-full py-2 lg:px-5  pc-view-padding">
        <!-- Current Time -->
         <!-- Current Time -->
         <div class="w-full flex items-center justify-center mb-1 mt-2 lg:p-0 lg:hidden">
            <div id="currentDateTime" class="text-green-950 w-2/3 p-2 rounded-xl bg-gray-50 text-sm text-center font-medium
                        shadow-gray-300 shadow-md lg:text-center lg:w-full lg:rounded-md lg:text-lg"></div>
        </div>
        <!-- Current time end here -->
        <div class="text-lg text-center font-bold text-green-800 py-4 bg-white shadow-lg rounded hidden lg:block mb-4">
        JABU_CAMS - ACCESS CONTROL</div>
        <div class="w-full mt-3 rounded-xl lg:py-3 lg:flex">
            <!-- Attendance control -->
            <div
                class="lg:w-1/2 h-full bg-white rounded-lg shadow-xl mx-2 mb-4 py-16 flex flex-col items-center justify-center">
                <h2 class="text-xl mb-8 font-bold text-green-600 shadow-lg py-4 px-4 rounded-xl">Attendance Access
                    Control</h2>
                <?php
                // Database connection parameters
                include '../include/connection.php';

                // Check connection
                if ($connect->connect_error) {
                    die("Connection failed: " . $connect->connect_error);
                }

                // Function to toggle page status
                function togglePageStatus()
                {
                    global $connect;

                    // Get current status
                    $status = getPageStatus('program');

                    // Toggle status
                    $newStatus = ($status == 'enabled') ? 'disabled' : 'enabled';

                    // Update status in the database
                    $sql = "UPDATE page_status SET status='$newStatus' WHERE page_id='program'";

                    if ($connect->query($sql) === TRUE) {
                        echo '<div id="successMessage" class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
                <p class="font-bold">Attendance page status updated successfully</p>
              </div>';
                    } else {
                        echo "Error updating page status: " . $connect->error;
                    }
                }

                // Function to get page status
                function getPageStatus($pageId)
                {
                    global $connect;

                    // Query database for page status
                    $sql = "SELECT status FROM page_status WHERE page_id = '$pageId'";
                    $result = $connect->query($sql);

                    if ($result->num_rows > 0) {
                        $row = $result->fetch_assoc();
                        return $row["status"];
                    } else {
                        return "Status not found";
                    }
                }
                ?>
                <?php
                // Check if form is submitted
                if (isset($_POST["program"])) {
                    // Toggle page status
                    togglePageStatus();
                }
                ?>

                <form method="post">
                    <?php
                    // Get current page status
                    $status = getPageStatus('program');

                    // Display appropriate button text based on current status
                    $buttonText = ($status == 'enabled') ? 'Disable Attendance Page' : 'Enable Attendance Page';
                    ?>
                    <input type="submit" name="program" value="<?php echo $buttonText; ?>"
                        class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">

                </form>
            </div>
            <!-- Record Control -->
            <div
                class="lg:w-1/2 h-full bg-white rounded-lg shadow-xl mx-2 mb-4 py-16 flex flex-col items-center justify-center">
                <h2 class="text-xl mb-8 font-bold text-green-600 shadow-lg py-4 px-4 rounded-xl">Report Access</h2>
                <?php
                // Database connection parameters
                include '../include/connection.php';

                // Check connection
                if ($connect->connect_error) {
                    die("Connection failed: " . $connect->connect_error);
                }

                // Function to toggle page status
                function togglePageStatus2()
                {
                    global $connect;

                    // Get current status
                    $status = getPageStatus('calculate');

                    // Toggle status
                    $newStatus = ($status == 'enabled') ? 'disabled' : 'enabled';

                    // Update status in the database
                    $sql = "UPDATE page_status SET status='$newStatus' WHERE page_id='calculate'";

                    if ($connect->query($sql) === TRUE) {
                        echo '<div id="successMessage" class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
                <p class="font-bold">Record page status updated successfully</p>
                </div>';
                    } else {
                        echo "Error updating page status: " . $connect->error;
                    }
                }

                // Function to get page status
                function getPageStatus2($pageId)
                {
                    global $connect;

                    // Query database for page status
                    $sql = "SELECT status FROM page_status WHERE page_id = '$pageId'";
                    $result = $connect->query($sql);

                    if ($result->num_rows > 0) {
                        $row = $result->fetch_assoc();
                        return $row["status"];
                    } else {
                        return "Status not found";
                    }
                }
                ?>
                <?php
                // Check if form is submitted
                if (isset($_POST["calculate"])) {
                    // Toggle page status
                    togglePageStatus2();
                }
                ?>

                <form method="post">
                    <?php
                    // Get current page status
                    $status = getPageStatus('calculate');

                    // Display appropriate button text based on current status
                    $buttonText = ($status == 'enabled') ? 'Disable Record Page' : 'Enable Record Page';
                    ?>
                    <input type="submit" name="calculate" value="<?php echo $buttonText; ?>"
                        class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">

                </form>
            </div>
        </div>
        <div class="w-full px-2 mt-3 rounded-xl lg:py-3 lg:flex">
            <!-- Mark Out Control -->
            <div
                class="lg:w-1/2 h-full bg-white rounded-lg shadow-xl mx-2 mb-4 py-16 flex flex-col items-center justify-center">
                <h2 class="text-xl mb-8 font-bold text-green-600 shadow-lg py-4 px-4 rounded-xl">Mark-Out Access</h2>
                <?php
                // Database connection parameters
                include '../include/connection.php';

                // Check connection
                if ($connect->connect_error) {
                    die("Connection failed: " . $connect->connect_error);
                }

                // Function to toggle page status
                function togglePageStatus4()
                {
                    global $connect;

                    // Get current status
                    $status = getPageStatus('markout');

                    // Toggle status
                    $newStatus = ($status == 'enabled') ? 'disabled' : 'enabled';

                    // Update status in the database
                    $sql = "UPDATE page_status SET status='$newStatus' WHERE page_id='markout'";

                    if ($connect->query($sql) === TRUE) {
                        echo '<div id="successMessage" class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
                    <p class="font-bold">Markout page status updated successfully</p>
                    </div>';
                    } else {
                        echo "Error updating page status: " . $connect->error;
                    }
                }

                // Function to get page status
                function getPageStatus4($pageId)
                {
                    global $connect;

                    // Query database for page status
                    $sql = "SELECT status FROM page_status WHERE page_id = '$pageId'";
                    $result = $connect->query($sql);

                    if ($result->num_rows > 0) {
                        $row = $result->fetch_assoc();
                        return $row["status"];
                    } else {
                        return "Status not found";
                    }
                }
                ?>
                <?php
                // Check if form is submitted
                if (isset($_POST["markout"])) {
                    // Toggle page status
                    togglePageStatus4();
                }
                ?>

                <form method="post">
                    <?php
                    // Get current page status
                    $status = getPageStatus4('markout');

                    // Display appropriate button text based on current status
                    $buttonText = ($status == 'enabled') ? 'Disable Markout Page' : 'Enable Markout Page';
                    ?>
                    <input type="submit" name="markout" value="<?php echo $buttonText; ?>"
                        class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                </form>
            </div>
            <!-- Student Attendance checker -->
            <div
                class="lg:w-1/2 h-full bg-white rounded-lg shadow-xl mx-2 mb-4 py-16 flex flex-col items-center justify-center">
                <h2 class="text-xl mb-8 font-bold text-green-600 shadow-lg py-4 px-4 rounded-xl">Attendance Checker
                    Access</h2>
                <?php
                // Database connection parameters
                include '../include/connection.php';

                // Check connection
                if ($connect->connect_error) {
                    die("Connection failed: " . $connect->connect_error);
                }

                // Function to toggle page status
                function togglePageStatus3()
                {
                    global $connect;

                    // Get current status
                    $status = getPageStatus('thechecker');

                    // Toggle status
                    $newStatus = ($status == 'enabled') ? 'disabled' : 'enabled';

                    // Update status in the database
                    $sql = "UPDATE page_status SET status='$newStatus' WHERE page_id='thechecker'";

                    if ($connect->query($sql) === TRUE) {
                        echo '<div id="successMessage" class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
                <p class="font-bold">Attendance checker page updated successfully</p>
                </div>';
                    } else {
                        echo "Error updating page status: " . $connect->error;
                    }
                }

                // Function to get page status
                function getPageStatus3($pageId)
                {
                    global $connect;

                    // Query database for page status
                    $sql = "SELECT status FROM page_status WHERE page_id = '$pageId'";
                    $result = $connect->query($sql);

                    if ($result->num_rows > 0) {
                        $row = $result->fetch_assoc();
                        return $row["status"];
                    } else {
                        return "Status not found";
                    }
                }
                ?>
                <?php
                // Check if form is submitted
                if (isset($_POST["thechecker"])) {
                    // Toggle page status
                    togglePageStatus3();
                }
                ?>

                <form method="post">
                    <?php
                    // Get current page status
                    $status = getPageStatus('thechecker');

                    // Display appropriate button text based on current status
                    $buttonText = ($status == 'enabled') ? 'Disable checker Page' : 'Enable checker Page';
                    ?>
                    <input type="submit" name="thechecker" value="<?php echo $buttonText; ?>"
                        class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">

                </form>
            </div>

        </div>
    </div>
    <?php include 'include/footer.php' ?>
    </div>
</body>

</html>
<script>
    // Hide success message after 2 seconds
    setTimeout(function () {
        var successMessage = document.getElementById('successMessage');
        if (successMessage) {
            successMessage.style.display = 'none';
        }
    }, 2000);
</script>
<script>
    function updateDateTime() {
        const dateTimeElement = document.getElementById('currentDateTime');
        const now = new Date();
        const date = now.toLocaleDateString();
        const time = now.toLocaleTimeString();
        dateTimeElement.textContent = `Date: ${date} | Time: ${time}`;
    }

    // Update the date and time every second
    setInterval(updateDateTime, 1000);

    // Initial call to display the date and time
    updateDateTime();
</script>
<script>
    document.getElementById('toggleButton').addEventListener('click', function () {
        document.getElementById('sidebar').classList.toggle('hidden');
    });
</script>
<!-- Include jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<!-- Include DataTables JavaScript -->
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script>

    $(document).ready(function () {
        $('#student-details-table').DataTable();
    });
</script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var table = document.getElementById('student-details-table');
        var rows = table.getElementsByTagName('tr');

        for (var i = 1; i < rows.length; i++) {
            var cell = document.createElement('td');
            cell.textContent = i;
            cell.style.border = '1px solid lightgray'; // Add border style
            cell.style.textAlign = 'center'; // Center text horizontally
            rows[i].insertBefore(cell, rows[i].firstChild);
        }
    });
</script>
<script src="js/adminscript.js"></script>