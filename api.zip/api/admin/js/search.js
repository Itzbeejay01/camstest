 // Initialize variables for pagination
 let currentPage = 1;
 let rowsPerPage = 5;

 // Function to display rows based on current page and rows per page
 function displayRows(start, end) {
     const rows = document.querySelectorAll('#moderatorTable tbody tr');

     rows.forEach((row, index) => {
         if (index >= start && index < end) {
             row.style.display = '';
         } else {
             row.style.display = 'none';
         }
     });
 }

 document.addEventListener('DOMContentLoaded', function() {
     const showOptions = document.getElementById('showOptions');
     const searchInput = document.getElementById('searchInput');
     const studentTable = document.getElementById('moderatorTable');
     const nextButton = document.getElementById('nextButton');

     // Add event listener for the showOptions dropdown
     showOptions.addEventListener('change', function() {
         rowsPerPage = parseInt(this.value);
         displayRows(0, rowsPerPage);
     });

     // Add event listener for the nextButton
     nextButton.addEventListener('click', function() {
         const totalRows = document.querySelectorAll('#moderatorTable tbody tr').length;
         const end = currentPage * rowsPerPage;
         if (end < totalRows) {
             const start = end;
             currentPage++;
             end = currentPage * rowsPerPage;
             displayRows(start, end);
         }
     });

     // Add event listener for the searchInput
     searchInput.addEventListener('input', function() {
         const searchString = this.value.toLowerCase();
         const rows = studentTable.querySelectorAll('tbody tr');

         rows.forEach(row => {
             const studentName = row.children[1].textContent.toLowerCase();
            const studentId = row.children[0].textContent.toLowerCase();

             if (studentName.includes(searchString) || studentId.includes(searchString)) {
                 row.style.display = '';
             } else {
                 row.style.display = 'none';
             }
         });
     });

     // Initially display the first set of rows based on rowsPerPage
     displayRows(0, rowsPerPage);
 });