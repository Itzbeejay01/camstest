document.getElementById('moderatorform').addEventListener('submit', function (event) {
    var emailInput = document.getElementById('email');
    var emailValue = emailInput.value.trim();

    if (!emailValue.endsWith('@jabu.edu.ng')) {
        alert('Please enter a valid JABU student email address.');
        event.preventDefault();
    }
});

function addOption(selectElement, value, text) {
    var option = document.createElement('option');
    option.value = value;
    option.text = text;
    selectElement.add(option);
}

document.getElementById('hostels').addEventListener('change', function () {
    var hostelsValue = this.value;
    var blockContainer = document.getElementById('blockContainer');
    var blockDropdown = document.getElementById('block');

    blockContainer.style.display = 'none';

    blockDropdown.innerHTML = '<option value="" disabled selected>Select Block</option>';

    if (hostelsValue === '4' || hostelsValue === '8') {
        blockContainer.style.display = 'block';

        for (var j = 1; j <=9; j++) {
            addOption(blockDropdown, j, 'Block ' + j);
        }
    }
});
function checkImageSize() {
    var input = document.getElementById('passport');
    var file = input.files[0];
    if (file) {
      if (file.size < 80000 || file.size > 100000) {
        alert('Image size should be between 80kb and 100kb');
        input.value = '';
      }
    }
  }




