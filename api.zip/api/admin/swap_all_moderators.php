<?php
// Include your database connect script here
include ("../include/connection.php");

// Step 1: Retrieve all moderators who are marking for male and have non-null block assignments
$sql_male = "SELECT * FROM tblmoderator WHERE marking_for_gender = 'male' AND block_id IS NOT NULL";
$result_male = mysqli_query($connect, $sql_male);
if (!$result_male) {
    die("Error retrieving male moderators with non-null block assignments: " . mysqli_error($connect));
}

$maleModeratorsWithBlock = [];
while ($row = mysqli_fetch_assoc($result_male)) {
    $maleModeratorsWithBlock[] = $row;
}

// Step 2: Retrieve all moderators who are marking for female and have non-null block assignments
$sql_female = "SELECT * FROM tblmoderator WHERE marking_for_gender = 'female' AND block_id IS NOT NULL";
$result_female = mysqli_query($connect, $sql_female);
if (!$result_female) {
    die("Error retrieving female moderators with non-null block assignments: " . mysqli_error($connect));
}

$femaleModeratorsWithBlock = [];
while ($row = mysqli_fetch_assoc($result_female)) {
    $femaleModeratorsWithBlock[] = $row;
}

// Step 3: Shuffle the arrays of male and female moderators with non-null block assignments to introduce randomness
shuffle($maleModeratorsWithBlock);
shuffle($femaleModeratorsWithBlock);

// Step 4: Randomly select pairs of male moderators with non-null block assignments for swapping
$pairs_male = [];
$numPairs_male = count($maleModeratorsWithBlock) / 2; // Assuming an even number of male moderators with non-null block assignments for simplicity
for ($i = 0; $i < $numPairs_male; $i++) {
    $pairs_male[] = [
        'moderator1' => $maleModeratorsWithBlock[$i * 2],
        'moderator2' => $maleModeratorsWithBlock[$i * 2 + 1]
    ];
}

// Step 5: Randomly select pairs of female moderators with non-null block assignments for swapping
$pairs_female = [];
$numPairs_female = count($femaleModeratorsWithBlock) / 2; // Assuming an even number of female moderators with non-null block assignments for simplicity
for ($i = 0; $i < $numPairs_female; $i++) {
    $pairs_female[] = [
        'moderator1' => $femaleModeratorsWithBlock[$i * 2],
        'moderator2' => $femaleModeratorsWithBlock[$i * 2 + 1]
    ];
}

// Step 6: Combine the pairs of male and female moderators for swapping
$pairs = array_merge($pairs_male, $pairs_female);

// Step 7: Shuffle the combined pairs array to further randomize the swapping process
shuffle($pairs);

// Step 8: Swap assignments and update the database
foreach ($pairs as $pair) {
    $moderator1 = $pair['moderator1'];
    $moderator2 = $pair['moderator2'];

    // Swap block assignments
    $tempBlock = $moderator1['block_id'];

    $moderator1['block_id'] = $moderator2['block_id'];
    $moderator2['block_id'] = $tempBlock;

    // Update database with new block assignments
    $sql1 = "UPDATE tblmoderator SET block_id = {$moderator1['block_id']} WHERE mod_id = {$moderator1['mod_id']}";
    $sql2 = "UPDATE tblmoderator SET block_id = {$moderator2['block_id']} WHERE mod_id = {$moderator2['mod_id']}";

    $result1 = mysqli_query($connect, $sql1);
    $result2 = mysqli_query($connect, $sql2);

    if (!$result1 || !$result2) {
        die("Error updating block assignments: " . mysqli_error($connect));
    }
}

echo "Moderator block assignments swapped successfully.";

// Close database connect
mysqli_close($connect);
?>