<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Registration Panel</title>
    <link rel="stylesheet" href="../dist/output.css">
    <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />

</head>

<body class="w-full h-full bg-gray-100 py-10 px-4 lg:px-96 lg:py-20">
    <div
        class="w-full bg-white backdrop-blur-sm rounded-xl py-8 px-2 shadow-md lg:w-full lg:flex lg:flex-col lg:py-20 lg:justify-center lg:items-center">
        <div class="flex flex-col items-center">
            <h2 class="text-xl text-gray-600 font-bold mb-4 text-center">JABU CHAPEL ATTENDANCE SYSTEM</h2>
            <img class="w-24" src="../img/logo.png" alt="">
            <h2 class="text-lg font-medium text-center text-gray-600 mb-5">Admin Registration Panel</h2>
        </div>
        <form id="adminLoginForm" method="post" class="w-full p-3 ">
            <?php include ("../include/adminreg.php") ?>
            <div class="mb-4">
                <input type="surname" id="surname" name="surname"
                    class="border-2 outline-none rounded-md form-input mt-1 p-2 w-full" placeholder="Surname">
            </div>
            <div class="mb-4">
                <input type="othernames" id="othernames" name="othernames"
                    class="border-2 outline-none rounded-md form-input mt-1 p-2 w-full" placeholder="Othernames">
            </div>
            <div class="mb-4">
                <input type="email" id="email" name="email"
                    class="border-2 outline-none rounded-md form-input mt-1 p-2 w-full" placeholder="Email Address">
            </div>
            <div class="mb-4">
                <input type="password" id="password" name="password"
                    class="border-2 outline-none rounded-md form-input mt-1 p-2 w-full" placeholder="Password">
            </div>
            <button name="submit" type="submit"
                class="w-full font-medium text-lg bg-green-500 text-white p-2 rounded shadow-lg hover:bg-green-700">Register</button>
        </form>
    </div>
</body>
<script src="js/adminscript.js"></script>
<script src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons.js"></script>