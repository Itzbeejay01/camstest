<?php
include ("../include/connection.php");
session_start();
if (!isset($_SESSION["username"])) {
    header("Location: ../index.php");
    exit;
}
// Fetching all student details from tblexeat and joining with tblstudents
$query = "SELECT e.*, s.surname, s.othernames, s.matricNumber, s.phoneNumber, c.college, d.department, h.hostel 
          FROM tblexeat AS e
          INNER JOIN tblstudents AS s ON e.student_id = s.student_id
          INNER JOIN tblcollege AS c ON s.college = c.id
          INNER JOIN tbldepartment AS d ON s.department = d.id
          INNER JOIN tblhostels AS h ON s.hostel_id = h.id";
$result = mysqli_query($connect, $query);

if (!$result) {
    die("Query failed: " . mysqli_error($connect));
}
?><!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin::Exeat</title>
    <link rel="stylesheet" href="../dist/output.css">
    <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
</head>
<style>
    @media (min-width: 1024px) {
        .pc-view-padding {
            padding-left: 300px;
        }
    }
</style>

<body class="w-full lg:flex-row lg:min-h-100vh lg:flex bg-gray-100 ">
    <?php include 'include/header.php'; ?>
    <div class="w-full h-full py-2 lg:px-5 pc-view-padding">
         <!-- Current Time -->
         <div class="w-full flex items-center justify-center mb-1 mt-2 lg:p-0 lg:hidden">
            <div id="currentDateTime" class="text-green-950 w-2/3 p-2 rounded-xl bg-gray-50 text-sm text-center font-medium
                        shadow-gray-300 shadow-md lg:text-center lg:w-full lg:rounded-md lg:text-lg"></div>
        </div>
        <!-- Current time end here -->
        <div class="text-lg text-center font-bold text-green-800 py-4 bg-white shadow-lg rounded hidden lg:block mb-4">
        JABU_CAMS - EXEAT STUDENTS</div>
        <div class="w-full px-2 mt-3 bg-white rounded-xl shadow-xl lg:py-3">
            <table id="student-details-table" class="w-full">
                <thead>
                    <div class="h-full w-full py-6">
                        <a href="exeat_form.php"
                            class="bg-green-500 px-8 py-2 font-semibold text-white rounded-full mb-4 hover:bg-green-700 shadow-sm">Exeat Form</a>
                    </div>
                    <tr class="text-white back" style="background:#21c55e;">
                        <th class="text-center">S/N</th>
                        <th class="text-left">Surname</th>
                        <th class="text-left px-1">Othernames</th>
                        <th class="text-left px-1">Matric No.</th>
                        <th class="text-left px-1">Phone No.</th>
                        <th class="text-left px-1">Start Date</th>
                        <th class="text-left px-1">End Date</th>
                        <th class="text-left px-1">Reason</th>
                        <th class="text-left px-1">Actions</th>
                    </tr>
                </thead>
                <tbody style="background:#21c55e;">
                    <?php if (mysqli_num_rows($result) > 0) { ?>
                        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                            <tr>
                                <td><?php echo $row['surname']; ?></td>
                                <td><?php echo $row['othernames']; ?></td>
                                <td><?php echo $row['matricNumber']; ?></td>
                                <td><?php echo $row['phoneNumber']; ?></td>
                                <td><?php echo $row['start_date']; ?></td>
                                <td><?php echo $row['end_date']; ?></td>
                                <td><?php echo $row['reason']; ?></td>
                                <td class="text-left">
                                    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                                        <input type="hidden" name="student_id" value="<?php echo $row['student_id']; ?>">
                                        <a href="update_exeat.php?student_id=<?php echo $row["student_id"]; ?>"
                                            class="text-blue-500">Update</a>
                                    </form>
                                </td>
                            </tr>
                        <?php } ?>
                    <?php } else { ?>
                        <tr>
                            <td colspan="12">No student details found</td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
        <?php include 'include/footer.php' ?>
    </div>
</body>

</html>
<script>
    function updateDateTime() {
        const dateTimeElement = document.getElementById('currentDateTime');
        const now = new Date();
        const date = now.toLocaleDateString();
        const time = now.toLocaleTimeString();
        dateTimeElement.textContent = `Date: ${date} | Time: ${time}`;
    }

    // Update the date and time every second
    setInterval(updateDateTime, 1000);

    // Initial call to display the date and time
    updateDateTime();
</script>
<script>
    document.getElementById('toggleButton').addEventListener('click', function () {
        document.getElementById('sidebar').classList.toggle('hidden');
    });
</script>
<!-- Include jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<!-- Include DataTables JavaScript -->
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script>

    $(document).ready(function () {
        $('#student-details-table').DataTable();
    });
</script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var table = document.getElementById('student-details-table');
        var rows = table.getElementsByTagName('tr');

        for (var i = 1; i < rows.length; i++) {
            var cell = document.createElement('td');
            cell.textContent = i;
            cell.style.border = '1px solid lightgray'; // Add border style
            cell.style.textAlign = 'center'; // Center text horizontally
            rows[i].insertBefore(cell, rows[i].firstChild);
        }
    });
</script>
<script src="js/adminscript.js"></script>