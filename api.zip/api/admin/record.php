<?php
include ("../include/connection.php");
session_start();
if (!isset($_SESSION["username"])) {
    header("Location: ../index.php");
    exit;
}
// Fetch moderators from tblmoderator
$moderator_query = "SELECT m.mod_id, m.surname, m.othernames, m.block_id, h.hostel FROM tblmoderator m INNER JOIN tblhostels h on m.hostel_id = h.id";
$moderator_result = $connect->query($moderator_query);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin:: Record</title>
    <link rel="stylesheet" href="../dist/output.css">
    <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
</head>
<style>
    @media (min-width: 1024px) {
        .pc-view-padding {
            padding-left: 305px;
        }
    }
</style>

<body class="w-full lg:flex-row lg:min-h-100vh lg:flex bg-gray-100 ">
    <?php include 'include/header.php'; ?>
    <div class="w-full h-full py-2 lg:px-5 pc-view-padding">
         <!-- Current Time -->
         <div class="w-full flex items-center justify-center mb-1 mt-2 lg:p-0 lg:hidden">
            <div id="currentDateTime" class="text-green-950 w-2/3 p-2 rounded-xl bg-gray-50 text-sm text-center font-medium
                        shadow-gray-300 shadow-md lg:text-center lg:w-full lg:rounded-md lg:text-lg"></div>
        </div>
        <!-- Current time end here -->
        <div class="text-lg text-center font-bold text-green-800 py-4 bg-white shadow-lg rounded hidden lg:block mb-4">
        JABU_CAMS - ATTENDANCE REPORT</div>
        <div class="lg:flex">
            <!-- INDIVIDUAL Report -->
            <div class="lg:w-1/2 max-h-screen mx-2 shadow-sm bg-inherit backdrop-blur-md rounded-md py-4 px-6 flex flex-col items-center justify-center mb-4"
                style="box-shadow: 0 2px 10px gray;">
                <h1 class="text-xl font-semibold mb-4 text-green-800">Individual Student Attendance Report</h1>
                <form method="post" class="w-full mb-5 flex flex-col items-center justify-center"
                    action="studentrecord.php">
                    <div class="w-full mb-4">
                        <label class="block text-green-800 text-sm font-bold mb-2 " for="matric_number">Matric
                            Number:</label>
                        <input
                            class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                            type="text" name="matric_number" id="matric_number" required>
                    </div>
                    <div class="w-full mb-4">
                        <label class="block text-green-800 text-sm font-bold mb-2" for="start_date">Start Date:</label>
                        <input
                            class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                            type="date" name="start_date" id="start_date" required>
                    </div>
                    <div class="w-full mb-4">
                        <label class="block text-green-800 text-sm font-bold mb-2" for="end_date">End Date:</label>
                        <input
                            class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                            type="date" name="end_date" id="end_date" required>
                    </div>
                    <div class="w-full text-center">
                        <button
                            class="w-full bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline flex items-center justify-center"
                            type="submit"> <span class="material-symbols-outlined text-white px-2">visibility</span>View Report</button>
                    </div>
                </form>
            </div>
            <!-- ALL STUDENT RECORD -->
            <div class="lg:w-1/2 mx-2 mb-4 shadow-sm bg-inherit backdrop-blur-md rounded-md py-4 px-6 flex flex-col items-center justify-center lg:mt-0"
                style="box-shadow: 0 2px 10px gray;">
                <h1 class="text-xl font-semibold px-3 mb-2 text-green-800">All Student Attendance Report</h1>
                <form action="include/generate_pdf.php" method="post" class="w-full rounded-lg px-3 py-2">
                    <div class="mb-4 w-full">
                        <label for="moderator" class="block text-green-800 font-bold mb-2">Select Moderator:</label>
                        <select name="mod_id" id="moderator"
                            class="block w-full p-2 border border-gray-300 rounded outline-none" required>
                            <!-- Disabled option for selecting moderator -->
                            <option value="" disabled selected>Select Moderator</option>
                            <!-- Populate moderator options dynamically -->
                            <?php
                            if ($moderator_result->num_rows > 0) {
                                while ($row = $moderator_result->fetch_assoc()) {
                                    echo "<option value='" . $row['mod_id'] . "'>" . $row['hostel'] . " Block: " . $row['block_id'] . " - " . $row['surname'] . " " . $row['othernames'] . "</option>";
                                }
                            } else {
                                echo "<option value=''>No moderators found</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="mb-4 w-full">
                        <label for="start_date" class="block text-green-800 font-bold mb-2">From:</label>
                        <input type="date" name="start_date" id="start_date"
                            class="block w-full p-2 border border-gray-300 rounded outline-none" required>
                    </div>
                    <div class="mb-4 w-full">
                        <label for="end_date" class="block text-green-800 font-bold mb-2">To:</label>
                        <input type="date" name="end_date" id="end_date"
                            class="block w-full p-2 border border-gray-300 rounded outline-none" required>
                    </div>
                    <div class=" w-full">
                        <button type="submit"
                            class="w-full bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline flex items-center justify-center"> <span class="material-symbols-outlined text-white px-2">download</span>Download
                            PDF</button>
                    </div>
                </form>
            </div>
        </div>
        <?php include 'include/footer.php' ?>
    </div>
</body>

</html>

<!-- SCRIPTS -->
<script>
    function updateDateTime() {
        const dateTimeElement = document.getElementById('currentDateTime');
        const now = new Date();
        const date = now.toLocaleDateString();
        const time = now.toLocaleTimeString();
        dateTimeElement.textContent = `Date: ${date} | Time: ${time}`;
    }

    // Update the date and time every second
    setInterval(updateDateTime, 1000);

    // Initial call to display the date and time
    updateDateTime();
</script>
<script>
    document.getElementById('toggleButton').addEventListener('click', function () {
        document.getElementById('sidebar').classList.toggle('hidden');
    });
</script>
<script src="js/search.js"></script>
<script src="js/drop.js"></script>
<script src="js/adminscript.js"></script>