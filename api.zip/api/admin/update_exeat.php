<?php
include ("../include/connection.php");
session_start();
if (!isset($_SESSION["username"])) {
    header("Location: ../index.php");
    exit;
}

// Check if student_id is provided in the URL
if (isset($_GET["student_id"])) {
    $student_id = $_GET["student_id"];

    // Fetch student details from the database
    $fetch_query = "SELECT * FROM tblexeat WHERE student_id = '$student_id'";
    $result = $connect->query($fetch_query);

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
    }
}
?><!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../dist/output.css">
    <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
</head>
<style>
    @media (min-width: 1024px) {
        .pc-view-padding {
            padding-left: 350px;
        }
    }
</style>

<body class="w-full max-h-full">
    <?php include 'include/header.php'; ?>
    <div class="w-full py-2 lg:px-5 pc-view-padding">
        <!-- Current Time -->
        <div class="w-full p-2 flex items-center justify-center mb-4 lg:p-0">
            <div id="currentDateTime" class="text-green-950 w-2/3 p-2 rounded-xl bg-gray-100 text-sm text-center font-medium
    shadow-gray-300 shadow-md lg:text-center lg:w-full lg:rounded-md lg:text-lg"></div>
        </div>
        <!-- Current time end here -->
        <!-- Display user details if fetched -->
        <?php if (isset($row)): ?>
            <div class="w-full px-4 lg:px-20 lg:py-2 mt-4">
                <!-- Display user details here -->
                <div class="flex flex-col">
                    <form class="w-full bg-white mt-1 shadow-lg p-8" method="POST" action="include/updateexeat.php">
                        <input type="hidden" name="student_id" value="<?php echo $row['student_id']; ?>">
                        <h1 class="text-lg font-bold mb-5 text-center underline text-green-800">Update Exeat Form</h1>
                        <div class="lg:flex w-full">
                            <div class="flex flex-col w-full px-2">
                                <div class="mb-4">
                                    <label class="block  text-green-800 text-sm font-bold mb-2"
                                        for="surname">Surname:</label>
                                    <input
                                        class="shadow appearance-none border rounded w-full py-2 px-3 text-black leading-tight focus:outline-none focus:shadow-outline"
                                        id="surname" type="text" name="surname" value="<?php echo $row['surname']; ?>"
                                        required>
                                </div>
                                <div class="mb-4">
                                    <label class="block  text-green-800 text-sm font-bold mb-2" for="othernames">Other
                                        Names:</label>
                                    <input
                                        class="shadow appearance-none border rounded w-full py-2 px-3 text-black leading-tight focus:outline-none focus:shadow-outline"
                                        id="othernames" type="text" name="othernames"
                                        value="<?php echo $row['othernames']; ?>" required>
                                </div>
                                <div class="mb-4">
                                    <label class="block  text-green-800 text-sm font-bold mb-2" for="matricNumber">Matric
                                        Number:</label>
                                    <input
                                        class="shadow appearance-none border rounded w-full py-2 px-3 text-black leading-tight focus:outline-none focus:shadow-outline"
                                        id="matricNumber" type="text" name="matricNumber"
                                        value="<?php echo $row['matricNumber']; ?>" required>
                                </div>
                            </div>
                            <div class="flex flex-col w-full px-2">
                                <div class="mb-4">
                                    <label class="block  text-green-800 text-sm font-bold mb-2" for="start_date">Start
                                        Date:</label>
                                    <input
                                        class="shadow appearance-none border rounded w-full py-2 px-3 text-black leading-tight focus:outline-none focus:shadow-outline"
                                        id="start_date" type="date" name="start_date"
                                        value="<?php echo $row['start_date']; ?>" required>
                                </div>
                                <div class="mb-4">
                                    <label class="block  text-green-800 text-sm font-bold mb-2" for="end_date">End
                                        Date:</label>
                                    <input
                                        class="shadow appearance-none border rounded w-full py-2 px-3 text-black leading-tight focus:outline-none focus:shadow-outline"
                                        id="end_date" type="date" name="end_date" value="<?php echo $row['end_date']; ?>"
                                        required>
                                </div>
                                <div class="mb-4">
                                    <label class="block  text-green-800 text-sm font-bold mb-2" for="reason">Reason:</label>
                                    <input
                                        class="shadow appearance-none border rounded w-full py-2 px-3 text-black leading-tight focus:outline-none focus:shadow-outline"
                                        id="reason" name="reason" rows="4" value="<?php echo $row['reason']; ?>"
                                        required></input>
                                </div>
                            </div>
                        </div>
                        <div class="mb-4">
                            <button
                                class="w-full bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                                type="submit">Update Exeat</button>
                        </div>
                    </form>
                </div>
            </div>
        <?php endif; ?>
        <?php include 'include/footer.php'; ?>
    </div>
</body>

</html>
<!-- SCRIPTS -->
<script src="/js/adminscript.js"></script>
<script>
    function updateDateTime() {
        const dateTimeElement = document.getElementById('currentDateTime');
        const now = new Date();
        const date = now.toLocaleDateString();
        const time = now.toLocaleTimeString();
        dateTimeElement.textContent = `Date: ${date} | Time: ${time}`;
    }

    // Update the date and time every second
    setInterval(updateDateTime, 1000);

    // Initial call to display the date and time
    updateDateTime();

    document.getElementById('toggleButton').addEventListener('click', function () {
        document.getElementById('sidebar').classList.toggle('hidden');
    });

    document.getElementById('dropdown-button').addEventListener('click', function () {
        var menu = document.getElementById('dropdown-menu');
        if (menu.classList.contains('hidden')) {
            menu.classList.remove('hidden');
        } else {
            menu.classList.add('hidden');
        }
    });

    document.addEventListener('click', function (event) {
        var menu = document.getElementById('dropdown-menu');
        var button = document.getElementById('dropdown-button');
        if (!menu.contains(event.target) && event.target !== button) {
            menu.classList.add('hidden');
        }
    });
</script>