<?php
include ("../include/connection.php");
session_start();
if (!isset($_SESSION["username"])) {
    header("Location: ../index.php");
    exit;
}
?>
<?php
// Include FPDF library
require ('../fpdf/fpdf.php');

// Include your database connection file or establish a connection here
include ("../include/connection.php");

// Fetch moderators from tblmoderator
?><!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin:: Student Record</title>
    <link rel="stylesheet" href="../dist/output.css">
    <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
</head>
<style>
    @media (min-width: 1024px) {
        .pc-view-padding {
            padding-left: 300px;
        }
    }
</style>
<body class="w-full lg:flex-row lg:min-h-100vh lg:flex bg-gray-100 ">
    <?php include 'include/header.php'; ?>
    <div class="w-full h-full py-2 lg:px-5 pc-view-padding">
         <!-- Current Time -->
         <div class="w-full flex items-center justify-center mb-1 mt-2 lg:p-0 lg:hidden">
            <div id="currentDateTime" class="text-green-950 w-2/3 p-2 rounded-xl bg-gray-50 text-sm text-center font-medium
                        shadow-gray-300 shadow-md lg:text-center lg:w-full lg:rounded-md lg:text-lg"></div>
        </div>
        <!-- Current time end here -->
        <div class="text-lg text-center font-bold text-green-800 py-4 bg-white shadow-lg rounded hidden lg:block mb-4">
        JABU_CAMS - STUDENTS ATTENDANCE RECORD</div>
            <?php
            // Check if form is submitted
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Get input data
                $matric_number = $_POST["matric_number"];
                $start_date = $_POST["start_date"];
                $end_date = $_POST["end_date"];

                // Database connection parameters
                include ("../include/connection.php");

                // SQL query to fetch attendance records for the given matriculation number and date range
                $sql = "SELECT a.attendance_id, s.surname, s.othernames, s.matricNumber,s.gender, p.program_name, a.attendance_status, a.attendance_date, a.timestamp
                FROM tblattendance AS a
                INNER JOIN tblstudents AS s ON a.student_id = s.student_id
                INNER JOIN tblprograms AS p ON a.program_id = p.program_id
                WHERE s.matricNumber = '$matric_number'
                AND a.attendance_date BETWEEN '$start_date' AND '$end_date'";
                $result = $connect->query($sql);

                // Display attendance records if available
                if ($result && $result->num_rows > 0) {
                    echo "<table class='w-full text-normal bg-gray-100'>";
                    echo "<thead class='w-full text-normal bg-green-600 text-gray-50'>
                <tr>
                <th class='border px-2 py-2'>Surname</th>
                <th class='border px-2 py-2'>Othername</th>
                <th class='border px-2 py-2'>Gender</th>
                <th class='border px-2 py-2'>Matric Number</th>
                <th class='border px-2 py-2'>Program</th>
                <th class='border px-2 py-2'>Status</th>
                <th class='border px-2 py-2'>Date</th>
                <th class='border px-2 py-2'>Time</th>
                </tr>
                </thead>
                <tbody>";
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                <td class='border px-2 py-2'>" . $row["surname"] . "</td>
                <td class='border px-2 py-2'>" . $row["othernames"] . "</td>
                <td class='border px-2 py-2'>" . $row["gender"] . "</td>
                <td class='border px-2 py-2'>" . $row["matricNumber"] . "</td>
                <td class='border px-2 py-2'>" . $row["program_name"] . "</td>
                <td class='border px-2 py-2 text-center'>" . ($row["attendance_status"] == 1 ? "Present" : "Absent") . "</td>
                <td class='border px-2 py-2'>" . $row["attendance_date"] . "</td>
                <td class='border px-2 py-2'>" . $row["timestamp"] . "</td>
                </tr>";
                    }
                    echo "</tbody></table>";
                } else {
                    echo "<p class='text-red-500 mt-4'>No attendance records found for the specified matriculation number and date range.</p>";
                }
            }
            ?>
        </div>
        <?php include 'include/footer.php' ?>
    </div>

</body>

</html>

<!-- SCRIPTS -->
<script>
    function updateDateTime() {
        const dateTimeElement = document.getElementById('currentDateTime');
        const now = new Date();
        const date = now.toLocaleDateString();
        const time = now.toLocaleTimeString();
        dateTimeElement.textContent = `Date: ${date} | Time: ${time}`;
    }

    // Update the date and time every second
    setInterval(updateDateTime, 1000);

    // Initial call to display the date and time
    updateDateTime();
</script>
<script>
    document.getElementById('toggleButton').addEventListener('click', function () {
        document.getElementById('sidebar').classList.toggle('hidden');
    });
</script>
<script src="js/search.js"></script>
<script src="js/drop.js"></script>
<script src="js/adminscript.js"></script>