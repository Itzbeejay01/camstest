<?php
include("../include/connection.php");
session_start();
if (!isset($_SESSION["username"])) {
    header("Location: ../index.php");
    exit;
}
?><!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../dist/output.css">
    <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
</head>
<style>
    @media (min-width: 1024px) {
        .pc-view-padding {
            padding-left: 310px;
        }
    }
</style>

<body class="w-full max-h-full bg-gray-100 ">

    <?php include 'include/header.php'; ?>
    <!-- MODERATOR REGISTRTATION DASHBOARD -->
    <div class="w-full flex flex-col lg:px-14 pc-view-padding">
        <!-- Current Time -->
        <div class="w-full flex items-center justify-center mb-1 mt-2 lg:p-0 lg:hidden">
            <div id="currentDateTime" class="text-green-950 w-2/3 p-2 rounded-xl bg-gray-100 text-sm text-center font-medium
                        shadow-gray-300 shadow-md lg:text-center lg:w-full lg:rounded-md lg:text-lg"></div>
        </div>
        <!-- Current time end here -->
        <div class="text-lg text-center font-bold text-green-800 py-4 bg-white shadow-lg rounded hidden lg:block mb-4">
            JABU_CAMS - UPDATE MODERATOR</div>
        <div class="w-full px-4 lg:px-2">
            <?php
            // Assuming you have a database connection established already
            include("../include/connection.php");

            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Process form data when form is submitted
                $id = $_POST['mod_id'];
                $surname = $_POST['surname'];
                $othernames = $_POST['othernames'];
                $marking_for_gender = $_POST['marking_for_gender'];
                $email = $_POST['email'];
                $hostel_id = $_POST['hostel_id'];
                $block_id = isset($_POST['block_id']) ? $_POST['block_id'] : 'NULL'; // Allow NULL
                $password = $_POST['password'];
                $hashed_password = hash('sha256', $password); // Hash the password using SHA256
            
                // Update user details in the database
                if ($block_id === 'NULL') {
                    $sql = "UPDATE tblmoderator 
                                SET surname='$surname', othernames='$othernames', marking_for_gender='$marking_for_gender', email='$email', hostel_id='$hostel_id', block_id=NULL, password='$hashed_password' 
                                WHERE mod_id=$id";
                } else {
                    $sql = "UPDATE tblmoderator 
                                SET surname='$surname', othernames='$othernames', marking_for_gender='$marking_for_gender', email='$email', hostel_id='$hostel_id', block_id='$block_id', password='$hashed_password' 
                                WHERE mod_id=$id";
                }
                if (mysqli_query($connect, $sql)) {
                    echo '<div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
                   <p class="font-bold">User updated successfully.</p>
                    </div>';
                } else {
                    echo "Error updating user: " . mysqli_error($connect);
                }
            }

            // Fetch user details based on ID from the query string
            if (isset($_GET['mod_id'])) {
                $id = $_GET['mod_id'];
                $sql = "SELECT * FROM tblmoderator WHERE mod_id=$id";
                $result = mysqli_query($connect, $sql);

                if (mysqli_num_rows($result) == 1) {
                    $row = mysqli_fetch_assoc($result);
                } else {
                    echo "User not found";
                    exit();
                }
            }
            // HTML structure starts here
            ?>

            <form class="w-full h-full bg-white rounded-lg mt-4 shadow-lg flex flex-col lg:p-10" method="POST"
                action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="w-full lg:flex lg:items-center lg:justify-center p-5">
                    <input type="hidden" name="mod_id" value="<?php echo $row['mod_id']; ?>">
                    <div class="w-full h-full px-4 ">
                        <div class="mb-4">
                            <label class="block text-gray-700 text-sm font-bold mb-2" for="username">Surname:</label>
                            <input
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                id="username" type="text" name="surname" value="<?php echo $row['surname']; ?>"
                                required>
                        </div>
                        <div class="mb-4">
                            <label class="block text-gray-700 text-sm font-bold mb-2" for="username">Othernames:</label>
                            <input
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                id="username" type="text" name="othernames" value="<?php echo $row['othernames']; ?>"
                                required>
                        </div>
                        <div class="mb-4">
                            <label class="block text-gray-700 text-sm font-bold mb-2" for="gender">Gender:</label>
                            <select id="marking_for_gender" name="marking_for_gender"
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                required>
                                <option value="" disabled selected>Select Gender</option>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                            </select>
                        </div>
                        <div class="mb-4">
                            <label class="block text-gray-700 text-sm font-bold mb-2" for="email">Email:</label>
                            <input
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                id="email" type="email" name="email" value="<?php echo $row['email']; ?>" required>
                        </div>
                    </div>
                    <div class="w-full h-full px-4  lg:top-0">
                        <div class="mb-4">
                            <label class="block text-gray-700 text-sm font-bold mb-2" for="email">Hostel:</label>
                            <input
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                id="email" type="text" name="hostel_id" value="<?php echo $row['hostel_id']; ?>"
                                required>
                        </div>
                        <div class="mb-4">
                            <label class="block text-gray-700 text-sm font-bold mb-2" for="email">Block</label>
                            <input
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                id="email" type="text" name="block_id" placeholder="Type NULL for hostel without block"
                                value="<?php echo $row['block_id']; ?>" required>
                        </div>
                        <div class="mb-4">
                            <label class="block text-gray-700 text-sm font-bold mb-2" for="username">Password:</label>
                            <input
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                id="username" type="password" name="password" alue="<?php echo $row['password']; ?>"
                                required>
                        </div>
                    </div>
                </div>
                <div class="mb-4 w-full flex items-center justify-center">
                    <button
                        class="w-1/2 bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                        type="submit">Update</button>
                </div>
            </form>
        </div>
        <?php
        // Close connection
        mysqli_close($connect);
        ?>
        <?php include 'include/footer.php' ?>

    </div>
</body>
<!-- SCRIPTS -->
<script>
    function updateDateTime() {
        const dateTimeElement = document.getElementById('currentDateTime');
        const now = new Date();
        const date = now.toLocaleDateString();
        const time = now.toLocaleTimeString();
        dateTimeElement.textContent = `Date: ${date} | Time: ${time}`;
    }

    // Update the date and time every second
    setInterval(updateDateTime, 1000);

    // Initial call to display the date and time
    updateDateTime();
</script>
<script>
    document.getElementById('toggleButton').addEventListener('click', function () {
        document.getElementById('sidebar').classList.toggle('hidden');
    });
</script>
<script src="js/moderator.js"></script>
<script src="js/adminscript.js"></script>
</body>

</html>