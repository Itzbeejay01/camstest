<?php
// Include the file with database connection parameters
include '../include/connection.php';

// Function to toggle page status
function togglePageStatus()
{
    global $conn;

    // Get current status
    $status = getPageStatus('program');

    // Toggle status
    $newStatus = ($status == 'enabled') ? 'disabled' : 'enabled';

    // Update status in the database
    $sql = "UPDATE page_status SET status='$newStatus' WHERE page_id='program'";

    if ($conn->query($sql) === TRUE) {
        echo "Page status updated successfully";
    } else {
        echo "Error updating page status: " . $conn->error;
    }
}

// Function to get page status
function getPageStatus($pageId)
{
    global $conn;

    // Query database for page status
    $sql = "SELECT status FROM page_status WHERE page_id = '$pageId'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row["status"];
    } else {
        return "Status not found";
    }
}
?>