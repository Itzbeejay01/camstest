<?php
//include "../../include/connection.php";
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['exeat'])) {
    // Initialize variables from $_POST array
    $student_id = $_POST['student_id'];
    $surname = $_POST['surname'];
    $othernames = $_POST['othernames'];
    $matricNumber = $_POST['matricNumber'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $reason = $_POST['reason'];

    // Insert data into tblexeat table
    $insert_query = "INSERT INTO tblexeat (student_id, surname, othernames, matricNumber, start_date, end_date, reason) 
                     VALUES ('$student_id', '$surname', '$othernames', '$matricNumber', '$start_date', '$end_date', '$reason')";

    if (mysqli_query($connect, $insert_query)) {
        echo '<div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
                <p class="font-bold">Exeat submitted successfully!</p> </div>';
    } else {
        echo '<div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
                <p class="font-bold">Error submitting exeat: ' . mysqli_error($connect) . '</p> </div>';
    }
}
?>