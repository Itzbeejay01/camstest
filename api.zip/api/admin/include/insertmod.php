<?php
if (isset($_POST['submit'])) {
    $surname = strip_tags($_POST['surname']);
    $othernames = strip_tags($_POST['othernames']);
    $marking_for_gender = $_POST['marking_for_gender'];
    $email = strip_tags($_POST['email']);
    $hostel_id = strip_tags($_POST['hostel_id']);
    $block_id = isset($_POST['block_id']) ? strip_tags($_POST['block_id']) : null; // Allow NIL
    $password = $_POST['password'];
    $hashed_password = hash('sha256', $password);

    // Check if email already exists
    $check_email = $connect->query("SELECT email FROM tblmoderator WHERE email='$email'");
    $count = $check_email->num_rows;
    if ($count == 0) {
        // Handle the block field when it's NULL
        if ($block_id === null) {
            $query = "INSERT INTO tblmoderator (surname, othernames, marking_for_gender, email, hostel_id, password) VALUES ('$surname', '$othernames', '$marking_for_gender', '$email', '$hostel_id', '$hashed_password')";
        } else {
            $query = "INSERT INTO tblmoderator (surname, othernames, marking_for_gender, email, hostel_id, block_id, password) VALUES ('$surname', '$othernames', '$marking_for_gender', '$email', '$hostel_id','$block_id', '$hashed_password')";
        }

        if ($connect->query($query)) {
            echo '<div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
            <p class="font-bold">Moderator added successfully!</p>
            </div>';
        } else {
            // Handle database insertion error
            echo '<div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
            <p class="font-bold">Error: ' . $connect->error . '</p>
            </div>';
        }
    } else {
        echo '<div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
            <p class="font-bold">Sorry! Moderator already exists!</p>
        </div>';
    }
    $connect->close();
}
?>