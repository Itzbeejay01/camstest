<?php
require ('../../fpdf/fpdf.php');

// Include your database connection file or establish a connection here
include ("../../include/connection.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve selected mod_id, start_date, and end_date from the form
    $mod_id = $_POST['mod_id'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    // Fetch moderator's surname and associated hostel name
    $moderator_query = "SELECT m.surname, m.othernames, h.hostel 
                        FROM tblmoderator m 
                        INNER JOIN tblhostels h ON m.hostel_id = h.id 
                        WHERE m.mod_id = '$mod_id'";
    $moderator_result = $connect->query($moderator_query);
    $moderator_row = $moderator_result->fetch_assoc();

    // Fetch attendance records including student names and program names based on the mod_id and date range
    $query = "SELECT A.student_id, A.attendance_status, A.attendance_date, A.timestamp, S.surname, S.othernames, P.program_name 
              FROM tblattendance A 
              JOIN tblstudents S ON A.student_id = S.student_id
              JOIN tblprograms P ON A.program_id = P.program_id
              WHERE A.mod_id = '$mod_id' 
              AND DATE(A.attendance_date) BETWEEN '$start_date' AND '$end_date'";
    $result = $connect->query($query);

    // Check for errors
    if (!$result) {
        die("Query execution failed: " . $connect->error);
    }

    // Create PDF
    $pdf = new FPDF();
    $pdf->AddPage();

    // Set logo as header aligned with hostel name
    $pdf->Image('../../img/logo.png', 10, 10, 27);

    $pdf->SetFont('Helvetica', 'B', 12);
    $pdf->SetFillColor(100, 100, 100); // Light blue
    $pdf->SetTextColor(0, 0, 0); // Black
    // Set hostel name as the header aligned with the logo
    $pdf->Cell(0, 10, $moderator_row['hostel'] . ' Moderated by ' . $moderator_row['surname'] . ' ' . $moderator_row['othernames'], 0, 1, 'C');
    $pdf->Cell(0, 10, 'Range: ' . $start_date . ' to ' . $end_date, 0, 1, 'C'); // Date range
    $pdf->Ln(5); // Add some space
    $pdf->SetTextColor($fill ? 255 : 255, $fill ? 255 : 255, $fill ? 255 : 255);
    $pdf->Cell(15, 10, 'S/N', 1, 0, 'C', true); // Add color to the header row
    $pdf->Cell(38, 10, 'Surname', 1, 0, 'C', true);
    $pdf->Cell(34, 10, 'Othernames', 1, 0, 'C', true);
    $pdf->Cell(39, 10, 'Program', 1, 0, 'C', true);
    $pdf->Cell(20, 10, 'Status', 1, 0, 'C', true);
    $pdf->Cell(27, 10, 'Date', 1, 0, 'C', true);
    $pdf->Cell(22, 10, 'Time', 1, 1, 'C', true);

    // Set table rows with alternating colors and styling
    $pdf->SetFont('Arial', '', 12);
    $fill = false;
    $counter = 1; // Initialize counter variable
    while ($row = $result->fetch_assoc()) {
        // Define attendance status text
        $attendanceStatus = $row['attendance_status'] == 1 ? 'Present' : 'Absent';
        $pdf->SetTextColor(0, 0, 0);
        $pdf->SetFillColor($fill ? 216 : 1, $fill ? 216 : 1, $fill ? 216 : 240);
        $pdf->Cell(15, 10, $counter++, 1, 0, 'C', $fill);
        $pdf->Cell(38, 10, $row['surname'], 1, 0, 'C', $fill);
        $pdf->Cell(34, 10, $row['othernames'], 1, 0, 'C', $fill);
        $pdf->Cell(39, 10, $row['program_name'], 1, 0, 'C', $fill);
        $pdf->Cell(20, 10, $attendanceStatus, 1, 0, 'C', $fill); // Display attendance status text
        $pdf->Cell(27, 10, $row['attendance_date'], 1, 0, 'C', $fill);
        $pdf->Cell(22, 10, $row['timestamp'], 1, 1, 'C', $fill);
        $fill = !$fill; // Toggle fill color for each row
    }

    $pdf->Output();
}
?>