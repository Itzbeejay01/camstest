<div class="w-full lg:w-full lg:flex justify-center lg:items-center">
    <!-- MOBILE VIEW -->
    <header class="w-full h-full bg-gray-200 p-4 header flex items-center justify-between px-5 lg:hidden top-0">
        <div class="flex items-center justify-center">
            <button type="hamburger" name="hamburger" id="toggleButton"><span
                    class="material-symbols-outlined bg-gray-50 p-2 rounded-md shadow-green-900 shadow-md font-bold text-2xl mr-2 text-green-600 hover:bg-green-800 hover:text-green-50">menu</span></button>
            <p class="text-lg font-medium mx-2">Welcome, <?php echo $_SESSION["username"]; ?></p>
        </div>
        <a href="logout.php"><span
                class="material-symbols-outlined bg-gray-50 p-2 rounded-md shadow-green-900 shadow-md font-bold text-2xl mr-2 text-green-600 hover:bg-green-800 hover:text-green-50">power_settings_new</span></a>
    </header>
    <!-- PC VIEW SIDEBAR START HERE -->
    <aside class="h-screen bg-gray-300 header p-4 lg:flex lg:flex-col items-center px-5 hidden fixed"
        style="top:0; left:0; width:280px; z-index:20;">
        <div class="flex w-full justify-between">
            <div class="flex items-center justify-center">
                <ion-icon name="menu"
                    class="bg-gray-50 p-2 rounded-md font-bold text-2xl mr-2 text-green-800 shadow-green-900 shadow-lg lg:hidden"></ion-icon>
                <p class="text-lg font-medium mx-2">Welcome, <?php echo $_SESSION["username"]; ?></p>
            </div>
            <a href="logout.php"><span
                    class="material-symbols-outlined bg-gray-50 p-2 rounded-md shadow-green-700 shadow-sm font-bold text-2xl mr-2 text-green-700 hover:bg-green-800 hover:text-red-50">power_settings_new</span></a>
        </div>

        <div class="w-full h-1 rounded-full mt-3 bg-green-700"></div>

        <div class="flex flex-col mt-4 w-full justify-between">
            <!-- Dashboard -->
            <a href="index.php" class="mb-5">
                <div
                    class="shadow-xl rounded-lg bg-slate-50 py-4 font-medium flex items-center hover:bg-slate-200 px-5">
                    <span class="material-symbols-outlined text-2xl">home</span>
                    <p class="text-md mx-5">Dashboard</p>
                </div>
            </a>
            <!-- moderator -->
            <a href="addmod.php" class="mb-5">
                <div
                    class="shadow-xl rounded-lg bg-slate-50 py-4 font-medium flex items-center hover:bg-slate-200 px-5">
                    <span class="material-symbols-outlined text-2xl">add_moderator</span>
                    <p class="text-md mx-5">Moderator</p>
                </div>
            </a>
            <!-- Access Control -->
            <a href="access.php" class="mb-5">
                <div
                    class="shadow-xl rounded-lg bg-slate-50 py-4 font-medium flex items-center hover:bg-slate-200 px-5">
                    <span class="material-symbols-outlined text-2xl">desktop_windows</span>
                    <p class="text-md mx-5">Access Control</p>
                </div>
            </a>
            <!-- Students -->
            <a href="students.php" class="mb-5">
                <div
                    class="shadow-xl rounded-lg bg-slate-50 py-4 font-medium flex items-center hover:bg-slate-200 px-5">
                    <span class="material-symbols-outlined text-2xl">person</span>
                    <p class="text-md mx-5">Students</p>
                </div>
            </a>
            <!-- Exeat -->
            <a href="exeat.php" class="mb-5">
                <div
                    class="shadow-xl rounded-lg bg-slate-50 py-4 font-medium flex items-center hover:bg-slate-200 px-5">
                    <span class="material-symbols-outlined text-2xl">person_off</span>
                    <p class="text-md mx-5">Exeat</p>
                </div>
            </a>
            <!-- download -->
            <a href="record.php">
                <div
                    class="shadow-xl rounded-lg bg-slate-50 py-4 font-medium flex items-center hover:bg-slate-200 px-5">
                    <span class="material-symbols-outlined text-2xl">cloud_download</span>
                    <p class="text-md mx-5">Report</p>
                </div>
            </a>
        </div>
    </aside>
    <!-- PC VIEW SIDEBAR END HERE -->

    <div class="w-full flex lg:flex lg:px-0 ">
        <!-- dropdown start here -->
        <div class="flex h-screen header backdrop:blur-xl bg-gray-300 lg:hidden shadow-lg rounded-lg">
            <div id="sidebar" class="w-64 h-full px-4 flex-shrink-0 hidden pt-2">
                <div class="flex flex-col w-full h-screen">
                    <!-- Dashboard -->
                    <a href="index.php" class="mb-5">
                        <div
                            class="shadow-xl rounded-lg bg-slate-50 py-4 font-medium flex items-center  hover:bg-slate-200 px-5">
                            <span class="material-symbols-outlined text-2xl">home</span>
                            <p class="text-sm mx-5">Dashboard</p>
                        </div>
                    </a>
                    <!-- moderator -->
                    <a href="addmod.php" class="mb-5">
                        <div
                            class="shadow-xl rounded-lg bg-slate-50 py-4 font-medium flex items-center  hover:bg-slate-200 px-5">
                            <span class="material-symbols-outlined text-2xl">add_moderator</span>
                            <p class="text-sm mx-5">Moderator</p>
                        </div>
                    </a>
                    <!-- Access Control-->
                    <a href="access.php" class="mb-5">
                        <div
                            class="shadow-xl rounded-lg bg-slate-50 py-4 font-medium flex items-center  hover:bg-slate-200 px-5">
                            <span class="material-symbols-outlined text-2xl">desktop_windows</span>
                            <p class="text-sm mx-5">Access Control</p>
                        </div>
                    </a>
                    <!-- Students -->
                    <a href="students.php" class="mb-5">
                        <div
                            class="shadow-xl rounded-lg bg-slate-50 py-4 font-medium flex items-center  hover:bg-slate-200 px-5">
                            <span class="material-symbols-outlined text-2xl">person</span>
                            <p class="text-sm mx-5">Students</p>
                        </div>
                    </a>
                    <!-- Exeat -->
                    <a href="exeat.php" class="mb-5">
                        <div
                            class="shadow-xl rounded-lg bg-slate-50 py-4 font-medium flex items-center  hover:bg-slate-200 px-5">
                            <span class="material-symbols-outlined text-2xl">person_off</span>
                            <p class="text-sm mx-5">Exeat</p>
                        </div>
                    </a>
                    <!-- download -->
                    <a href="record.php">
                        <div
                            class="shadow-xl rounded-lg bg-slate-50 py-4 font-medium flex items-center  hover:bg-slate-200 px-5">
                            <span class="material-symbols-outlined text-2xl">cloud_download</span>
                            <p class="text-sm mx-5">Attendance Report</p>
                        </div>
                    </a>
                </div>
            </div>
        </div>
        <!-- dropdown ends here -->
        <div class=" w-full lg:px-0 h-screen">