<?php
session_start();

// Check if moderator is logged in
include ("../include/connection.php");
session_start();
if (!isset($_SESSION["username"])) {
  header("Location: ../index.php");
  exit;
}
?><!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin:: Exeat Updated</title>
  <link rel="stylesheet" href="../../dist/output.css">
  <link rel="shortcut icon" href="../../img/logo.png" type="image/x-icon">
  <link rel="stylesheet"
    href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
  <style>
    @media (min-width: 1024px) {
      .pc-view-padding {
        padding-left: 330px;
      }
    }
  </style>
</head>

<body class="w-full max-h-full lg:flex bg-gray-100 ">
  <?php include 'header.php'; ?>
  <div class="w-full px-4 pt-6 pc-view-padding">
    <!-- Current Time -->
    <div class="w-full p-2 flex items-center justify-center mb-4 lg:p-0">
      <div id="currentDateTime" class="text-green-950 w-2/3 p-2 rounded-xl bg-gray-100 text-sm text-center font-medium
    shadow-gray-300 shadow-md lg:text-center lg:w-full lg:rounded-md lg:text-lg"></div>
    </div>
    <!-- Current time end here -->
    <div class="bg-gray-50 p-8 rounded shadow-lg text-center mt-7">
      <h1 class="text-xl font-bold text-green-600 mb-4">Exeat information updated successfully!</h1>
      <p class="text-gray-600 mb-4">You will be redirected <a href="/admin/exeat.php" class="text-green-600"></a> in
        <span id="countdown">5</span> seconds.</p>

    </div>

    <script>
      let timeLeft = 5000;
      const countdown = document.getElementById('countdown');

      const timer = setInterval(() => {
        timeLeft--;
        countdown.textContent = timeLeft;

        if (timeLeft <= 0) {
          clearInterval(timer);
          window.location.href = '../exeat.php';
        }
      }, 1000);
    </script>
    <?php include 'footer.php' ?>
  </div>

  <!-- SCRIPTS -->
  <script src="/js/adminscript.js"></script>
  <script>
    function updateDateTime() {
      const dateTimeElement = document.getElementById('currentDateTime');
      const now = new Date();
      const date = now.toLocaleDateString();
      const time = now.toLocaleTimeString();
      dateTimeElement.textContent = `Date: ${date} | Time: ${time}`;
    }

    // Update the date and time every second
    setInterval(updateDateTime, 1000);

    // Initial call to display the date and time
    updateDateTime();
  </script>
  <script>
    document.getElementById('toggleButton').addEventListener('click', function () {
      document.getElementById('sidebar').classList.toggle('hidden');
    });
  </script>
  <script>
    document.getElementById('dropdown-button').addEventListener('click', function () {
      var menu = document.getElementById('dropdown-menu');
      if (menu.classList.contains('hidden')) {
        menu.classList.remove('hidden');
      } else {
        menu.classList.add('hidden');
      }
    });

    document.addEventListener('click', function (event) {
      var menu = document.getElementById('dropdown-menu');
      var button = document.getElementById('dropdown-button');
      if (!menu.contains(event.target) && event.target !== button) {
        menu.classList.add('hidden');
      }
    });
  </script>

</body>

</html>