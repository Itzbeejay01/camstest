<?php
// Assuming you have a database connection established already
include ("../../include/connection.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Process form data when form is submitted
    $student_id = $_POST['student_id'];
    $surname = $_POST['surname'];
    $othernames = $_POST['othernames'];
    $matricNumber = $_POST['matricNumber'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $reason = $_POST['reason'];

    // Check if the user with the provided student_id already exists
    $check_query = "SELECT * FROM tblexeat WHERE student_id = '$student_id'";
    $result = $connect->query($check_query);

    if ($result && $result->num_rows > 0) {
        // If the user exists, update the existing record
        $update_query = "UPDATE tblexeat SET surname='$surname', othernames='$othernames', matricNumber='$matricNumber', start_date='$start_date', end_date='$end_date', reason='$reason' WHERE student_id='$student_id'";
        if ($connect->query($update_query)) {
            header("Location:update_exeat_form.php");

        } else {
            echo '<div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
                            <p class="font-bold">Update error!</p> </div>';
        }
    }
}
?>