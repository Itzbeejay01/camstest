<?php
include ("../../include/connection.php");
session_start();
if (!isset($_SESSION["username"])) {
    header("Location: ../index.php");
    exit;
}
if (isset($_GET["mod_id"])) {
    $moderator_id = $_GET["mod_id"];
    // Sanitize the input (in this case, we're casting it to an integer)
    $moderator_id = (int) $moderator_id;
    $delete_query = "DELETE FROM tblmoderator WHERE mod_id = $moderator_id";

    if ($connect->query($delete_query)) {
        $connect->close();
        header("Location: " . $_SERVER['HTTP_REFERER']); // Redirect back to the previous page
        exit();
    } else {
        echo "Error deleting moderator: " . $connect->error;
    }
}
?>