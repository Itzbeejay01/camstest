<?php
// Include FPDF library
require ('../../fpdf/fpdf.php');

// Include your database connection file or establish a connection here
include ("../../include/connection.php");

// Create a class extending FPDF
class PDF extends FPDF
{
    // Page header
    function Header()
    {
        // Logo image
        $this->Image('../../img/logo.png', 10, 6, 30);
        // Arial bold 15
        $this->SetFont('Arial', 'B', 15);
        // Move to the right
        $this->Cell(80);
        // Title
        $this->Cell(30, 10, 'Student Attendance Record', 0, 0, 'C');
        // Line break
        $this->Ln(20);
    }

    // Page footer
    function Footer()
    {
        // Position at 1.5 cm from bottom
        $this->SetY(-15);
        // Arial italic 8
        $this->SetFont('Arial', 'I', 8);
        // Page number
        $this->Cell(0, 10, 'Page ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
    }
}

// Create PDF object
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();

// Set font
$pdf->SetFont('Arial', '', 12);

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get input data
    $matric_number = $_POST["matric_number"];
    $start_date = $_POST["start_date"];
    $end_date = $_POST["end_date"];

    // SQL query to fetch attendance records for the given matriculation number and date range
    $sql = "SELECT a.attendance_id, s.surname, s.othernames, s.matricNumber, p.program_name, a.attendance_status, a.attendance_date
            FROM tblattendance AS a
            INNER JOIN tblstudents AS s ON a.student_id = s.student_id
            INNER JOIN tblprograms AS p ON a.program_id = p.program_id
            WHERE s.matricNumber = '$matric_number'
            AND a.attendance_date BETWEEN '$start_date' AND '$end_date'";
    $result = $connect->query($sql);

    // Display attendance records if available
    if ($result && $result->num_rows > 0) {
        $pdf->SetFillColor(180, 180, 255);
        $pdf->Cell(30, 10, 'Surname', 1, 0, 'C', true);
        $pdf->Cell(30, 10, 'Othername', 1, 0, 'C', true);
        $pdf->Cell(40, 10, 'Matric Number', 1, 0, 'C', true);
        $pdf->Cell(40, 10, 'Program', 1, 0, 'C', true);
        $pdf->Cell(20, 10, 'Status', 1, 0, 'C', true);
        $pdf->Cell(40, 10, 'Date', 1, 1, 'C', true);
        while ($row = $result->fetch_assoc()) {
            $pdf->Cell(30, 10, $row["surname"], 1, 0);
            $pdf->Cell(30, 10, $row["othernames"], 1, 0);
            $pdf->Cell(40, 10, $row["matricNumber"], 1, 0);
            $pdf->Cell(40, 10, $row["program_name"], 1, 0);
            $pdf->Cell(20, 10, $row["attendance_status"], 1, 0);
            $pdf->Cell(40, 10, $row["attendance_date"], 1, 1);
        }
    } else {
        $pdf->Cell(0, 10, 'No attendance records found for the specified matriculation number and date range.', 0, 1);
    }
}

// Output PDF
$pdf->Output();
?>