<?php
include("../include/connection.php");
session_start();
if (!isset($_SESSION["username"])) {
    header("Location: ../index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../dist/output.css">
    <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
</head>
<style>
    @media (min-width: 1024px) {
        .pc-view-padding {
            padding-left: 350px;
        }
    }
</style>

<body class="w-full h-full">
    <?php include 'include/header.php'; ?>
    <!-- STUDENT DETAILS DASHBOARD -->
    <div class="w-full px-4 lg:px-10 py-4 pc-view-padding lg:py-0">
         <!-- Current Time -->
         <div class="w-full flex items-center justify-center mb-2 lg:p-0 lg:hidden">
            <div id="currentDateTime" class="text-green-950 p-2 rounded-xl bg-gray-50 text-sm text-center font-medium
                        shadow-gray-300 shadow-md lg:text-center lg:w-full lg:rounded-md lg:text-lg"></div>
        </div>
        <!-- Current time end here -->
        <div class="w-full text-lg text-center font-bold text-green-800 mt-6 py-4 bg-white shadow-lg rounded hidden lg:block mb-4">
        JABU_CAMS - STUDENT INFORMATION</div>
        <div class="w-full mx-auto px-2 py-2 bg-inherit backdrop-blur-sm shadow-md rounded-lg lg:px-5 lg:py-4">
            <?php
            // Fetch user details based on ID from the query string
            if (isset($_GET['student_id'])) {
                $student_id = $_GET['student_id'];
                $sql = "SELECT s.*, c.college, d.department, h.hostel 
                        FROM tblstudents s
                        INNER JOIN tblcollege c ON s.college = c.id
                        INNER JOIN tbldepartment d ON s.department = d.id
                        INNER JOIN tblhostels h ON s.hostel_id = h.id WHERE s.student_id=$student_id";
                $result = mysqli_query($connect, $sql);

                if (mysqli_num_rows($result) == 1) {
                    $row = mysqli_fetch_assoc($result);
                    ?>
                    <div class="lg:flex lg:w-full mb-4">
                        <div class="section lg:w-full mx-2">
                            <div class="section-title font-bold text-lg mb-2  text-green-800">Personal Information:</div>
                            <div class="section-content bg-gray-100 shadow-md shadow-gray-500 p-4 rounded-lg mb-4"
                                style="height: 230px;">
                                <p class="mb-2"><strong>Surname:</strong> <?php echo $row['surname']; ?></p>
                                <p class="mb-2"><strong>Othernames:</strong> <?php echo $row['othernames']; ?></p>
                                <p class="mb-2"><strong>Gender:</strong> <?php echo $row['gender']; ?></p>
                                <p class="mb-2"><strong>Phone Number:</strong> <?php echo $row['phoneNumber']; ?></p>
                            </div>
                        </div>
                        <div class="section lg:w-full mx-2">
                            <div class="section-title font-bold text-lg mb-2  text-green-800">Academic Information:</div>
                            <div class="section-content bg-gray-100 shadow-md shadow-gray-500 p-4 rounded-lg mb-4"
                                style="height: 230px;">
                                <p class="mb-2"><strong>College:</strong> <?php echo $row['college']; ?></p>
                                <p class="mb-2"><strong>Department:</strong> <?php echo $row['department']; ?></p>
                                <p class="mb-2"><strong>Matric Number:</strong> <?php echo $row['matricNumber']; ?></p>
                                <p class="mb-2"><strong>Email:</strong> <?php echo $row['email']; ?></p>
                                <p class="mb-2"><strong>Level:</strong> <?php echo $row['level']; ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="lg:flex lg:w-full">
                        <div class="section lg:w-full mx-2">
                            <div class="section-title font-bold text-lg mb-2  text-green-800">Accommodation Information:</div>
                            <div class="section-content bg-gray-100 shadow-md shadow-gray-500 p-4 rounded-lg mb-4"
                                style="height: 150px;">
                                <p class="mb-2"><strong>Hostel:</strong> <?php echo $row['hostel']; ?></p>
                                <p class="mb-2"><strong>Block:</strong> <?php echo $row['block']; ?></p>
                                <p class="mb-2"><strong>Room:</strong> <?php echo $row['roomNo']; ?></p>
                                <p class="mb-2"><strong>Space:</strong> <?php echo $row['bedSpace']; ?></p>
                            </div>
                        </div>
                        <!--STUDENT IMAGE -->
                        <div class="section lg:w-full mx-2">
                            <div class="section-title font-bold text-lg mb-2  text-green-800">Image:</div>
                            <div class="section-content bg-gray-100 shadow-md shadow-gray-500 p-4 rounded-lg mb-4"
                                style="height: 150px;">
                                <?php
                                // Fetch and display image
                                $image_extensions = ['jpg', 'jpeg', 'png', 'gif']; // Add more extensions as needed
                                $image_found = false;
                                foreach ($image_extensions as $extension) {
                                    $image_filename = $row['matricNumber'] . '.' . $extension;
                                    $image_path = '../uploads/' . $image_filename;
                                    if (file_exists($image_path)) {
                                        echo '<div class="image-container" style="width:100px;"><img src="' . $image_path . '" alt="Student Image" class="rounded-md"></div>';
                                        $image_found = true;
                                        break;
                                    }
                                }
                                if (!$image_found) {
                                    echo '<p>Image not found</p>';
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                    <?php
                } else {
                    echo '<p>User not found</p>';
                }
            }
            ?>
            <div class="w-full flex items-center justify-center">
                <a class="w-full flex items-center justify-center"
                    href="edit_student.php?student_id=<?php echo $row["student_id"]; ?>"><button
                        class="w-full bg-green-500 rounded-lg px-8 py-2 font-medium text-white hover:bg-green-700 mx-auto lg:w-1/2">Edit
                        Details</button></a>
            </div>
        </div>

        <div class="mt-5">
        <?php include 'include/footer.php' ?>
        </div>
    </div>
    <!-- SCRIPTS -->
    <script>
        function updateDateTime() {
            const dateTimeElement = document.getElementById('currentDateTime');
            const now = new Date();
            const date = now.toLocaleDateString();
            const time = now.toLocaleTimeString();
            dateTimeElement.textContent = `Date: ${date} | Time: ${time}`;
        }
        // Update the date and time every second
        setInterval(updateDateTime, 1000);
        // Initial call to display the date and time
        updateDateTime();
    </script>
    <script>
        document.getElementById('toggleButton').addEventListener('click', function () {
            document.getElementById('sidebar').classList.toggle('hidden');
        });
    </script>
    <script src="js/moderator.js"></script>
    <script src="js/adminscript.js"></script>
</body>

</html>