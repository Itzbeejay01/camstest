document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("myForm");
  const submitButton = document.getElementById("submitButton");
  const timerValue = document.getElementById("timerValue");

  // Check if timer is running
  let startTime = localStorage.getItem("startTime");
  if (startTime) {
    startTimer();
    const elapsedTime = Math.floor((Date.now() - parseInt(startTime)) / 1000);
    const timeRemaining = 600 - elapsedTime; // Timer runs for 1 minute (60 seconds)
    if (timeRemaining > 0) {
      setTimeout(startTimer, timeRemaining * 1000);
    }
  }

  form.addEventListener("submit", function (event) {
    event.preventDefault();
    // Perform form submission tasks here
    console.log("Form submitted!");
  });

  function startTimer() {
    submitButton.click();
    localStorage.setItem("startTime", Date.now().toString());
    let seconds = 0;
    const interval = setInterval(() => {
      seconds++;
      const minutes = Math.floor(seconds / 60);
      const remainingSeconds = seconds % 60;
      timerValue.textContent = `${minutes}:${
        remainingSeconds < 10 ? "0" : ""
      }${remainingSeconds}`;
      if (seconds >= 60) {
        submitButton.click();
        clearInterval(interval);
      }
    }, 1000); // Update timer every second
  }
});
