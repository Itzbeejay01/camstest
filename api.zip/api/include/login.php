<?php
include 'connection.php';
session_start();
// Check login
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userRole = $_POST['userRole'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $hashed_password = hash('sha256', $password); // Hash the password using SHA256

    if ($userRole == "superAdmin") {
        $query = "SELECT surname FROM tbladmin WHERE email = '$email' AND password = '$hashed_password'";
        $result = mysqli_query($connect, $query);
        
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $_SESSION["username"] = $row["surname"];
            echo "<script type = \"text/javascript\">
            window.location = (\"admin/index.php\")
            </script>";
        } else {
            echo "<div class='bg-red-500 shadow-slate-200 shadow-md text-white px-5 py-3 rounded-md  my-2 mb-8 text-center'>Invalid email or password</div>";
        }
    } else if ($userRole == "moderator") {
        // Query to check moderator credentials
        $query = "SELECT * FROM tblmoderator WHERE email='$email' AND password='$hashed_password'";
        $result = mysqli_query($connect, $query);

        if (mysqli_num_rows($result) == 1) {
            // Moderator authenticated, set session
            $moderator = mysqli_fetch_assoc($result);
            $_SESSION['mod_id'] = $moderator['mod_id'];
            //$_SESSION['email'] = $moderator['email'];
            echo "<script type = \"text/javascript\">
            window.location = (\"moderator/index.php\")
            </script>";
        } else {
            // Moderator authentication failed
            echo "<div class='bg-red-500 shadow-slate-200 shadow-md text-white px-5 py-3 rounded-md  my-2 mb-8 text-center'>Invalid email or password</div>";
        }
    }
}
?>