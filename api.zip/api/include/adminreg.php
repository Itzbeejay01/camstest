<?php
include 'connection.php';
if(isset($_POST['submit'])){
    $surname = $_POST['surname'];
    $othernames = $_POST['othernames'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Hash the password using SHA256
    $hashed_password = hash('sha256', $password);

    $check_email = $connect->query("SELECT email FROM tbladmin WHERE email='$email'");
    $count = $check_email->num_rows;
    
    if ($count == 0){
        $query = "INSERT INTO tbladmin (surname, othernames, email, password) VALUES ('$surname', '$othernames', '$email', '$hashed_password')";
        
        if ($connect->query($query)) {
            echo "<div class='bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4' role='alert'>
                <p class='font-bold'>Registration successful! <a class='text-green-500 underline' href='index.php'>Login now</a></p> 
            </div>";
        } else {
            echo '<div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
                <p class="font-bold">Registration Error!</p>
            </div>';
        }
    } else {
        echo '<div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
            <p class="font-bold">Email already exists!</p>
        </div>';
    }
} 
?>