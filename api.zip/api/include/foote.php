<footer class="bg-transparent backdrop-blur-sm w-full py-2 fixed bottom-0 right-2 left-0">
    <p class="text-md font-medium text-center text-black">
        &copy; <script>document.write(new Date().getFullYear());</script>. Created by &ThinSpace;BeeTechHub
    </p>
</footer>
