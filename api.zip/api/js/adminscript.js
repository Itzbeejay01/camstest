document.getElementById('adminLoginForm').addEventListener('submit', function (event) {
    var emailInput = document.getElementById('email');
    var emailValue = emailInput.value.trim();

    if (!emailValue.endsWith('@jabu.edu.ng')) {
        alert('Please enter a valid JABU email address.');
        event.preventDefault();
    }
});
document.getElementById('adminRegistrationForm').addEventListener('submit', function(event) {
    event.preventDefault();
    var userRole = document.getElementById('userRole').value;
    var surname = document.getElementById('surname').value.trim();
    var othernames = document.getElementById('othernames').value.trim();
    var email = document.getElementById('email').value.trim();
    var password = document.getElementById('password').value.trim();
    var registrationCode = document.getElementById('registrationCode').value.trim();


    if (userRole === "" || surname === "" || othernames === "" || email === "" || password === "" || registrationCode === "") {
        alert("Please fill in all fields");
        return;
    }


    if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/.test(password)) {
        alert("Password must contain at least one lowercase letter, one uppercase letter, one symbol, and one number");
        return;
    }

    alert("Registration successful!");

    document.getElementById('adminRegistrationForm').submit();
});


function updateDateTime() {
    const dateTimeElement = document.getElementById('currentDateTime');
    const now = new Date();
    const date = now.toLocaleDateString();
    const time = now.toLocaleTimeString();
    dateTimeElement.textContent = `Current Date: ${date} | Current Time: ${time}`;
  }

  // Update the date and time every second
  setInterval(updateDateTime, 1000);

  // Initial call to display the date and time
  updateDateTime();