
    document.addEventListener('DOMContentLoaded', function() {
        var table = document.getElementById('data-table');
        var rows = table.getElementsByTagName('tr');
        
        for (var i = 1; i < rows.length; i++) {
            var cell = document.createElement('td');
            cell.textContent = i;
            cell.style.border = '1px solid lightgray'; // Add border style here
            rows[i].insertBefore(cell, rows[i].firstChild);
        }
    });
    