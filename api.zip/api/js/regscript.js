// FOR email
// Dynamic email validation as user types
document.getElementById('email').addEventListener('input', function() {
    var emailInput = this.value.trim();
    var emailError = document.getElementById('emailError');

    if (!emailInput.endsWith('@students.jabu.edu.ng')) {
      emailError.classList.remove('hidden');
      emailError.textContent = 'Please enter a valid student email address.';
      this.classList.remove('border-green-300');
      this.classList.add('border-red-300');
    } else {
      emailError.classList.add('hidden');
      emailError.textContent = '';
      this.classList.remove('border-red-300');
      this.classList.add('border-green-300');
    }
  });

  // Form submission validation
  document.getElementById('registrationForm').addEventListener('submit', function(event) {
    var emailInput = document.getElementById('email').value.trim();
    var emailError = document.getElementById('emailError');

    if (!emailInput.endsWith('@students.jabu.edu.ng')) {
      emailError.classList.remove('hidden');
      emailError.textContent = 'Please enter a valid student email address.';
      document.getElementById('email').classList.remove('border-green-300');
      document.getElementById('email').classList.add('border-red-300');
      event.preventDefault(); // Prevent form submission
    } else {
      emailError.classList.add('hidden');
      emailError.textContent = '';
      document.getElementById('email').classList.remove('border-red-300');
      document.getElementById('email').classList.add('border-green-300');
    }
  });

// Phone number validation
document.getElementById('phoneNumber').addEventListener('input', function() {
    var phoneNumberInput = this.value.trim();
    var phoneNumberError = document.getElementById('phoneNumberError');
  
    if (!/^\d+$/.test(phoneNumberInput)) {
      phoneNumberError.classList.remove('hidden');
      phoneNumberError.textContent = 'Phone number must contain only numeric digits.';
      this.classList.remove('border-green-300');
      this.classList.add('border-red-300');
    } else if (phoneNumberInput.length !== 11) {
      phoneNumberError.classList.remove('hidden');
      phoneNumberError.textContent = 'Phone number must be exactly 11 digits.';
      this.classList.remove('border-green-300');
      this.classList.add('border-red-300');
    } else {
      phoneNumberError.classList.add('hidden');
      phoneNumberError.textContent = '';
      this.classList.remove('border-red-300');
      this.classList.add('border-green-300');
    }
  });
  
document.getElementById('registrationForm').addEventListener('submit', function (event) {
    var hostelsValue = document.getElementById('hostels').value;
    var bedSpaceInput = document.getElementById('bedSpace');
    var bedSpaceValue = bedSpaceInput.value;

    if ((hostelsValue === '4' || hostelsValue === '8') && bedSpaceValue > 4) {
        alert('Bed space cannot be greater than 4.');
        event.preventDefault();
    } else if ((hostelsValue !== '4' && hostelsValue !== '8') && bedSpaceValue > 8) {
        alert('Bed space cannot be greater than 8.');
        event.preventDefault();
    }
});

document.getElementById('college').addEventListener('change', function () {
    var collegeValue = this.value;
    var departmentDropdown = document.getElementById('department');

    departmentDropdown.innerHTML = '<option value="" disabled selected>Select Department</option>';

    if (collegeValue === '1') {
        addOption(departmentDropdown, '1', 'Agriculture');
        addOption(departmentDropdown, '2', 'Biochemistry');
        addOption(departmentDropdown, '3', 'Computer Science');
        addOption(departmentDropdown, '4', 'Food Science and Technology');
        addOption(departmentDropdown, '5', 'Microbiology');
        addOption(departmentDropdown, '6', 'Industrial Chemistry');
        addOption(departmentDropdown, '7', 'Physics');
    } else if (collegeValue === '2') {
        addOption(departmentDropdown, '8', 'Medical Laboratory Science');
        addOption(departmentDropdown, '9', 'Nursing');
    } else if (collegeValue === '3') {
        addOption(departmentDropdown, '10', 'Law');
    }else if (collegeValue === '4') {
        addOption(departmentDropdown, '11', 'Economics');
        addOption(departmentDropdown, '12', 'English');
        addOption(departmentDropdown, '13', 'History and International Studies');
        addOption(departmentDropdown, '14', 'Mass Communication');
        addOption(departmentDropdown, '15', 'Political Science');
        addOption(departmentDropdown, '16', 'Public Administrtaion');
        addOption(departmentDropdown, '17', 'Religious Studies');
        addOption(departmentDropdown, '28', 'International Relation');
    }else if (collegeValue === '5') {
        addOption(departmentDropdown, '18', 'Architecture');
        addOption(departmentDropdown, '19', 'Building and Quantity Survey');
        addOption(departmentDropdown, '20', 'Estate Management');
        addOption(departmentDropdown, '21', 'Geography');
        addOption(departmentDropdown, '22', 'Urban and Regional Planning');
    } else if (collegeValue === '6') {
        addOption(departmentDropdown, '23', 'Accounting');
        addOption(departmentDropdown, '24', 'Actuarial Science and Insurance');
        addOption(departmentDropdown, '25', 'Business Administration');
        addOption(departmentDropdown, '26', 'Entrepreneurship');
        addOption(departmentDropdown, '27', 'Human Resource Management and Industrial Relations');
    }
});

function addOption(selectElement, value, text) {
    var option = document.createElement('option');
    option.value = value;
    option.text = text;
    selectElement.add(option);
}
document.getElementById('hostels').addEventListener('change', function () {
    var hostelsValue = this.value;
    var blockContainer = document.getElementById('blockContainer');
    var blockDropdown = document.getElementById('block');

    blockContainer.style.display = 'none';

    if (hostelsValue === '4' || hostelsValue === '8') {
        blockContainer.style.display = 'block';

        blockDropdown.innerHTML = '<option value="">Select Block</option>';

        var endValue = (hostelsValue === '4') ? 8 : 9; // If hostel is 4, end at 8; if hostel is 8, end at 9
        for (var i = 1; i <= endValue; i++) {
            if (hostelsValue === '8' && i === 10) continue; // Skip 10 if hostel is 8
            addOption(blockDropdown, i, 'Block ' + i);
        }
        if (hostelsValue === '8') {
            addOption(blockDropdown, 11, 'Block 11'); // Add Block 11 for hostel 8
        }
    } else {
        blockContainer.style.display = 'none'; // Hide block container if hostel value is not 4 or 8
    }
});

function addOption(selectElement, value, text) {
    var option = document.createElement('option');
    option.value = value;
    option.textContent = text;
    selectElement.appendChild(option);
}

document.getElementById('registrationForm').addEventListener('submit', function (event) {
    var phoneNumberInput = document.getElementById('phoneNumber');
    var phoneNumberValue = phoneNumberInput.value.trim();

    if (!phoneNumberValue.startsWith('0') || phoneNumberValue.length !== 11) {
        alert('Phone number should start with "0" and have a length of 11 digits.');
        event.preventDefault();
    }
});
document.getElementById('registrationForm').addEventListener('submit', function (event) {
    var imageInput = document.getElementById('image');
    
    // Check if a photo has been taken
    if (!imageInput.files || !imageInput.files[0]) {
        alert('Please take a photo before submitting.');
        event.preventDefault(); // Prevent form submission
    }
});
