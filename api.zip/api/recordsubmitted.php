<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Record Submitted</title>
    <link rel="stylesheet" href="dist/output.css">
    <link rel="shortcut icon" href="img/logo.png" type="image/x-icon">
    <style>
        @keyframes rotate {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }

        .loading-container {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .loading-spinner {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            border: 5px solid #17a349;
            border-top-color: transparent;
            animation: rotate 0.7s infinite linear;
        }
    </style>
</head>

<body class="w-full flex flex-col items-center justify-center h-screen px-2">
    <div class="bg-transparent backdrop-blur-sm px-8 py-12 rounded shadow-lg shadow-gray-500 text-center mb-16">
        <h1 class="text-2xl font-bold text-green-600 mb-4">Record Submitted Successfully!</h1>
        <div class="loading-container">
            <div class="loading-spinner"></div>
        </div>
        <p class="text-gray-600 mb-4">You will be redirected <a href="attendance/index.php" class="text-blue-600"></a>
            in <span id="countdown">5</span> seconds.</p>
        <p class="text-gray-600">If you are not redirected, please click <a href="attendance/index.php"
                class="text-blue-600">here</a>.</p>
    </div>
    <script>
        let timeLeft = 5;
        const countdown = document.getElementById('countdown');

        const timer = setInterval(() => {
            timeLeft--;
            countdown.textContent = timeLeft;

            if (timeLeft <= 0) {
                clearInterval(timer);
                window.location.href = 'attendance/index.php';
            }
        }, 1000);
    </script>
</body>

</html>