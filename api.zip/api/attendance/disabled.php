<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page Status</title>
    <!-- Include Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>

<body class="bg-gray-100 flex justify-center items-center h-screen">

    <div class="max-w-md bg-white shadow-md rounded p-8">
        <!-- Page Disabled message -->
        <div class="text-red-600 text-lg font-semibold">
            Page Disabled
        </div>
        <div class="text-gray-600 mt-4">
            This page has been disabled by the administrator.
        </div>
    </div>
</body>

</html>