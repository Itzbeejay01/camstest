<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Check Attendance</title>
    <link rel="stylesheet" href="../dist/output.css">
    <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
</head>
<style>
    @media screen and (min-width: 1024px) {
        .mybody {
            padding-left: 450px;
            padding-right: 450px;
            padding-top: 80px;
            padding-bottom: 100px;
        }
    }

    .student-image {
        width: 80px;
        height: auto;
        border-radius: 50%;
    }
</style>

<body class="w-full h-full loginback mybody px-2 py-10">
    <div class="flex flex-col items-center">
        <h2 class="text-xl text-gray-600 font-bold mb-4 text-center">JABU CHAPEL ATTENDANCE MANAGEMENT SYSTEM</h2>
        <img class="w-24" src="../img/logo.png" alt="">
        <h2 class="text-lg font-medium text-center text-gray-600 mb-5">Student Attendance Report</h2>
    </div>
    <div class="w-full lg:w-full px-4 py-3 bg-white rounded-lg shadow-lg">
        <?php
        include "../include/connection.php";

        // Check if form is submitted
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Fetch matricNumber and surname from form submission
            $matricNumber = $_POST['matricNumber'];
            $surname = $_POST['surname'];

            // Prepare SQL query to get student details and attendance percentage
            $sql_query = "SELECT s.surname, s.othernames, s.matricNumber, h.hostel, s.block, s.roomNo, s.bedSpace,
        COUNT(a.attendance_status) AS total_attendance,
        SUM(CASE WHEN a.attendance_status = 1 THEN 1 ELSE 0 END) AS present_attendance,
        CONCAT('../uploads/', s.matricNumber, '.jpg') AS image_path
        FROM tblstudents s
        LEFT JOIN tblattendance a ON s.student_id = a.student_id
        LEFT JOIN tblhostels h ON s.hostel_id = h.id
        WHERE s.matricNumber = ? AND s.surname = ?
        GROUP BY s.surname, s.othernames, s.matricNumber, h.id, s.block, s.roomNo, s.bedSpace";


            // Using prepared statement to prevent SQL injection
            $stmt = $connect->prepare($sql_query);
            $stmt->bind_param("ss", $matricNumber, $surname);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                // Fetch student details and attendance percentage
                $row = $result->fetch_assoc();
                $surname = $row['surname'];
                $othernames = $row['othernames'];
                $matricNumber = $row['matricNumber'];
                $hostel_id = $row['hostel'];
                $block = $row['block'];
                $roomNo = $row['roomNo'];
                $bedSpace = $row['bedSpace'];
                $total_attendance = $row['total_attendance'];
                $present_attendance = $row['present_attendance'];
                $image_path = $row['image_path'];

                // Calculate attendance percentage, handling division by zero
                $attendance_percentage = ($total_attendance > 0) ? ($present_attendance / $total_attendance) * 100 : 0;

                // Determine color based on attendance percentage
                if ($attendance_percentage <= 45) {
                    $color_class = "bg-red-600 text-white";
                } elseif ($attendance_percentage <= 70) {
                    $color_class = "bg-blue-500 text-white";
                } else {
                    $color_class = "bg-green-500 text-white";
                }

                // Display student information and attendance percentage
                ?>
                <div class="">
                    <p class="text-lg font-semibold">Student Information:</p>
                    <div class="mx-4 flex items-center justify-end mb-4">
                        <?php
                        // Fetch and display image
                        $image_extensions = ['jpg', 'jpeg', 'png', 'gif']; // Add more extensions as needed
                        $image_found = false;
                        foreach ($image_extensions as $extension) {
                            $image_filename = $row['matricNumber'] . '.' . $extension;
                            $image_path = '../uploads/' . $image_filename;
                            if (file_exists($image_path)) {
                                echo '<div class="image-container" style="width:100px;"><img src="' . $image_path . '" alt="Student Image" class="rounded-full"></div>';
                                $image_found = true;
                                break;
                            }
                        }
                        if (!$image_found) {
                            echo '<p>Image not found</p>';
                        }
                        ?>
                    </div>
                    <table class="w-full bg-white shadow-md rounded-lg overflow-hidden">
                        <thead class="bg-green-500 text-white mt-4">
                            <tr>
                                <th class="py-3 px-4 font-semibold uppercase">Field</th>
                                <th class="py-3 px-4 font-semibold uppercase">Value</th>
                            </tr>
                        </thead>
                        <tbody class="text-gray-600">
                            <tr>
                                <td class="py-3 px-4">Surname:</td>
                                <td class="py-3 px-2"><?php echo $surname; ?></td>
                            </tr>
                            <tr class="bg-gray-100">
                                <td class="py-3 px-4">Other Names:</td>
                                <td class="py-3 px-2"><?php echo $othernames; ?></td>
                            </tr>
                            <tr>
                                <td class="py-3 px-4">Matric Number:</td>
                                <td class="py-3 px-2"><?php echo $matricNumber; ?></td>
                            </tr>
                            <tr class="bg-gray-100">
                                <td class="py-3 px-4">Hostel:</td>
                                <td class="py-3 px-2"><?php echo $hostel_id; ?></td>
                            </tr>
                            <tr>
                                <td class="py-3 px-4">Block:</td>
                                <td class="py-3 px-2"><?php echo $block; ?></td>
                            </tr>
                            <tr class="bg-gray-100">
                                <td class="py-3 px-4">Room Number:</td>
                                <td class="py-3 px-2"><?php echo $roomNo; ?></td>
                            </tr>
                            <tr>
                                <td class="py-3 px-4">Bed Space:</td>
                                <td class="py-3 px-2"><?php echo $bedSpace; ?></td>
                            </tr>
                        </tbody>
                    </table>

                    <p class="mt-4 text-lg font-semibold">Percentage:</p>
                    <div class=" py-2 flex items-center justify-center">
                        <div
                            class="<?php echo $color_class; ?> border-4 rounded-full w-24 h-24 px-4 py-2 flex items-center justify-center">
                            <p class="text-xl font-bold"><?php echo round($attendance_percentage, 2); ?>%</p>
                        </div>
                    </div>
                </div>
                <a href="index.php"
                    class="inline-block bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-8 rounded-full text-center">
                    Logout
                </a>
                <?php
            } else {
                echo '<p class="text-red-500">Incorrect Matric Number or password. &ThickSpace;<span class="text-blue-500"><a href="index.php">Try again</a></span></p>';
            }

            // Close statement and database connection
            $stmt->close();
            $connect->close();
        }
        ?>
    </div>
    <footer class="h-full mt-5">
        <?php
        include "../admin/include/footer.php";
        ?>
    </footer>
</body>

</html>