<?php
// Start the session
session_start();

// Include the file with database connection parameters
include "../include/connection.php";

// Sanitize the input to prevent SQL injection
$pageId = $connect->real_escape_string('thechecker');

// Query database for page status
$sql = "SELECT status FROM page_status WHERE page_id = '$pageId'";
$result = $connect->query($sql);

if ($result && $result->num_rows > 0) {
    // Fetch the first row
    $row = $result->fetch_assoc();
    $status = $row["status"];

    // Check if the page is disabled
    if ($status === 'disabled') {
        // If the page is disabled, show a message and exit
        header('Location: disabled.php');
        exit; // Stop further execution of the script
    }
} else {
    // If status is not found, display an error message
    echo "Status not found.";
}
?><!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Check Attendance</title>
    <link rel="stylesheet" href="../dist/output.css">
    <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
</head>
<style>
    @media screen and (min-width: 1024px) {
        .mybody {
            padding-left: 450px;
            padding-right: 450px;
            padding-top: 80px;
            padding-bottom: 100px;
        }
    }
</style>

<body class="w-full h-full loginback mybody px-4 py-10">
    <div class="flex flex-col items-center bg-transparent bg-white py-8 px-2 rounded shadow-md">
        <h2 class="text-xl text-gray-600 font-bold mb-4 text-center">JABU CHAPEL ATTENDANCE MANAGEMENT SYSTEM</h2>
        <p class="mb-4 text-center">(JABU_CAMS)</p>
        <img class="w-24" src="../img/logo.png" alt="">
        <h2 class="text-lg font-medium text-center text-gray-600 mb-5">Attendance Checker</h2>
        <div class="w-full mx-auto bg-transparent py-8 px-4">
            <form action="check_attendance.php" method="POST">
                <div class="relative mb-4">
                    <input type="text" id="matricNumber" name="matricNumber"
                        class="w-full shadow-md shadow-green-500 rounded-full pl-12 pr-2 py-2 px-2 outline-none"
                        placeholder="Matric Number" maxlength="10" required>
                    <div class="absolute inset-y-0 left-0 flex items-center rounded-l-md px-3 ">
                        <span class="material-symbols-outlined text-2xl text-green-500">123</span>
                    </div>
                </div>
                <div class="relative mb-2">
                    <input type="password" id="surname" name="surname"
                        class="w-full shadow-md shadow-green-500 rounded-full pl-12 pr-2 py-2 px-2 outline-none"
                        placeholder="Password" required>
                    <div class="absolute inset-y-0 left-0 flex items-center rounded-l-md px-3 ">
                        <span class="material-symbols-outlined text-2xl text-green-500">key</span>
                    </div>
                </div>
                <p class="text-gray-600 text-sm mb-8 px-4"><span>N.B:</span>Your surname is your password</p>

                <button type="submit"
                    class="w-full bg-green-500 text-white py-2 px-4 font-bold rounded-full hover:bg-green-600 flex items-center justify-center"><span
                        class="material-symbols-outlined text-white font-semibold mr-1">arrow_right_alt</span>&ThinSpace;Login</button>
            </form>
        </div>
    </div>
    <footer class="h-full mt-10">
        <?php
        include "../admin/include/footer.php";
        ?>
    </footer>
    <script>
        // Add event listeners to trim input values on change
        document.getElementById('matricNumber').addEventListener('change', function () {
            this.value = this.value.trim();
        });

        document.getElementById('surname').addEventListener('change', function () {
            this.value = this.value.trim();
        });
    </script>
</body>

</html>